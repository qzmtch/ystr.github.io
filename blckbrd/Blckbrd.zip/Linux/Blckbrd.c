#include <stdio.h>
#include <stdint.h>
#include <assert.h>




typedef int8_t s8; typedef uint8_t u8;
typedef int16_t s16; typedef uint16_t u16;
typedef int32_t s32; typedef uint32_t u32;

#define MIN(A,B) ((A) < (B) ? (A) : (B))
#define MAX(A,B) ((A) > (B) ? (A) : (B))
#define SWAP(T,V0,V1) { T swap = V0; V0 = V1; V1 = swap; }
#define LIST(T,V,A,C) (T V = A; V < A + C; V++)




typedef u8 Color;
typedef struct { u8 R, G, B; } Rgb;
typedef struct { int L, T, R, B; } Rect;
typedef struct { s32 X, Y; } XY;

#define RGB2(r,g,b) ((r << 6) | (g << 4) | (b << 2) | (3 << 0))
#define RGBA2(r,g,b,a) ((r << 6) | (g << 4) | (b << 2) | (a << 0))




void* LoadData (const char* name);
void SaveData (const char* name, const void* data, long size);
void DeleteData (const char* name);
Raster* NewRaster (int w, int h);
void ZapRaster (Raster* pi);
void Invalidate (const Rect* r);
void Quit ();




#define TILESIZE 512
#define TILEAREA (TILESIZE * TILESIZE)




typedef struct {
	
	XY Coords;
	
	Color* Doodle;
	Raster* Buffer;
	
} Tile;

typedef struct {
	
	XY TopLeft;
	XY Size;
	
	int Count;
	Tile** Tiles;
	
} Grid;

typedef struct {
	
	XY Start, End;
	Rect Bounds;
	
	Rect GridBounds;
	
} Stroke;

struct {
	
	XY ScreenSize;
	XY GridSize;
	
	Grid* Grid;
	
	Color PenColor;
	
	XY TileLocation;
	XY GridLocation;
	
	struct {
		
		enum { NORMAL = 0, DRAWING, PANNING, ERASING } Mode;
		
		XY OldPointer;
		XY NewPointer;
		
		Rect OldSelRect;
		Rect NewSelRect;
		
		Rect BoundingSelRect;
		
		Stroke Action;
		
	} Input;
	
	struct {
		
		Raster* Texture;
		
		#define BACKCOUNT 15
		const Rgb Colors[BACKCOUNT];
		
		int Index;
		Rgb Color;
		
	} Background;
	
} Board = {
	
	.Background.Colors =
	{
		{ 00, 00, 00 }, { 16, 16, 16 }, { 32, 32, 32 },
		{ 32, 00, 00 }, { 00, 32, 00 }, { 00, 00, 32 },
		{ 32, 16, 16 }, { 16, 32, 16 }, { 16, 16, 32 },
		{ 32, 32, 00 }, { 00, 32, 32 }, { 32, 00, 32 },
		{ 32, 32, 16 }, { 16, 32, 32 }, { 32, 16, 32 },
	}
};




Pixel Pixelize (Color c)
{
	return (Pixel) {
		.R = ((c >> 6) & 3) * 85,
		.G = ((c >> 4) & 3) * 85,
		.B = ((c >> 2) & 3) * 85
	};
}

Rect FindBoundingRect (const Rect* r1, const Rect* r2)
{
	return (Rect) {
		.L = MIN(r1->L, r2->L), .T = MIN(r1->T, r2->T),
		.R = MAX(r1->R, r2->R), .B = MAX(r1->B, r2->B)
	};
}

Rect GetGridBounds (const Rect* r)
{
	return (Rect) {
		.L = (r->L + Board.TileLocation.X) / TILESIZE,
		.R = (r->R + Board.TileLocation.X) / TILESIZE,
		.T = (r->T + Board.TileLocation.Y) / TILESIZE,
		.B = (r->B + Board.TileLocation.Y) / TILESIZE
	};
}

char* GetTileName (s32 x, s32 y)
{
	char* name = malloc(sizeof(char) * 32);
	sprintf(name, "%li.%li", (long) x, (long) y);
	return name;
}

Color* LoadDoodle (s32 x, s32 y)
{
	char* name = GetTileName(x, y);
	Color* doo = LoadData(name);
	
	if (!doo)
	{
		doo = malloc(sizeof(Color) * TILEAREA);
		for (int i = 0; i < TILEAREA; i++) doo[i] = 0;
	}
	
	free(name);
	return doo;
}

void SaveDoodle (const Color* doo, s32 x, s32 y)
{
	char* name = GetTileName(x, y);
	
	long set = 0;
	const int threshold = 8;
	for (int i = 0; i < TILEAREA; i++) if (doo[i] != 0) set++;
	
	if (set > threshold) SaveData(name, doo, TILEAREA * sizeof(Color));
	else DeleteData(name);
	
	free(name);
}

void Bufferize (Tile* t)
{
	for (int i = 0; i < TILEAREA; i++)
	{
		if (t->Doodle[i] == 0) t->Buffer->Data[i] = Board.Background.Texture->Data[i];
		else t->Buffer->Data[i] = Pixelize(t->Doodle[i]);
	}
}

Tile* NewTile (s32 x, s32 y)
{
	Tile* t = malloc(sizeof(Tile));
	
	t->Coords.X = x;
	t->Coords.Y = y;
	
	t->Doodle = LoadDoodle(x, y);
	t->Buffer = NewRaster(TILESIZE, TILESIZE);
	
	Bufferize(t);
	return t;
}

void FinalizeTile (Tile* t)
{
	SaveDoodle(t->Doodle, t->Coords.X, t->Coords.Y);
	
	ZapRaster(t->Buffer);
	free(t->Doodle);
	free(t);
}

Tile** GetTileLocal (const Grid* g, s32 x, s32 y)
{
	if (x < 0 || x >= g->Size.X) return 0;
	if (y < 0 || y >= g->Size.Y) return 0;
	
	return &g->Tiles[y * g->Size.X + x];
}

Tile** GetTileGlobal (const Grid* g, s32 x, s32 y)
{
	x -= g->TopLeft.X; if (x < 0 || x >= g->Size.X) return 0;
	y -= g->TopLeft.Y; if (y < 0 || y >= g->Size.Y) return 0;
	
	return &g->Tiles[y * g->Size.X + x];
}

Grid* NewGrid (Grid* og, const XY* topleft, const XY* size)
{
	Grid* ng = malloc(sizeof(Grid));
	
	ng->TopLeft = *topleft;
	ng->Size = *size;
	ng->Count = size->X * size->Y;
	
	ng->Tiles = malloc(sizeof(Tile*) * ng->Count);
	for (int i = 0; i < ng->Count; i++) ng->Tiles[i] = 0;
	
	if (og)
	{
		for (int i = 0; i < og->Count; i++)
		{
			Tile* ot = og->Tiles[i];
			if (!ot) continue;
			
			Tile** nt = GetTileGlobal(ng, ot->Coords.X, ot->Coords.Y);
			if (nt) *nt = ot; else FinalizeTile(ot);
		}
		
		free(og->Tiles);
		free(og);
	}
	
	return ng;
}

void Transition (int* sub, int* grid)
{
	if (*sub < 0) { *sub += TILESIZE; *grid -= 1; }
	else if (*sub >= TILESIZE) { *sub -= TILESIZE; *grid += 1; }
}

void UpdateBoard ()
{
	if (
		Board.TileLocation.X < 0 || Board.TileLocation.X > TILESIZE ||
		Board.TileLocation.Y < 0 || Board.TileLocation.Y > TILESIZE
	) {
		XY newGridLoc = Board.GridLocation;
		XY newTileLoc = Board.TileLocation;
		
		Transition(&newTileLoc.X, &newGridLoc.X);
		Transition(&newTileLoc.Y, &newGridLoc.Y);
		
		Board.Grid = NewGrid(Board.Grid, &newGridLoc, &Board.GridSize);
		
		Board.GridLocation = newGridLoc;
		Board.TileLocation = newTileLoc;
	}
	
	for (int y = 0; y < Board.GridSize.Y; y++)
	{
		for (int x = 0; x < Board.GridSize.X; x++)
		{
			Tile** t = GetTileLocal(Board.Grid, x, y);
			if (!*t) *t = NewTile(Board.GridLocation.X + x, Board.GridLocation.Y + y);
		}
	}
}




void MakeNoise (int* c)
{
	static unsigned int seed = 0;
	seed = (seed * 1103515245 + 12345) / 16;
	*c += seed % 16;
}

void MakeBackground ()
{
	for (int y = 0, i = 0; y < TILESIZE; y++)
	{
		for (int x = 0; x < TILESIZE; x++, i++)
		{
			int r = Board.Background.Color.R; MakeNoise(&r);
			int g = Board.Background.Color.G; MakeNoise(&g);
			int b = Board.Background.Color.B; MakeNoise(&b);
			
			for (int i = 4; i <= TILESIZE; i *= 2)
			{
				if (x % i && y % i) continue;
				r += 3, g += 3, b += 3;
			}
			
			Pixel* p = &Board.Background.Texture->Data[i];
			
			p->R = r < 0 ? 0 : (r > 255 ? 255 : r);
			p->G = g < 0 ? 0 : (g > 255 ? 255 : g);
			p->B = b < 0 ? 0 : (b > 255 ? 255 : b);
		}
	}
}

void UpdateBackground ()
{
	MakeBackground();
	for LIST (Tile**, t, Board.Grid->Tiles, Board.Grid->Count) Bufferize(*t);
}

void NextBackground ()
{
	Board.Background.Index++;
	if (Board.Background.Index >= BACKCOUNT) Board.Background.Index = 0;
	Board.Background.Color = Board.Background.Colors[Board.Background.Index];
	UpdateBackground();
}

void PrepareBackground ()
{
	Board.Background.Texture = NewRaster(TILESIZE, TILESIZE);
	MakeBackground();
}




Stroke DoStroke (const XY* start, const XY* end)
{
	Stroke s = { .Start = *start, .End = *end };
	
	s.Bounds.L = start->X; s.Bounds.R = end->X;
	s.Bounds.T = start->Y; s.Bounds.B = end->Y;
	
	if (s.Bounds.L > s.Bounds.R) SWAP(int, s.Bounds.L, s.Bounds.R);
	if (s.Bounds.T > s.Bounds.B) SWAP(int, s.Bounds.T, s.Bounds.B);
	
	s.GridBounds = GetGridBounds(&s.Bounds);
	
	return s;
}

void DrawPixel (Tile* t, int x, int y)
{
	long i = y * TILESIZE + x;
	t->Buffer->Data[i] = Pixelize(Board.PenColor);
	t->Doodle[i] = Board.PenColor;
}

void ErasePixel (Tile* t, int x, int y)
{
	long i = y * TILESIZE + x;
	t->Buffer->Data[i] = Board.Background.Texture->Data[i];
	t->Doodle[i] = 0;
}

void Bresenline (Tile* t, int x, int y, int xt, int yt)
{
	int dx = abs(xt - x), sx = x < xt ? 1 : -1;
	int dy = abs(yt - y), sy = y < yt ? 1 : -1;
	
	int ee, e = (dx > dy ? dx : -dy) / 2;
	
	for (;;)
	{
		if (
			x >= 0 && x < TILESIZE &&
			y >= 0 && y < TILESIZE
		) {
			DrawPixel(t, x, y);
		}
		
		if (x == xt && y == yt) return;
		
		ee = e;
		
		if (ee > -dx) e -= dy, x += sx;
		if (ee < +dy) e += dx, y += sy;
	}
}

void DrawLine (const Stroke* s)
{
	for (int gy = s->GridBounds.T; gy <= s->GridBounds.B; gy++)
	{
		for (int gx = s->GridBounds.L; gx <= s->GridBounds.R; gx++)
		{
			Tile* t = *GetTileLocal(Board.Grid, gx, gy);
			
			int tox = s->Start.X - TILESIZE * gx + Board.TileLocation.X;
			int toy = s->Start.Y - TILESIZE * gy + Board.TileLocation.Y;
			int tnx = s->End.X - TILESIZE * gx + Board.TileLocation.X;
			int tny = s->End.Y - TILESIZE * gy + Board.TileLocation.Y;
			
			Bresenline(t, tox, toy, tnx, tny);
		}
	}
}

void EraseRectangle (const Stroke* s)
{
	for (int gy = s->GridBounds.T; gy <= s->GridBounds.B; gy++)
	{
		for (int gx = s->GridBounds.L; gx <= s->GridBounds.R; gx++)
		{
			Tile* t = *GetTileLocal(Board.Grid, gx, gy);
			
			int tox = s->Bounds.L - TILESIZE * gx + Board.TileLocation.X;
			int toy = s->Bounds.T - TILESIZE * gy + Board.TileLocation.Y;
			int tnx = s->Bounds.R - TILESIZE * gx + Board.TileLocation.X;
			int tny = s->Bounds.B - TILESIZE * gy + Board.TileLocation.Y;
			
			if (tox < 0) tox = 0;
			if (toy < 0) toy = 0;
			
			if (tnx >= TILESIZE) tnx = TILESIZE - 1;
			if (tny >= TILESIZE) tny = TILESIZE - 1;
			
			for (int y = toy; y <= tny; y++)
			{
				for (int x = tox; x <= tnx; x++)
				{
					ErasePixel(t, x, y);
				}
			}
		}
	}
}




void PrepareBoard ()
{
	Board.Grid = 0;
	Board.PenColor = RGB2(3,3,3);
	
	Board.GridLocation = (XY) { 0, 0 };
	Board.TileLocation = (XY) { 0, 0 };
	
	XY* gl = LoadData("GL");
	XY* tl = LoadData("TL");
	Rgb* bc = LoadData("BC");
	
	if (gl) { Board.GridLocation = *gl; free(gl); }
	if (tl) { Board.TileLocation = *tl; free(tl); }
	if (bc) { Board.Background.Color = *bc; free(bc); }
	
	PrepareBackground();
}

void NewBoard (int scrxs, int scrys)
{
	Board.ScreenSize.X = scrxs;
	Board.ScreenSize.Y = scrys;
	
	Board.GridSize.X = scrxs / TILESIZE + 2;
	Board.GridSize.Y = scrys / TILESIZE + 2;
	
	Board.Grid = NewGrid(Board.Grid, &Board.GridLocation, &Board.GridSize);
}

void Finalize ()
{
	for LIST (Tile**, t, Board.Grid->Tiles, Board.Grid->Count)
	{
		FinalizeTile(*t);
	}
	
	SaveData("GL", &Board.GridLocation, sizeof(XY));
	SaveData("TL", &Board.TileLocation, sizeof(XY));
	SaveData("BC", &Board.Background.Color, sizeof(Rgb));
}




void BbMouseDown (int x, int y, int btn)
{
	Board.Input.OldPointer = (XY) { x, y };
	
	switch (btn)
	{
		case BM_FIRST: Board.Input.Mode = DRAWING; break;
		case BM_THIRD: Board.Input.Mode = PANNING; break;
		case BM_SECOND: Board.Input.Mode = ERASING; break;
	}
}

void BbMouseUp ()
{
	switch (Board.Input.Mode)
	{
		case ERASING: {
			EraseRectangle(&Board.Input.Action);
			Board.Input.Mode = NORMAL;
			Invalidate(&Board.Input.BoundingSelRect);
		} break;
		
		default: Board.Input.Mode = NORMAL; break;
	}
}

void BbMouseMove (int x, int y)
{
	Board.Input.NewPointer = (XY) { x, y };
	
	XY oldMouse = Board.Input.OldPointer;
	XY newMouse = Board.Input.NewPointer;
	
	Board.Input.Action = DoStroke(&oldMouse, &newMouse);
	
	Rect mouseRect = {
		.L = Board.Input.Action.Bounds.L - 1,
		.T = Board.Input.Action.Bounds.T - 1,
		.R = Board.Input.Action.Bounds.R + 1,
		.B = Board.Input.Action.Bounds.B + 1
	};
	
	switch (Board.Input.Mode)
	{
		case NORMAL: {
			Board.Input.OldPointer = Board.Input.NewPointer;
		} break;
		
		case DRAWING: {
			DrawLine(&Board.Input.Action);
			Invalidate(&mouseRect);
			Board.Input.OldPointer = Board.Input.NewPointer;
		} break;
			
		case ERASING: {
			Board.Input.NewSelRect = mouseRect;
			Board.Input.BoundingSelRect = FindBoundingRect(&Board.Input.OldSelRect, &Board.Input.NewSelRect);
			Invalidate(&Board.Input.BoundingSelRect);
			Board.Input.OldSelRect = Board.Input.NewSelRect;
		} break;
		
		case PANNING: {
			
			Board.TileLocation.X += (Board.Input.OldPointer.X - Board.Input.NewPointer.X);
			Board.TileLocation.Y += (Board.Input.OldPointer.Y - Board.Input.NewPointer.Y);
			
			Invalidate(0);
			Board.Input.OldPointer = Board.Input.NewPointer;
			
		} break;
	}
}

void BbKeyPress (int key)
{
	switch (key)
	{
		case '0': Board.PenColor = RGB2(3, 3, 3); break;
		case '1': Board.PenColor = RGB2(3, 0, 0); break;
		case '2': Board.PenColor = RGB2(3, 1, 0); break;
		case '3': Board.PenColor = RGB2(3, 3, 0); break;
		case '4': Board.PenColor = RGB2(0, 3, 0); break;
		case '5': Board.PenColor = RGB2(0, 2, 3); break;
		case '6': Board.PenColor = RGB2(1, 1, 3); break;
		case '7': Board.PenColor = RGB2(3, 0, 3); break;
		case '8': Board.PenColor = RGB2(2, 2, 2); break;
		case '9': Board.PenColor = RGB2(1, 1, 1); break;
		
		case 'B': NextBackground(); break;
		
		case BK_UP: Board.TileLocation.Y -= 16; break;
		case BK_DOWN: Board.TileLocation.Y += 16; break;
		case BK_LEFT: Board.TileLocation.X -= 16; break;
		case BK_RIGHT: Board.TileLocation.X += 16; break;
		
		case BK_ESC: Quit(); return;
	}
	
	Invalidate(0);
}
