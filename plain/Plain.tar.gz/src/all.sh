for inf in $(ls defs); do
	./gen.py xfwm4 defs/$inf ../Themes/$inf/xfwm4
	ln -snf $(realpath ../Themes/$inf) ~/.themes/$inf
done
