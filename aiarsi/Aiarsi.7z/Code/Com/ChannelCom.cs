using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class ChannelCom : ChatCom
{
	public readonly Channel Channel;
	UserBox userList;
	
	public ChannelCom (Channel c) : base (c, Sig(c))
	{
		Channel = c;
		Text = Channel.Name;
		
		IconName = "Channel";
		Skinize();
		
		userList = new UserBox(Channel);
		userList.Dock = DockStyle.Fill;
		userList.BorderStyle = BorderStyle.None;
		VSplit.Panel2Collapsed = false;
		VSplit.Panel2.Controls.Add(userList);
		
		userList.UserDoubleClick += ShowQuery;
		
		userList.UserKeyDown += (u, e) =>
		{
			switch (e.KeyCode)
			{
				case Keys.Enter:
					if (e.Control) Insert(u.Nick);
					else ShowQuery(u);
				break;
				
				case Keys.Apps:
					ShowUserMenu(u, new Point(0, 0));
				break;
			}
		};
		
		userList.UserMouseDown += (u, e) =>
		{
			if (e.Button == MouseButtons.Right)
			{
				ShowUserMenu(u, e.Location);
			}
		};
		
		Channel.StatusChanged += SyncAdmitStatus;
		Channel.Terminated += Close;
		
		AdmitStatus();
	}
	
	protected override void Dispose (bool disposing)
	{
		Channel.StatusChanged -= SyncAdmitStatus;
		Channel.Terminated -= Close;
		base.Dispose(disposing);
	}
	
	
	void SyncAdmitStatus () { this.Sync(AdmitStatus); }
	void AdmitStatus ()
	{
		HSplit.Panel2Collapsed = VSplit.Panel2Collapsed = !(
			Channel.Status == ChannelStatus.Joined
		);
	}
	
	
	protected override void OnKey (KeyEventArgs e)
	{
		switch (e.KeyCode)
		{
			case Keys.Space: {
				if (e.Alt) userList.Focus();
			} break;
		}
		
		base.OnKey(e);
	}
	
	
	void OnNickClick (string word)
	{
		Insert(word.Trim(':'));
	}
	
	protected override Action<string> OnWordHover (string word)
	{
		if (word[0] == '#' && word.ToID() == Channel.ID) return null;
		if (Channel.HasUser(word.Trim(':').ToID())) return OnNickClick;
		return base.OnWordHover(word);
	}
	
	
	void Insert (string text)
	{
		Input.Text += text;
		Input.SelectionStart = Input.Text.Length;
		Input.SelectionLength = 0;
		Input.Focus();
	}
	
	void ClInsert (string text)
	{
		Input.Clear();
		Insert(text);
	}
	
	void ShowConsole (string line)
	{
		Server.Send(line);
		ConsoleCom.Open(Server);
	}
	
	void ShowQuery (User u)
	{
		QueryCom.Open(Channel.Server.AddQuery(u.Nick));
	}
	
	
	void ShowUserMenu (User u, Point loc)
	{
		ContextMenu userMenu = new ContextMenu();
		
		MenuRow queryRow = new MenuRow("Query", "Query", "Enter", true);
		MenuRow insertRow = new MenuRow(null, "Insert", "Ctrl + Enter");
		MenuRow whoisRow = new MenuRow(null, "Whois", null);
		
		userMenu.Items.Add(queryRow);
		userMenu.Items.Add(insertRow);
		userMenu.AddSeparator();
		userMenu.Items.Add(whoisRow);
		
		insertRow.Clicked += () => Insert(u.Nick);
		queryRow.Clicked += () => ShowQuery(u);
		whoisRow.Clicked += () => ShowConsole("WHOIS " + u.Nick);
		
		MenuRow ctcpRow = new MenuRow(null, "CTCP", null);
		MenuRow pingRow = new MenuRow(null, "Ping", null);
		MenuRow versionRow = new MenuRow(null, "Version", null);
		MenuRow timeRow = new MenuRow(null, "Time", null);
		MenuRow fingerRow = new MenuRow(null, "Finger", null);
		
		pingRow.Clicked += () => ShowConsole("/ctcp " + u.Nick + " PING " + DateTime.Now.ToUnixString());
		versionRow.Clicked += () => ShowConsole("/ctcp " + u.Nick + " VERSION");
		timeRow.Clicked += () => ShowConsole("/ctcp " + u.Nick + " TIME");
		fingerRow.Clicked += () => ShowConsole("/ctcp " + u.Nick + " FINGER");
		
		ctcpRow.DropDownItems.Add(pingRow);
		ctcpRow.DropDownItems.Add(versionRow);
		ctcpRow.DropDownItems.Add(timeRow);
		ctcpRow.DropDownItems.Add(fingerRow);
		
		userMenu.Items.Add(ctcpRow);
		
		if (Channel.OwnStatus == '@')
		{
			userMenu.Items.Add(new ToolStripSeparator());
			
			MenuRow controlRow = new MenuRow(null, "Control", null);
			
			MenuRow opRow = new MenuRow(null, "Op", null);
			MenuRow deopRow = new MenuRow(null, "Deop", null);
			MenuRow voiceRow = new MenuRow(null, "Voice", null);
			MenuRow devoiceRow = new MenuRow(null, "Devoice", null);
			
			MenuRow kickRow = new MenuRow(null, "Kick", null);
			MenuRow kickWhyRow = new MenuRow(null, "Kick (why)", null);
			MenuRow banRow = new MenuRow(null, "Ban", null);
			MenuRow banKickRow = new MenuRow(null, "Ban + Kick", null);
			MenuRow banKickWhyRow = new MenuRow(null, "Ban + Kick (why)", null);
			
			opRow.Clicked += () => Channel.Send("/mode +o " + u.Nick);
			deopRow.Clicked += () => Channel.Send("/mode -o " + u.Nick);
			voiceRow.Clicked += () => Channel.Send("/mode +v " + u.Nick);
			devoiceRow.Clicked += () => Channel.Send("/mode -v " + u.Nick);
			
			kickRow.Clicked += () => Channel.Send("/kick " + u.Nick);
			kickWhyRow.Clicked += () => ClInsert("/kick " + u.Nick + " ");
			banRow.Clicked += () => Channel.Send("/mode +b " + u.Nick);
			banKickRow.Clicked += () => { Channel.Send("/mode +b " + u.Nick); Channel.Send("/kick " + u.Nick); };
			banKickWhyRow.Clicked += () => { Channel.Send("/mode +b " + u.Nick); ClInsert("/kick " + u.Nick + " "); };
			
			controlRow.DropDownItems.Add(opRow);
			controlRow.DropDownItems.Add(deopRow);
			controlRow.DropDownItems.Add(voiceRow);
			controlRow.DropDownItems.Add(devoiceRow);
			
			controlRow.DropDownItems.Add(new ToolStripSeparator());
			
			controlRow.DropDownItems.Add(kickRow);
			controlRow.DropDownItems.Add(kickWhyRow);
			controlRow.DropDownItems.Add(banRow);
			controlRow.DropDownItems.Add(banKickRow);
			controlRow.DropDownItems.Add(banKickWhyRow);
			
			userMenu.Items.Add(controlRow);
		}
		
		userMenu.Show(userList, loc);
	}
	
	
	static string Sig (Channel c)
	{
		return "Servers\\" + c.Server.ID + "\\Channels\\" + Options.Escape(c.ID);
	}
	
	public static void Open (Channel c)
	{
		if (!Open(Sig(c)))
		{
			Open(new ChannelCom(c));
		}
	}
	
	public static ChannelCom Opened (Channel c)
	{
		return (ChannelCom) Opened(Sig(c));
	}
}