using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

class LogBox : RichTextBox
{
	object logLock = new object();
	public readonly Log Log;
	ulong? lastEntryNumber;
	
	string pointedWord = null;
	Action<string> wordClick = null;
	
	public delegate Action<string> WordHandler (string w);
	public event WordHandler WordPointed = (w) => { return null; };
	
	public LogBox (Log l)
	{
		Log = l;
		DetectUrls = false;
		AutoWordSelection = true;
		ReadOnly = true;
		
		DoubleBuffered = true;
		
		Style.Changed += SetStyle;
		Style.Changed += Reload;
		
		MouseMove += (o, e) =>
		{
			Action<string> newc = null;
			
			if (Text.Length > 0)
			{
				int ci = GetCharIndexFromPosition(new Point(e.X, e.Y));
				pointedWord = Text.WordFromIndex(ci);
				if (pointedWord != null) newc = WordPointed(pointedWord);
			}
			
			if (newc != wordClick)
			{
				if ((wordClick = newc) != null) Cursor = Cursors.Hand;
				else Cursor = Cursors.IBeam;
			}
		};
		
		MouseClick += (o, e) =>
		{
			if (e.Button == MouseButtons.Left)
			{
				if (wordClick != null) wordClick(pointedWord);
			}
		};
		
		SetStyle();
		
		Log.Logged += SyncAppend;
		Reload();
	}
	
	protected override void Dispose (bool disposing)
	{
		Log.Logged -= SyncAppend;
		Style.Changed -= SetStyle;
		Style.Changed -= Reload;
		base.Dispose(disposing);
	}
	
	void SetStyle ()
	{
		ForeColor = Style.Default.Fore;
		BackColor = Style.Default.Back;
	}
	
	void Reload ()
	{
		lock (logLock)
		{
			lastEntryNumber = null;
			
			this.SuspendRedraw();
			
			Clear();
			foreach (Entry e in Log.GetEntries()) Print(e);
			this.ScrollToBottom();
			
			this.ResumeRedraw();
		}
	}
	
	void SyncAppend (Entry e) { this.Sync(() => Append(e)); }
	void Append (Entry e)
	{
		int s = SelectionStart;
		int l = SelectionLength;
		
		if (Lines.Length >= Log.Limit)
		{
			ReadOnly = false;
			Select(0, Text.IndexOf("\n") + 1); 
			SelectedText = "";
			ReadOnly = true;
		}
		
		Print(e);
		
		if (Focused) {
			SelectionStart = s;
			SelectionLength = l;
		} else this.ScrollToBottom();
	}
	
	void Print (string t, Style f)
	{
		SelectionStart = TextLength;
		SelectionLength = 0;
		SelectionFont = f.Font;
		SelectionBackColor = f.Back;
		SelectionColor = f.Fore;
		AppendText(t);
	}
	
	void Print (Entry e)
	{
		lock (logLock)
		{
			if (e.Number <= lastEntryNumber) return;
			lastEntryNumber = e.Number;
			
			Print(e.Bullet + " ", Style.Get("Bullet"));
			
			if (Settings.ShowTime)
			{
				string time = e.Time.ToString("H:mm");
				if (Settings.ShowSeconds) time = time + ":" + e.Time.ToString("ss");
				Print(time + " ", Style.Get("Time"));
			}
			
			foreach (Chunk c in e.Output) Print(c.Text, c.Style);
			AppendText(Environment.NewLine);
		}
	}
}