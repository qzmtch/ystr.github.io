abstract class ChatCom : Com
{
	public readonly Chat Chat;
	
	public ChatCom (Chat c, string sig) : base (c.Log, c.Server, sig)
	{
		Chat = c;
		Input.LineSubmitted += Chat.Send;
	}
}