using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

class InputBox : Field
{
	public InputBox ()
	{
		AllowEmpty = false;
		Indication = false;
		Multiline = true;
		
		KeyDown += (o, e) =>
		{
			switch (e.KeyCode)
			{
				case Keys.Enter: {
					
					string text = Text.Trim(new char[] {'\n', '\r'});
					
					if (text.Length > 0)
					{
						string[] lines = text.Split('\n');
						for (int i = 0; i < lines.Length; i++) lines[i] = lines[i].Trim('\r');
						foreach (string l in lines) LineSubmitted(l);
						
						Clear();
					}
					
				} break;
				
				case Keys.A: {
					if (e.Control) SelectAll();
					else return;
				} break;
				
				default: return;
			}
			
			e.SuppressKeyPress = true;
		};
		
		Style.Changed += SetStyle;
		SetStyle();
	}
	
	protected override void Dispose (bool disposing)
	{
		Style.Changed -= SetStyle;
		base.Dispose(disposing);
	}
	
	void SetStyle ()
	{
		Font = Style.Default.Font;
		ForeColor = Style.Default.Fore;
		BackColor = Style.Default.Back;
	}
	
	public event Action<string> LineSubmitted = (s) => {};
}