using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class DebugCom : Com
{
	public DebugCom (Server s) : base (s.DebugLog, s, Sig(s))
	{
		Server.TitleChanged += SetTitle;
		Server.Link.StatusChanged += SyncAdmitStatus;
		
		Input.LineSubmitted += Server.Send;
		
		IconName = "Debug";
		Skinize();
		
		AdmitStatus();
		SetTitle();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= SetTitle;
		Server.TitleChanged -= SetTitle;
		Server.Link.StatusChanged -= SyncAdmitStatus;
		base.Dispose(disposing);
	}
	
	
	void SetTitle ()
	{
		Text = Own.Line("Debug: %0", Server.Title);
	}
	
	void SyncAdmitStatus () { this.Sync(AdmitStatus); }
	void AdmitStatus ()
	{
		HSplit.Panel2Collapsed = !(Server.Link.Status == LinkStatus.Connected);
	}
	
	
	static string Sig (Server s)
	{
		return "Servers\\" + s.ID + "\\Debug";
	}
	
	public static void Open (Server s)
	{
		if (!Open(Sig(s)))
		{
			Open(new DebugCom(s));
		}
	}
}