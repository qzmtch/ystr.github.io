using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class ConsoleCom : Com
{
	public ConsoleCom (Server s) : base (s.Log, s, Sig(s))
	{
		Server.TitleChanged += SetTitle;
		Server.Link.StatusChanged += SyncAdmitStatus;
		Input.LineSubmitted += Server.Send;
		
		IconName = "Console";
		Skinize();
		
		SetTitle();
		AdmitStatus();
	}
	
	protected override void Dispose (bool disposing)
	{
		Server.TitleChanged -= SetTitle;
		Server.Link.StatusChanged -= SyncAdmitStatus;
		base.Dispose(disposing);
	}
	
	
	void SetTitle ()
	{
		Text = Server.Title;
	}
	
	void SyncAdmitStatus () { this.Sync(AdmitStatus); }
	void AdmitStatus ()
	{
		HSplit.Panel2Collapsed = !(
			Input.Enabled = (Server.Link.Status == LinkStatus.Connected)
		);
	}
	
	
	static string Sig (Server s)
	{
		return "Servers\\" + s.ID;
	}
	
	public static void Open (Server s)
	{
		if (!Open(Sig(s)))
		{
			Open(new ConsoleCom(s));
		}
	}
	
	public static ConsoleCom Opened (Server s)
	{
		return (ConsoleCom) Opened(Sig(s));
	}
}