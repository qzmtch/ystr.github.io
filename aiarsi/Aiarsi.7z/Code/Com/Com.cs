using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

abstract class Com : Window
{
	protected readonly Log Log;
	protected readonly Server Server;
	
	
	protected readonly Splitter HSplit = new Splitter();
	protected readonly Splitter VSplit = new Splitter();
	
	protected readonly InputBox Input;
	protected readonly LogBox Output;
	
	
	protected string IconName;
	protected void Skinize () { Icon = Own.Icon(IconName); }
	
	
	public Com (Log l, Server s, string sig) : base (sig)
	{
		Log = l;
		Server = s;
		
		HSplit.Dock = DockStyle.Fill;
		HSplit.Orientation = Orientation.Horizontal;
		HSplit.BorderStyle = BorderStyle.Fixed3D;
		HSplit.FixedPanel = FixedPanel.Panel2;
		
		VSplit.Dock = DockStyle.Fill;
		VSplit.Orientation = Orientation.Vertical;
		VSplit.BorderStyle = BorderStyle.Fixed3D;
		VSplit.FixedPanel = FixedPanel.Panel2;
		VSplit.Panel2Collapsed = true;
		
		Output = new LogBox(Log);
		Output.Dock = DockStyle.Fill;
		Output.BorderStyle = BorderStyle.None;
		Output.WordPointed += OnWordHover;
		
		Input = new InputBox();
		Input.BorderStyle = BorderStyle.None;
		Input.Dock = DockStyle.Fill;
		
		VSplit.Panel1.Controls.Add(Output);
		HSplit.Panel1.Controls.Add(VSplit);
		HSplit.Panel2.Controls.Add(Input);
		Controls.Add(HSplit);
		
		Shown += (o, e) =>
		{
			Log.NowReading = true;
			Log.Unread = Unread.None;
			
			VSplit.RightPosition = Options.Get("VSplit", 128);
			HSplit.RightPosition = Options.Get("HSplit", 32);
			
			Input.Focus();
		};
		
		FormClosing += (o, e) =>
		{
			Log.NowReading = false;
			
			Options.Set("VSplit", VSplit.RightPosition);
			Options.Set("HSplit", HSplit.RightPosition);
		};
		
		Resize += (o, e) =>
		{
			if (Active) Log.Unread = Unread.None;
			Log.NowReading = !Minimized;
		};
		
		Activated += (o, e) =>
		{
			Log.Unread = Unread.None;
			Log.NowReading = true;
		};
		
		KeyDown += (o, e) => OnKey(e);
		
		Own.SkinChanged += Skinize;
		Server.Terminated += Close;
	}
	
	protected override void Dispose (bool disposing)
	{
		Server.Terminated -= Close;
		Own.SkinChanged -= Skinize;
		base.Dispose(disposing);
	}
	
	
	protected virtual void OnKey (KeyEventArgs e)
	{
		switch (e.KeyCode)
		{
			case Keys.Space: {
				if (e.Shift) Output.Focus();
				else if (!e.Alt) {
					if (Input.Focused) return;
					else Input.Focus();
				}
			} break;
			
			default: return;
		}
		
		e.SuppressKeyPress = true;
	}
	
	
	void OnLinkClick (string word)
	{
		Process.Start(word);
	}
	
	void OnChannelClick (string word)
	{
		Channel c = Server.AddChannel(word);
		if (Server.Welcomed && c.Status == ChannelStatus.Parted) Server.Send("JOIN " + word);
		ChannelCom.Open(c);
	}
	
	protected virtual Action<string> OnWordHover (string word)
	{
		if (word[0] == '#') return OnChannelClick;
		else if (word.LooksLikeUri()) return OnLinkClick;
		else return null;
	}
}