using System;
using System.Drawing;
using System.Windows.Forms;

class ToolBar : MenuStrip
{
	class ToolBarRenderer : ToolStripSystemRenderer
	{
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e) { }
	}
	
	class RightMargin : ToolStripLabel
	{
		public RightMargin ()
		{
			Alignment = ToolStripItemAlignment.Right;
			AutoSize = false;
			Width = 3;
		}
	}
	
	public ToolBar ()
	{
		RenderMode = ToolStripRenderMode.System;
		Renderer = new ToolBarRenderer();
		Items.Add(new RightMargin());
		ShowItemToolTips = true;
	}
}