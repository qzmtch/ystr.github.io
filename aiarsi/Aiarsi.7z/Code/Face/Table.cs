using System;
using System.Drawing;
using System.Windows.Forms;

class Table : TableLayoutPanel
{
	public Control this [int x]
	{ set {
		this[x, 0] = value;
	}}
	
	public Control this [int x, int y]
	{ set {
		value.Dock = DockStyle.Fill;
		Controls.Add(value, x, y);
	}}
	
	
	public void Put (params Control[] cs)
	{
		for (int i = 0; i < cs.Length; i++)
		{
			if (cs[i] != null) this[i] = cs[i];
		}
	}
	
	public void Set (params int[] cols)
	{
		foreach (int c in cols)
		{
			ColumnStyle style;
			
			if (c == 0) style = new ColumnStyle(SizeType.AutoSize);
			else style = new ColumnStyle(SizeType.Percent, c);
			
			ColumnStyles.Add(style);
		}
	}
	
	
	public Table ()
	{
		Dock = DockStyle.Top;
		AutoSize = true;
	}
	
	public Table (params int[] cols) : this () { Set(cols); }
	public Table (params Control[] cs) : this () { Put(cs); }
}