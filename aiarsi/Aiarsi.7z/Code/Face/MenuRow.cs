using System;
using System.Drawing;
using System.Windows.Forms;

class MenuRow : ToolStripMenuItem
{
	readonly string text;
	readonly string image;
	
	void Localize () { Text = Own.Line(text); }
	void Skinize () { if (image != null) Image = Own.Image(image); }
	
	bool bold = false;
	bool italic = false;
	
	public bool Bold {
		get { return bold; }
		set { bold = value; SetStyle(); }
	}
	
	public bool Italic {
		get { return italic; }
		set { italic = value; SetStyle(); }
	}
	
	void SetStyle ()
	{
		FontStyle style = FontStyle.Regular;
		if (bold) style |= FontStyle.Bold;
		if (italic) style |= FontStyle.Italic;
		Font = new Font(Font, style);
	}
	
	public MenuRow (string image, string text, string keys) : this (image, text, keys, false) { }
	public MenuRow (string image, string text, string keys, bool bold)
	{
		this.image = image;
		this.text = text;
		this.bold = bold;
		
		ShortcutKeyDisplayString = (keys == null) ? null : "(" + keys + ")";
		
		Own.LocaleChanged += Localize;
		Own.SkinChanged += Skinize;
		
		Localize();
		Skinize();
		
		Click += (o, e) => { Clicked(); };
		
		SetStyle();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		Own.SkinChanged -= Skinize;
		
		base.Dispose(disposing);
	}
	
	public event Action Clicked = () => {};
}