using System;
using System.Diagnostics;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;

class Window : Form
{
	#region Existing
		
		protected readonly string Signature;
		static protected Dictionary<string, Window> existing = new Dictionary<string, Window>();
		
		protected static Window Opened (string sig)
		{
			if (existing.ContainsKey(sig)) return existing[sig];
			else return null;
		}
		
		protected static bool Open (string sig)
		{
			if (sig == null) return false;
			Window o = Opened(sig);
			if (o == null) return false;
			o.Summon(); return true;
		}
		
		protected static void Open (Window w)
		{
			w.Closed += (o, e) => { existing.Remove(w.Signature); };
			existing[w.Signature] = w; w.Show(); w.Activate();
		}
		
	#endregion
	
	public bool Active { get { return ActiveForm == this; } }
	public bool Minimized { get { return WindowState == FormWindowState.Minimized; } }
	
	public void Summon ()
	{
		if (Minimized) this.Unminimize();
		Activate();
	}
	
	bool OnScreen { get {
		foreach (Screen s in Screen.AllScreens)
			if (s.WorkingArea.Contains(Location)) return true;
		return false;
	} }
	
	protected Options Options;
	
	protected override Size DefaultSize {
		get {
			return new Size(640, 480);
		}
	}
	
	public Window () : this (null) {}
	public Window (string sig)
	{
		Signature = sig;
		
		Options = Options.Root.Open(Signature);
		
		Size = Options.Get("Size", DefaultSize);
		
		if (Options.HasValue("Location")) {
			Location = Options.Get("Location", Location);
			if (OnScreen) StartPosition = FormStartPosition.Manual;
			else StartPosition = FormStartPosition.CenterScreen;
		} else StartPosition = FormStartPosition.CenterScreen;
		
		if (Options.Get("Maximized", false)) WindowState = FormWindowState.Maximized;
		
		Closing += (o, e) =>
		{
			bool maxd = (WindowState == FormWindowState.Maximized);
			
			if (!maxd && !Minimized)
			{
				Options.Set("Size", Size);
				Options.Set("Location", Location);
			}
			
			Options.Set("Maximized", maxd);
		};
		
		KeyPreview = true;
		KeyDown += (o, e) =>
		{
			switch (e.KeyCode)
			{
				case Keys.F12: Settings.Open(); break;
				case Keys.F1: Process.Start(Own.Find("Help.htm")); break;
				default: return;
			}
			
			e.Handled = true;
		};
	}
}
