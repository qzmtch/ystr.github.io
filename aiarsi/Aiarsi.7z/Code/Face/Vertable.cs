using System;
using System.Drawing;
using System.Windows.Forms;

class Vertable : Table
{
	public Vertable (params Control[] cs)
	{
		for (int i = 0; i < cs.Length; i++)
		{
			if (cs[i] != null) this[0, i] = cs[i];
		}
	}
}