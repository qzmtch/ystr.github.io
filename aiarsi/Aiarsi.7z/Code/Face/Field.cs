using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Field : TextBox
{
	public bool Indication = true;
	
	public event Action Checked;
	public event Action Submitted;
	
	public bool AllowEmpty = true;
	public Regex Template = null;
	public char[] Disallow = null;
	
	public bool IntegerOnly = false;
	public int Min = int.MinValue;
	public int Max = int.MaxValue;
	
	public string[] List
	{
		get {
			
			string[] words = Text.Split(new char[] { ' ', ',', ';' });
			List<string> re = new List<string>();
			
			foreach (string w in words)
			{
				string word = w.Trim();
				if (word.Length > 0) re.Add(word);
			}
			
			return re.ToArray();
		}
		
		set {
			Text = string.Join(" ", value);
		}
	}
	
	public bool Okay
	{
		get
		{
			if (!AllowEmpty && Text.Length == 0) return false;
			if (Template != null && !Template.IsMatch(Text)) return false;
			if (Disallow != null && Text.IndexOfAny(Disallow) > -1) return false;
			
			if (IntegerOnly)
			{
				int val;
				try { val = Convert.ToInt32(Text); } catch { return false; }
				if (val < Min || val > Max) return false;
			}
			
			return true;
		}
	}
	
	public void Check ()
	{
		if (Indication)
		{
			if (Okay) ResetBackColor();
			else BackColor = Color.LightPink;
		}
		
		if (Checked != null) Checked();
	}
	
	public Field ()
	{
		DoubleBuffered = true;
		
		TextChanged += (o, e) => Check();
		
		KeyDown += (o, e) =>
		{
			if (e.KeyCode == Keys.Enter)
			{
				if (!Multiline || e.Control)
				{
					if (Submitted != null)
					{
						Submitted();
						e.Handled = true;
					}
				}
			}
		};
	}
}