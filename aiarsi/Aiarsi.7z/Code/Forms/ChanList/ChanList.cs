using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

class ChanList : Window
{
	public readonly Server Server;
	ChanListView list = new ChanListView();
	
	public ChanList (Server s) : base ("Servers\\" + s.ID + "\\ChanList")
	{
		Server = s;
		
		Skinize();
		SetTitle();
		
		Own.SkinChanged += Skinize;
		Own.LocaleChanged += SetTitle;
		
		Server.TitleChanged += SetTitle;
		Server.Terminated += Close;
		Server.WelcomedChanged += SyncAdmitStatus;
		
		list.Dock = DockStyle.Fill;
		Controls.Add(list);
		
		list.BeginUpdate();
		foreach (Server.ChanListItem i in Server.GetListedChans()) AddChanItem(i);
		list.EndUpdate();
		
		Server.ChanListStarted += SyncAdmitStart;
		Server.ChanListFinished += SyncAdmitFinish;
		Server.ChanListed += SyncAddSingleChanItem;
		
		if (
			Server.Welcomed &&
			Server.ListedChansCount == 0 &&
			!Server.ChanListInProgress
		) Start();
		
		KeyDown += (o, e) => { if (e.KeyCode == Keys.F5) Reload(); };
		
		list.ChannelInvoked += (cn) =>
		{
			Channel c = Server.AddChannel(cn);
			if (Server.Welcomed && c.Status == ChannelStatus.Parted) c.Join();
			ChannelCom.Open(c);
		};
		
		AdmitStatus();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= Skinize;
		Own.LocaleChanged -= SetTitle;
		Server.Terminated -= Close;
		Server.TitleChanged -= SetTitle;
		Server.ChanListed -= SyncAddSingleChanItem;
		Server.ChanListStarted -= SyncAdmitStart;
		Server.ChanListFinished -= SyncAdmitFinish;
		Server.WelcomedChanged -= SyncAdmitStatus;
		
		base.Dispose(disposing);
	}
	
	
	void SyncAdmitStart () { this.Sync(AdmitStart); }
	void AdmitStart ()
	{
		list.Items.Clear();
		SetTitle();
	}
	
	void SyncAdmitFinish () { this.Sync(AdmitFinish); }
	void AdmitFinish ()
	{
		SetTitle();
	}
	
	void SyncAdmitStatus () { this.Sync(AdmitStatus); }
	void AdmitStatus ()
	{
		SetTitle();
	}
	
	void SyncAddSingleChanItem (Server.ChanListItem c) { this.Sync(()=>AddSingleChanItem(c)); }
	void AddSingleChanItem (Server.ChanListItem c)
	{
		list.BeginUpdate();
		AddChanItem(c);
		list.EndUpdate();
	}
	
	void AddChanItem (Server.ChanListItem c)
	{
		ListViewItem l = new ListViewItem(c.Name, c.Name);
		l.SubItems.Add(c.Users.ToString());
		l.SubItems.Add(c.Topic.StripFormatting());
		list.Items.Add(l);
		SetTitle();
	}
	
	
	
	void Start ()
	{
		Server.Send("LIST");
	}
	
	void Reload ()
	{
		if (Server.ChanListInProgress) return;
		list.Items.Clear();
		Start();
	}
	
	
	public static void Open (Server s)
	{
		if (!Open("Servers\\" + s.ID + "\\ChanList")) Open(new ChanList(s));
	}
	
	void Skinize ()
	{
		Icon = Own.Icon("ChanList");
	}
	
	void SetTitle ()
	{
		string t = Server.ChanListInProgress ? "%0 list (%1…)" : "%0 list (%1)";
		Text = Own.Line(t, Server.Title, list.Items.Count.ToString());
	}
}