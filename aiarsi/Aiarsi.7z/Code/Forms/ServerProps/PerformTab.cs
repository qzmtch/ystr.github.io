using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;

class PerformTab : ServerTab
{
	Field perField = new Field();
	
	public PerformTab (Server s, string title) : base (s, title)
	{
		perField.Multiline = true;
		perField.Dock = DockStyle.Fill;
		Controls.Add(perField);
		
		if (Server != null)
		{
			perField.Lines = Server.Perform;
		}
		
		perField.Submitted += () => Submitted();
	}
	
	public override void Save (Server s)
	{
		s.Perform = perField.Lines;
	}
	
	public event Action Submitted;
}