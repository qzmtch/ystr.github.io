using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;

class MainTab : ServerTab
{
	Group conGroup = new Group("Connection");
	Table conTable = new Table();
	Lable hostLable = new Lable("Host:");
	Field hostField = new Field();
	Lable portLable = new Lable("Port:");
	Field portField = new Field();
	Lable encodingLable = new Lable("Encoding:");
	SortedDictionary<string, Encoding> encodings = new SortedDictionary<string, Encoding>();
	ComboBox encodingCombo = new ComboBox();
	
	Group idGroup = new Group("Identity");
	Table idTable = new Table();
	Lable nickLable = new Lable("Nick(s):");
	Field nickField = new Field();
	Lable passLable = new Lable("Password:");
	Field passField = new Field();
	Lable userLable = new Lable("Username:");
	Field userField = new Field();
	Label fullLable = new Lable("Full name:");
	Field fullField = new Field();
	
	public MainTab (Server s, string title) : base (s, title)
	{
		nickField.AllowEmpty = false;
		passField.AllowEmpty = true;
		userField.AllowEmpty = false;
		fullField.AllowEmpty = false;
		
		idTable[0,0] = nickLable; idTable[1,0] = nickField;
		idTable[0,1] = passLable; idTable[1,1] = passField;
		idTable[0,2] = userLable; idTable[1,2] = userField;
		idTable[0,3] = fullLable; idTable[1,3] = fullField;
		
		hostField.AllowEmpty = false;
		portField.AllowEmpty = false;
		portField.IntegerOnly = true;
		portField.Min = 1; portField.Max = 65536;
		
		encodingCombo.Dock = DockStyle.Fill;
		encodingCombo.DropDownStyle = ComboBoxStyle.DropDownList;
		
		EncodingInfo[] eis = Encoding.GetEncodings();
		foreach (EncodingInfo ei in eis) encodings[ei.DisplayName] = Encoding.GetEncoding(ei.CodePage);
		foreach (string e in encodings.Keys) encodingCombo.Items.Add(e);
		
		Encoding enc = (Server == null) ? Encoding.UTF8 : Server.Encoding;
		encodingCombo.SelectedIndex = encodingCombo.FindStringExact(enc.EncodingName);
		
		conTable[0,0] = hostLable; conTable[1,0] = hostField;
		conTable[0,1] = portLable; conTable[1,1] = portField;
		conTable[0,2] = encodingLable; conTable[1,2] = encodingCombo;
		
		conGroup.Controls.Add(conTable);
		idGroup.Controls.Add(idTable);
		
		Controls.Add(new Vertable(conGroup, idGroup));
		
		if (Server != null)
		{
			hostField.Text = Server.Host;
			portField.Text = Server.Port.ToString();
			nickField.List = Server.InitialNicks;
			passField.Text = Server.Password;
			userField.Text = Server.UserName;
			fullField.Text = Server.FullName;
		}
		
		hostField.Check();
		portField.Check();
		nickField.Check();
		passField.Check();
		userField.Check();
		fullField.Check();
		
		hostField.Checked += Check;
		portField.Checked += Check;
		nickField.Checked += Check;
		passField.Checked += Check;
		userField.Checked += Check;
		fullField.Checked += Check;
		
		hostField.Submitted += () => Submitted();
		portField.Submitted += () => Submitted();
		nickField.Submitted += () => Submitted();
		passField.Submitted += () => Submitted();
		userField.Submitted += () => Submitted();
		fullField.Submitted += () => Submitted();
	}
	
	public void Check ()
	{
		Okay =
		(
			hostField.Okay &&
			portField.Okay &&
			nickField.Okay &&
			passField.Okay &&
			userField.Okay &&
			fullField.Okay
		);
		
		if (Checked != null) Checked();
	}
	
	public override void Save (Server s)
	{
		s.Host = hostField.Text;
		s.Port = Convert.ToInt32(portField.Text);
		s.Encoding = encodings[encodingCombo.Text];
		s.InitialNicks = nickField.List;
		s.Password = passField.Text;
		s.UserName = userField.Text;
		s.FullName = fullField.Text;
	}
	
	public bool Okay;
	public event Action Checked;
	public event Action Submitted;
}