using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Reflection;

class Roster : Window
{
	ToolBar bar = new ToolBar();
	ToolBarKnob addServerBtn = new ToolBarKnob("AddServer", "New Server", "Ctrl + N");
	ToolBarKnob settingsBtn = new ToolBarKnob("Settings", "Settings", "F12");
	
	ServerList list = new ServerList();
	
	public Roster () : base ("Roster")
	{
		MaximizeBox = false;
		
		addServerBtn.Clicked += ServerProps.New;
		settingsBtn.Clicked += Settings.Open;
		
		settingsBtn.Alignment = ToolStripItemAlignment.Right;
		
		bar.Items.Add(addServerBtn);
		bar.Items.Add(settingsBtn);
		
		Controls.Add(bar);
		
		list.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
		list.Location = new Point(0, bar.Height);
		list.Size = new Size(ClientSize.Width, ClientSize.Height - list.Location.Y);
		list.BorderStyle = BorderStyle.Fixed3D;
		Controls.Add(list);
		
		KeyDown += (o, e) =>
		{
			e.Handled = true;
			
			switch (e.KeyCode)
			{
				case Keys.N: if (e.Control) ServerProps.New(); return;
				case Keys.Up: list.SelectNext(-1); return;
				case Keys.Down: list.SelectNext(+1); return;
				
				case Keys.Tab: {
					if (e.Shift) {
						list.SetExpandedAll(false);
						return;
					}
				} break;
			}
			
			if (list.SelectedChat != null) list.SelectedChat.Key(e);
			else if (list.SelectedServer != null) list.SelectedServer.Key(e);
		};
		
		Settings.Changed += ApplySettings;
		Own.SkinChanged += Skinize;
		
		ApplySettings();
		Skinize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Settings.Changed -= ApplySettings;
		Own.SkinChanged -= Skinize;
		
		base.Dispose(disposing);
	}
	
	
	static Roster the = null;
	public static Roster The { get { return the; } }
	
	static bool minimizing = false;
	
	public static void ShowRoster ()
	{
		the = new Roster();
		
		the.Resize += (o, e) =>
		{
			if (the != null && the.Minimized && !Settings.InTaskbar)
			{
				minimizing = true;
				the.Close();
			}
		};
		
		the.Disposed += (o, e) =>
		{
			if (minimizing) minimizing = false;
			else if (!Settings.CloseToTray) Application.Exit();
			the = null;
		};
		
		the.Activated += (o, e) => Notify.ClearAsterisks();
		
		the.Show();
		the.Activate();
	}
	
	static public void CloseToTray ()
	{
		minimizing = true;
		the.Close();
	}
	
	
	void ApplySettings ()
	{
		Text = Settings.RosterTitle;
		MinimizeBox = Settings.ShowMinimizeButton;
		ShowInTaskbar = Settings.InTaskbar;
	}
	
	protected override Size DefaultSize {
		get {
			return new Size(220, 400);
		}
	}
	
	void Skinize ()
	{
		Icon = Own.Icon("Main");
	}
}