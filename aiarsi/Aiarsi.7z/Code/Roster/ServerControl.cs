using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;

class ServerControl : RosterControl
{
	public readonly Server Server;
	
	ContextMenu menu = new ContextMenu();
	MenuRow addRow = new MenuRow("Add", "Add/Join", "Ctrl + J");
	MenuRow listRow = new MenuRow("ChanList", "List channels", "Ctrl + L");
	MenuRow consoleRow = new MenuRow("Console", "Console", "Enter", true);
	MenuRow debugRow = new MenuRow("Debug", "Debug", "Shift + Enter");
	MenuRow deleteRow = new MenuRow("Delete", "Delete", "Del");
	MenuRow propsRow = new MenuRow("ServerProps", "Properties", "Ctrl + Enter");
	
	RosterKnob expandButton = new RosterKnob("", "", "Tab");
	RosterKnob autoButton = new RosterKnob("A", "Auto");
	RosterKnob connectButton = new RosterKnob("C");
	
	public Panel Sub = new Panel();
	Field addJoinField = new Field();
	
	bool expanded;
	public bool Expanded {
		get { return expanded; }
		set { expanded = value; Reload(); }
	}
	
	public ServerControl (Server s) : base (s.Title)
	{
		Server = s;
		
		ContextMenuStrip = menu;
		
		menu.Items.Add(addRow);
		menu.Items.Add(listRow);
		menu.AddSeparator();
		menu.Items.Add(consoleRow);
		menu.Items.Add(debugRow);
		menu.AddSeparator();
		menu.Items.Add(deleteRow);
		menu.Items.Add(propsRow);
		
		addRow.Clicked += ShowAddJoin;
		listRow.Clicked += ShowChanList;
		consoleRow.Clicked += ShowConsole;
		debugRow.Clicked += ShowDebug;
		propsRow.Clicked += ShowProps;
		deleteRow.Clicked += Delete;
		
		addJoinField.Visible = false;
		addJoinField.Dock = DockStyle.Bottom;
		addJoinField.AllowEmpty = false;
		addJoinField.Disallow = new char [] { ' ', ',' };
		Controls.Add(addJoinField);
		addJoinField.Check();
		
		expandButton.NormalImage = "Collapsed";
		expandButton.CheckedImage = "Expanded";
		
		Frame[0] = expandButton;
		Frame[2] = autoButton;
		Frame[3] = connectButton;
		
		expandButton.Clicked += ToggleExpanded;
		autoButton.Clicked += ToggleAuto;
		connectButton.Clicked += ToggleConnected;
		
		DoubleClicked += ShowConsole;
		
		Server.TitleChanged += RevealTitle;
		Server.ChannelsChanged += SyncReload;
		Server.QueriesChanged += SyncReload;
		Server.Link.StatusChanged += SyncRevealState;
		Server.WelcomedChanged += SyncRevealState;
		Server.AutoChanged += SyncRevealAuto;
		Server.Log.UnreadChanged += SyncRevealUnread;
		
		Sub.BackColor = SystemColors.Control;
		Sub.Dock = DockStyle.Bottom;
		Sub.AutoSize = true;
		Controls.Add(Sub);
		
		expanded = Server.Options.Get("Expanded", true);
		
		Reload();
		
		SelectedChanged += HideAddJoin;
		
		RevealUnread();
		RevealState();
		RevealAuto();
	}
	
	protected override void Dispose (bool disposing)
	{
		Server.ChannelsChanged -= SyncReload;
		Server.QueriesChanged -= SyncReload;
		Server.AutoChanged -= SyncRevealAuto;
		Server.WelcomedChanged -= SyncRevealState;
		Server.Link.StatusChanged -= SyncRevealState;
		Server.TitleChanged -= RevealTitle;
		Server.Log.UnreadChanged -= SyncRevealUnread;
		base.Dispose(disposing);
	}
	
	void RevealTitle ()
	{
		TitleLable.Text = Server.Title;
	}
	
	void SyncRevealUnread () { this.Sync(RevealUnread); }
	void RevealUnread ()
	{
		FontStyle ts = FontStyle.Bold;
		if (Server.Log.Unread.Has(Unread.Message)) ts |= FontStyle.Italic;
		TitleLable.Font = new Font(TitleLable.Font, ts);
	}
	
	void SyncRevealAuto () { this.Sync(RevealAuto); }
	void RevealAuto ()
	{
		autoButton.Checked = Server.AutoConnect;
	}
	
	
	void SyncRevealState () { this.Sync(RevealState); }
	void RevealState ()
	{
		if (
			Server.Link.Status == LinkStatus.Connecting ||
			(Server.Link.Status == LinkStatus.Connected && !Server.Welcomed) ||
			Server.Link.Status == LinkStatus.Disconnecting
		) connectButton.Text = "…";
		else connectButton.Text = "C";
		
		connectButton.Checked = (
			Server.Link.Status == LinkStatus.Connected ||
			Server.Link.Status == LinkStatus.Connecting
		);
		
		if (connectButton.Checked) connectButton.Tip = "Disconnect";
		else connectButton.Tip = "Connect";
		
		if (
			Server.Link.Status == LinkStatus.Disconnected && (
				Server.Link.OldStatus == LinkStatus.Connecting ||
				Server.Link.OldStatus == LinkStatus.Connected
			) && !Server.QuitByUser
		) connectButton.ForeColor = Color.Red;
		else connectButton.ForeColor = SystemColors.WindowText;
		
		listRow.Enabled = Server.Welcomed;
	}
	
	void ShowConsole () { ConsoleCom.Open(Server); }
	void ShowDebug () { DebugCom.Open(Server); }
	void ShowProps () { ServerProps.Open(Server); }
	void ShowChanList () { if (Server.Welcomed) ChanList.Open(Server); }
	
	void ToggleConnected ()
	{
		if (Server.Link.Status == LinkStatus.Disconnected) Server.ManualConnect();
		else Server.ManualQuit();
	}
	
	void ToggleAuto ()
	{
		Server.AutoConnect = !Server.AutoConnect;
	}
	
	void ToggleExpanded ()
	{
		Expanded = !Expanded;
		Server.Options.Set("Expanded", Expanded);
	}
	
	void Delete ()
	{
		if (Dialog.Delete(Server.Title)) Server.Zap(Server);
	}
	
	void ShowAddJoin ()
	{
		StartRedraw();
		addJoinField.Visible = true;
		FinishRedraw();
		addJoinField.Focus();
	}
	
	void HideAddJoin ()
	{
		if (!addJoinField.Visible) return;
		addJoinField.Visible = false;
		FindForm().ActiveControl = null;
		addJoinField.Clear();
	}
	
	void CancelAddJoin ()
	{
		StartRedraw();
		HideAddJoin();
		FinishRedraw();
	}
	
	void AddJoin ()
	{
		if (!addJoinField.Okay) return;
		
		string name = addJoinField.Text;
		
		StartRedraw();
		HideAddJoin();
		FinishRedraw();
		
		Chat nc = Server.Add(name);
		
		if (
			Server.Welcomed &&
			nc.GetType().Name == "Channel"
		) {
			Channel c = (Channel) nc;
			if (c.Status == ChannelStatus.Parted) c.Join();
		}
		
		Select(nc);
	}
	
	void Select (Chat sc)
	{
		foreach (ChatControl c in Sub.Controls)
		{
			if (c.Chat == sc)
			{
				c.SelectDirectly();
				return;
			}
		}
	}
	
	void SyncReload () { this.Sync(Reload); }
	void Reload ()
	{
		StartRedraw();
		
		if (expandButton.Checked = expanded) expandButton.Tip = "Collapse";
		else expandButton.Tip = "Expand";
		
		Sub.WipeControls();
		
		if (expanded)
		{
			foreach (Channel c in Server.ListChannels().Values)
			{
				ChannelControl cc = new ChannelControl(this, c);
				cc.Dock = DockStyle.Bottom;
				cc.RedrawStarted += StartRedraw;
				cc.RedrawFinished += FinishRedraw;
				Sub.Controls.Add(cc);
			}
			
			foreach (Query q in Server.ListQueries().Values)
			{
				QueryControl pc = new QueryControl(this, q);
				pc.Dock = DockStyle.Bottom;
				Sub.Controls.Add(pc);
			}
		}
		
		Reorganized();
		
		FinishRedraw();
	}
	
	public override void Key (KeyEventArgs e)
	{
		if (addJoinField.Visible)
		{
			switch (e.KeyCode)
			{
				case Keys.Escape: CancelAddJoin(); break;
				case Keys.Enter: AddJoin(); break;
				default: return;
			}
			
			e.SuppressKeyPress = true;
		}
		else switch (e.KeyCode)
		{
			case Keys.Enter:
				if (e.Shift) ShowDebug();
				else if (e.Control) ShowProps();
				else ShowConsole();
			break;
			
			case Keys.Tab: ToggleExpanded(); break;
			case Keys.A: ToggleAuto(); break;
			case Keys.C: ToggleConnected(); break;
			case Keys.Delete: Delete(); break;
			case Keys.Apps: ContextMenuStrip.Show(this, new Point(0, 0)); break;
			case Keys.J: if (e.Control) ShowAddJoin(); break;
			case Keys.L: if (e.Control) ShowChanList(); break;
		}
	}
	
	public event Action Reorganized = () => {};
}