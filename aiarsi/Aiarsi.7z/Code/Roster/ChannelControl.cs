using System;
using System.Drawing;
using System.Windows.Forms;

class ChannelControl : ChatControl
{
	public readonly Channel Channel;
	
	ContextMenu menu = new ContextMenu();
	MenuRow showRow = new MenuRow("Channel", "Open", "Enter", true);
	MenuRow keyRow = new MenuRow(null, "Key", "Ctrl + K");
	MenuRow deleteRow = new MenuRow("Delete", "Delete", "Del");
	
	RosterKnob autoKnob = new RosterKnob("A", "Auto");
	RosterKnob joinKnob = new RosterKnob("J");
	
	Field keyField = new Field();
	
	public ChannelControl (ServerControl parent, Channel c) : base (parent, c, c.Name)
	{
		Channel = c;
		
		ContextMenuStrip = menu;
		menu.Items.Add(showRow);
		menu.Items.Add(keyRow);
		menu.Items.Add(deleteRow);
		
		Frame[2] = autoKnob;
		Frame[3] = joinKnob;
		
		DoubleClicked += ShowCom;
		autoKnob.Clicked += ToggleAuto;
		joinKnob.Clicked += ToggleJoined;
		showRow.Clicked += ShowCom;
		keyRow.Clicked += ShowKey;
		deleteRow.Clicked += Delete;
		
		keyField.Visible = false;
		keyField.Dock = DockStyle.Bottom;
		keyField.Text = Channel.Options.Get("Key", "");
		Controls.Add(keyField);
		keyField.Check();
		
		keyField.TextChanged += (o, e) => {
			if (keyField.Okay) Channel.Key = keyField.Text;
		};
		
		Channel.AutoChanged += SyncRevealAuto;
		Channel.StatusChanged += SyncRevealState;
		Channel.ProblemChanged += SyncRevealState;
		Channel.Server.WelcomedChanged += SyncRevealState;
		
		SelectedChanged += HideKey;
		
		RevealState();
		RevealAuto();
	}
	
	protected override void Dispose (bool disposing)
	{
		Channel.AutoChanged -= SyncRevealAuto;
		Channel.StatusChanged -= SyncRevealState;
		Channel.ProblemChanged -= SyncRevealState;
		Channel.Server.WelcomedChanged -= SyncRevealState;
		
		menu.Dispose();
		
		base.Dispose(disposing);
	}
	
	void SyncRevealAuto () { this.Sync(RevealAuto); }
	void RevealAuto ()
	{
		autoKnob.Checked = Channel.AutoJoin;
	}
	
	
	void SyncRevealState () { this.Sync(RevealState); }
	void RevealState ()
	{
		joinKnob.Enabled = Channel.Server.Welcomed;
		
		joinKnob.Checked = (
			Channel.Status == ChannelStatus.Joining ||
			Channel.Status == ChannelStatus.Joined
		);
		
		if (
			Channel.Status == ChannelStatus.Joined ||
			Channel.Status == ChannelStatus.Parted
		) joinKnob.Text = "J";
		else joinKnob.Text = "…";
		
		if (joinKnob.Checked) joinKnob.Tip = "Part";
		else joinKnob.Tip = "Join";
		
		if (Channel.Problem != null) joinKnob.ForeColor = Color.Red;
		else joinKnob.ForeColor = SystemColors.WindowText;
	}
	
	void ShowCom ()
	{
		ChannelCom.Open(Channel);
	}
	
	void ShowKey ()
	{
		StartRedraw();
		keyField.Visible = true;
		FinishRedraw();
		keyField.Focus();
	}
	
	void HideKey ()
	{
		if (!keyField.Visible) return;
		keyField.Visible = false;
		FindForm().ActiveControl = null;
	}
	
	void CancelKey ()
	{
		StartRedraw();
		HideKey();
		FinishRedraw();
	}
	
	void ToggleAuto ()
	{
		Channel.AutoJoin = !Channel.AutoJoin;
	}
	
	void ToggleJoined ()
	{
		if (!Channel.Server.Welcomed) return;
		if (Channel.Status == ChannelStatus.Parted) Channel.Join();
		else Channel.Part();
	}
	
	void Delete ()
	{
		Channel.Server.ZapChannel(Channel);
	}
	
	public override void Key (KeyEventArgs e)
	{
		if (keyField.Visible)
		{
			switch (e.KeyCode)
			{
				case Keys.Escape: CancelKey(); break;
				case Keys.Enter: CancelKey(); break;
				default: return;
			}
			
			e.SuppressKeyPress = true;
		}
		else switch (e.KeyCode)
		{
			case Keys.A: ToggleAuto(); break;
			case Keys.J: ToggleJoined(); break;
			case Keys.K: if (e.Control) ShowKey(); break;
			case Keys.Enter: ShowCom(); break;
			case Keys.Apps: ContextMenuStrip.Show(this, new Point(0, 0)); break;
			case Keys.Delete: Delete(); break;
			default: Parent.Key(e); break;
		}
	}
}