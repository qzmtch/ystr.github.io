using System;
using System.Drawing;
using System.Windows.Forms;

class RosterKnob : CheckBox
{
	string text;
	string tipText;
	string keys;
	
	void Localize ()
	{
		Text = text;
		Tip = tipText;
	}
	
	void Skinize ()
	{
		if (normalImageName != null) normalImage = Own.Image(normalImageName);
		if (checkedImageName != null) checkedImage = Own.Image(checkedImageName);
		
		Decorate();
	}
	
	string normalImageName = null;
	string checkedImageName = null;
	
	public string NormalImage { set { normalImageName = value; Skinize(); } }
	public string CheckedImage { set { checkedImageName = value; Skinize(); } }
	
	Image normalImage = null;
	Image checkedImage = null;
	
	ToolTip tip = null;
	public string Tip {
		set {
			if (tip != null) tip.Dispose(); tip = new ToolTip();
			tip.SetToolTip(this, Own.Line(tipText = value) + " (" + keys + ")");
		}
	}
	
	public override string Text {
		set {
			base.Text = Own.Line(text = value);
		}
	}
	
	public RosterKnob (string text) : this (text, text, text) {}
	public RosterKnob (string text, string tip) : this (text, tip, text) {}
	public RosterKnob (string text, string tip, string keys)
	{
		Text = text;
		this.keys = keys;
		Tip = tip;
		
		Appearance = Appearance.Button;
		Dock = DockStyle.Fill;
		Margin = new Padding(0);
		TextAlign = ContentAlignment.MiddleCenter;
		UseVisualStyleBackColor = true;
		TabStop = false;
		
		CheckedChanged += (o, e) => { Decorate(); };
		
		Own.SkinChanged += Skinize;
		Own.LocaleChanged += Localize;
		
		PreviewKeyDown += (o, e) => { e.IsInputKey = true; };
		Click += (o, e) => Clicked();
		
		Skinize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= Skinize;
		Own.LocaleChanged -= Localize;
		if (tip != null) tip.Dispose();
		base.Dispose(disposing);
	}
	
	void Decorate ()
	{
		if (Checked) {
			Font = new Font(Font, FontStyle.Bold);
			if (checkedImage != null) Image = checkedImage;
		} else {
			Font = new Font(Font, FontStyle.Regular);
			if (normalImage != null) Image = normalImage;
		}
	}
	
	public event Action Clicked = () => {};
}