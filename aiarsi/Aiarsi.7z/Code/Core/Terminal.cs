abstract class Terminal
{
	public readonly Log Log = new Log();
	
	public abstract void Send (Slash input);
	public abstract void Send (string input);
	
	public abstract void ProcessIncoming (Line l);
	public abstract void ProcessOutgoing (Line l);
}