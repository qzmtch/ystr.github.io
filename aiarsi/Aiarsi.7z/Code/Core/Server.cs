using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Text;
using Timer = System.Timers.Timer;
using System.Windows.Forms;


partial class Server : Terminal, IComparable
{
	public readonly string ID;
	public readonly Options Options;
	
	public Server (string id)
	{
		ID = id ?? Guid.NewGuid().ToString();
		Options = Options.Servers.Open(ID);
		
		title = Options.Get("Title", "");
		host = Options.Get("Host", "");
		port = Options.Get("Port", 0);
		encoding = Options.Get("Encoding", Encoding.UTF8);
		initialNicks = Options.Get("InitialNicks", new string[1]);
		currentNick = initialNicks[0];
		currentID = currentNick != null ? currentNick.ToID() : null;
		password = Options.Get("Password", "");
		userName = Options.Get("UserName", "");
		fullName = Options.Get("FullName", "");
		quitLine = Options.Get("QuitLine", "");
		autoConnect = Options.Get("AutoConnect", false);
		perform = Options.Get("Perform", new string[0]);
		
		Link.StatusChanged += HandleStatus;
		Link.DataReceived += Receive;
		
		reconnectTimer.Elapsed += (o, e) => { Connect(); reconnectTimer.Stop(); };
		suppressTimer.Elapsed += (o, e) => { suppressNotify = false; suppressTimer.Stop(); };
		
		string[] cs = Options.Open("Channels").ListUnescapedKeys();
		foreach (string chan in cs) channels.Add(chan, new Channel(this, chan));
		
		string[] qs = Options.Open("Queries").ListUnescapedKeys();
		foreach (string query in qs) queries.Add(query, new Query(this, query));
		
		TitleChanged += SetLogWriters;
		SetLogWriters();
		
		NetworkChange.NetworkAvailabilityChanged += (o, e) => {
			if (e.IsAvailable) ResetAutoConnect();
		};
		
		if (autoConnect) Connect();
	}
	
	
	#region Unread
		
		object unreadLock = new object();
		Unread unreadItems = Unread.None;
		public Unread UnreadItems { get { lock (unreadLock) return unreadItems; } }
		public event Action UnreadItemsChanged = () => {};
		
		public void ScanUnreadItems ()
		{
			lock (unreadLock)
			{
				Unread nu = Unread.None;
				
				lock (channels) foreach (Channel c in channels.Values) nu |= c.Log.Unread;
				lock (queries) foreach (Query q in queries.Values) nu |= q.Log.Unread;
				
				if (nu == unreadItems) return;
				unreadItems = nu;
			}
			
			UnreadItemsChanged();
		}
		
	#endregion
	
	
	#region Items
		
		public event Action QueriesChanged = () => {};
		public event Action ChannelsChanged = () => {};
		
		
		readonly SortedDictionary<string, Channel> channels = new SortedDictionary<string, Channel>();
		readonly SortedDictionary<string, Query> queries = new SortedDictionary<string, Query>();
		
		
		public SortedDictionary<string, Channel> ListChannels ()
		{
			lock (channels)
			{
				return new SortedDictionary<string, Channel>(channels);
			}
		}
		
		public SortedDictionary<string, Query> ListQueries ()
		{
			lock (queries)
			{
				return new SortedDictionary<string, Query>(queries);
			}
		}
		
		
		bool ToChannel (string target, Line il) { return ToChannel(target, il, false); }
		bool ToChannel (string target, Line il, bool create)
		{
			string id = target.ToID();
			
			Channel tgt = null;
			bool exists = create;
			bool added = false;
			
			lock (channels)
			{
				if (exists = channels.ContainsKey(id)) tgt = channels[id];
				else if (added = exists = create) {
					channels.Add(id, tgt = new Channel(this, target, true));
				}
			}
			
			if (added) ChannelsChanged();
			
			if (exists) {
				if (il.In) tgt.ProcessIncoming(il);
				else tgt.ProcessOutgoing(il);
			}
			
			return exists;
		}
		
		bool ToQuery (string target, Line il) { return ToQuery(target, il, false); }
		bool ToQuery (string target, Line il, bool create)
		{
			string id = target.ToID();
			
			Query tgt = null;
			bool exists = create;
			bool added = false;
			
			lock (queries)
			{
				if (exists = queries.ContainsKey(id)) tgt = queries[id];
				else if (added = exists = create) {
					queries.Add(id, tgt = new Query(this, target));
				}
			}
			
			if (added) QueriesChanged();
			
			if (exists) {
				if (il.In) tgt.ProcessIncoming(il);
				else tgt.ProcessOutgoing(il);
			}
			
			return exists;
		}
		
		
		void ToAllChannels (Line il)
		{
			foreach (Channel c in ListChannels().Values)
			{
				c.ProcessIncoming(il);
			}
		}
		
		
		public Chat Add (string name)
		{
			if (name.HasChanPrefix()) return AddChannel(name);
			else return AddQuery(name);
		}
		
		public Channel AddChannel (string name)
		{
			string id = name.ToID();
			Channel nc = null;
			
			lock (channels)
			{
				if (channels.ContainsKey(id)) return channels[id];
				channels.Add(id, nc = new Channel(this, name));
			}
			
			ChannelsChanged();
			return nc;
		}
		
		public Query AddQuery (string name)
		{
			string id = name.ToID();
			Query nq = null;
			
			lock (queries)
			{
				if (queries.ContainsKey(id)) return queries[id];
				queries.Add(id, nq = new Query(this, name));
			}
			
			QueriesChanged();
			return nq;
		}
		
		
		public void ZapChannel (Channel c)
		{
			lock (channels) channels.Remove(c.ID);
			ChannelsChanged();
			ScanUnreadItems();
			c.Terminate();
			Options.ZapKey("Channels\\" + Options.Escape(c.ID));
		}
		
		public void ZapQuery (Query q)
		{
			lock (queries) queries.Remove(q.ID);
			QueriesChanged();
			ScanUnreadItems();
			q.Terminate();
			Options.ZapKey("Queries\\" + Options.Escape(q.ID));
		}
		
		
		public static void Cleanup ()
		{
			foreach (Server s in List)
			{
				foreach (Query q in s.ListQueries().Values)
				{
					if (!q.Keep) s.ZapQuery(q);
				}
			}
		}
		
	#endregion
	
	
	#region Properties
		
		string title;
		public event Action TitleChanged = () => {};
		public string Title {
			get { return title; }
			set { Options.Set("Title", title = value); TitleChanged(); }
		}
		
		string host;
		public string Host {
			get { return host; }
			set { Options.Set("Host", host = value); }
		}
		
		int port;
		public int Port {
			get { return port; }
			set { Options.Set("Port", port = value); }
		}
		
		Encoding encoding;
		public Encoding Encoding {
			get { return encoding; }
			set { Options.Set("Encoding", encoding = value); }
		}
		
		string password;
		public string Password {
			get { return password; }
			set { Options.Set("Password", password = value); }
		}
		
		string userName;
		public string UserName {
			get { return userName; }
			set { Options.Set("UserName", userName = value); }
		}
		
		string fullName;
		public string FullName {
			get { return fullName; }
			set { Options.Set("FullName", fullName = value); }
		}
		
		string quitLine;
		public string QuitLine {
			get { return quitLine; }
			set { Options.Set("QuitLine", quitLine = value); }
		}
		
		string[] perform;
		public string[] Perform {
			get { return perform; }
			set { Options.Set("Perform", perform = value); }
		}
		
	#endregion
	
	
	#region Listing
		
		readonly List<ChanListItem> chanList = new List<ChanListItem>();
		public ChanListItem[] GetListedChans () { lock (chanList) { return chanList.ToArray(); } }
		public int ListedChansCount { get { lock (chanList) return chanList.Count; } }
		
		bool chanListInProgress = false;
		public bool ChanListInProgress { get { return chanListInProgress; } }
		
		public event Action ChanListStarted = () => {};
		public event Action ChanListFinished = () => {};
		public event ChanListItemHandler ChanListed = (c) => {};
		
		void StartChanList ()
		{
			lock (chanList)
			{
				if (chanListInProgress) return;
				chanList.Clear();
				chanListInProgress = true;
			}
			
			ChanListStarted();
		}
		
		void ListChannel (string name, string users, string topic)
		{
			ChanListItem c = new ChanListItem(name, users, topic);
			lock (chanList) chanList.Add(c);
			ChanListed(c);
		}
		
		void FinishChanList ()
		{
			chanListInProgress = false;
			ChanListFinished();
		}
		
		void ResetChanList ()
		{
			chanListInProgress = false;
			chanList.Clear();
		}
		
		public class ChanListItem
		{
			public readonly string Name;
			public readonly int Users;
			public readonly string Topic;
			
			public ChanListItem (string name, string users, string topic)
			{
				Name = name;
				Users = int.Parse(users);
				Topic = topic;
			}
		}

		public delegate void ChanListItemHandler (ChanListItem c);
		
	#endregion
	
	
	#region Infra
		
		public static readonly List<Server> List = new List<Server>();
		
		public static event Action ListChanged = () => {};
		public event Action Terminated = () => {};
		
		public static void Initialize ()
		{
			string[] ids = Options.Servers.ListKeys();
			foreach (string id in ids) List.Add(new Server(id));
			List.Sort();
		}
		
		public static void Add (Server s)
		{
			List.Add(s);
			List.Sort();
			ListChanged();
		}
		
		public static void Zap (Server s)
		{
			List.Remove(s);
			s.Terminate();
			ListChanged();
		}
		
		void Terminate ()
		{
			Terminated();
			Options.Servers.ZapKey(ID);
		}
		
		public int CompareTo (object to)
		{
			return Title.CompareTo(((Server)to).Title);
		}
		
	#endregion
	
	
	#region Flow
		
		bool suppressNotify = false;
		Timer suppressTimer = new Timer(5000);
		
		bool welcomed = false;
		public bool Welcomed { get { return welcomed; } }
		public event Action WelcomedChanged = () => {};
		
		void SetWelcomed (bool w)
		{
			if (w == welcomed) return;
			welcomed = w; WelcomedChanged();
		}
		
		
		int autoConnectCount = 0;
		Timer reconnectTimer = new Timer(1000);
		
		bool autoConnect;
		public event Action AutoChanged = () => {};
		public bool AutoConnect {
			get { return autoConnect; }
			set {
				Options.Set("AutoConnect", autoConnect = value);
				reconnectTimer.Stop();
				AutoChanged();
			}
		}
		
		public void ResetAutoConnect ()
		{
			autoConnectCount = 0;
			reconnectTimer.Interval = 1000;
		}
		
		
		void HandleStatus ()
		{
			string msg = null;
			
			ResetChanList();
			
			switch (Link.Status)
			{
				case LinkStatus.Connected:
					msg = Own.Line("Connected.");
					if (Settings.SuppressWelcomes) suppressNotify = true;
				break;
				
				case LinkStatus.Connecting: msg = Own.Line("Connecting to %0…", Host); break;
				case LinkStatus.Disconnecting: msg = Own.Line("Disconnecting…"); break;
				case LinkStatus.Disconnected:
					
					if (quitByUser) msg = Own.Line("Disconnected.");
					else
					{
						string le = Link.LastError.Message;
						
						if (Link.OldStatus == LinkStatus.Connecting) {
							if (le != "") msg = Own.Line("Unable to connect (%0).", le);
							else msg = Own.Line("Unable to connect.");
							if (Settings.ErrorsNotify && autoConnectCount == 3) this.Announce(NotifyType.Error, Title, msg);
						} else {
							if (le != "") msg = Own.Line("Disconnected (%0).", le);
							else msg = Own.Line("Disconnected.");
							if (Settings.ErrorsNotify) this.Announce(NotifyType.Error, Title, msg);
						}
						
						msg += "\n";
					}
					
				break;
			}
			
			Entry se = new Entry(LogTag.Client);
			se.Add(msg);
			
			DebugLog.Push(se);
			Log.Push(se);
			
			switch (Link.Status)
			{
				case LinkStatus.Connected:
					Send("NICK " + currentNick);
					Send("USER " + userName + " 8 * :" + fullName);
				break;
				
				case LinkStatus.Disconnecting:
				case LinkStatus.Disconnected: SetWelcomed(false); break;
			}
			
			if (Link.Status == LinkStatus.Disconnected)
			{
				if (!quitByUser && autoConnect)
				{
					autoConnectCount++;
					reconnectTimer.Interval *= 2;
					reconnectTimer.Start();
				}
			}
		}
		
		
		bool quitByUser = false;
		public bool QuitByUser { get { return quitByUser; } }
		
		public void ManualQuit ()
		{
			quitByUser = true;
			if (Link.Status == LinkStatus.Connecting) Link.Disconnect();
			else if (Welcomed) {
				if (quitLine == "") Send("QUIT");
				else Send("QUIT :" + quitLine);
			} else if (Link.Status == LinkStatus.Connected) Link.Disconnect();
		}
		
		public void ManualConnect ()
		{
			ResetAutoConnect();
			Connect();
		}
		
		void Connect ()
		{
			nickIndex = 0;
			currentNick = initialNicks[0];
			quitByUser = false;
			Link.Connect(host, port);
		}
		
		
		void PerformPerform ()
		{
			foreach (string p in Perform)
			{
				if (p.Length > 0) Send(p);
			}
		}
		
	#endregion
	
	
	#region Nick
		
		object nickLock = new object();
		
		string[] initialNicks;
		public string[] InitialNicks {
			get { lock (nickLock) return initialNicks; }
			set { lock (nickLock) Options.Set("InitialNicks", initialNicks = value); }
		}
		
		int nickIndex = 0;
		
		string currentNick;
		string currentID;
		
		public string CurrentID { get { lock (nickLock) return currentID; } }
		public string CurrentNick { get { lock (nickLock) return currentNick; } }
		
		public event Action CurrentNickChanged = () => {};
		
		void SetCurrentNick (string n)
		{
			string id = n.ToID();
			
			lock (nickLock)
			{
				if (id == currentID) return;
				currentNick = n; currentID = id;
			}
			
			CurrentNickChanged();
		}
		
		void TryAnotherNick ()
		{
			string nnick = "";
			
			lock (nickLock)
			{
				nickIndex++;
				
				if (nickIndex >= initialNicks.Length) {
					Random rnd = new Random();
					const string ncs = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQSTUVWXYZ";
					for (int i = 0; i < 8; i++) nnick += ncs[rnd.Next(0, ncs.Length)];
				} else nnick = initialNicks[nickIndex];
			}
			
			Send("NICK " + nnick);
		}
		
	#endregion
	
	
	#region Logs
		
		public readonly Log DebugLog = new Log();
		
		void LogDebugLine (LogTag tag, Line l)
		{
			if (
				Settings.HideRawKnown &&
				Irc.Known(l.Command)
			) return;
			
			switch (l.Command)
			{
				case Irc.PING:
				case Irc.PONG:
					if (Settings.HideRawPing) return;
				break;
				
				case Irc.PRIVMSG:
					if (Settings.HideRawPrivmsg) return;
				break;
				
				case Irc.RPL_LIST:
					if (Settings.HideRawList) return;
				break;
			}
			
			Entry de = new Entry(tag);
			if (l.Prefix != null) de.Add(Style.Get("RawPrefix"), ":" + l.Prefix + " ");
			de.Add(Style.Get("RawCommand"), l.RawCommand);
			if (l.PlainArgs != null) de.Add(Style.Get("RawParams"), " " + l.PlainArgs);
			if (l.Postfix != null) de.Add(Style.Get("RawPostfix"), " :" + l.Postfix);
			DebugLog.Push(de);
		}
		
		void SetLogWriters ()
		{
			Log.LogFile = Title.EscapeFileName() + ".log";
			DebugLog.LogFile = Title.EscapeFileName() + ".Debug.log";
		}
		
		
	#endregion
	
	
	#region Network
		
		public readonly Link Link = new Link();
		string receiveBuffer = "";
		
		void Receive (byte[] bu)
		{
			receiveBuffer += Decode(bu);
			
			if (
				receiveBuffer.Length > 0 &&
				receiveBuffer[receiveBuffer.Length - 1] == '\n'
			) {
				string[] lines = Split(receiveBuffer);
				foreach (string l in lines) ProcessIncoming(l);
				receiveBuffer = "";
			}
		}
		
		
		byte[] Encode (string s)
		{
			return Encoding.GetBytes(s);
		}
		
		string Decode (byte[] b)
		{
			return Encoding.GetString(b, 0, b.Length);
		}
		
		string[] Split (string s)
		{
			return s.TrimEnd('\n', '\r').Split (
				new string[] {"\r\n", "\n"}, StringSplitOptions.None
			);
		}
		
		
		public override void Send (string msg)
		{
			if (Slash.IsIt(msg))
			{
				Send(new Slash(msg));
				return;
			}
			
			ProcessOutgoing(msg);
			byte[] tos = Encode(msg + "\r\n");
			if (tos.Length > 512) throw new Irc.TooLongException(msg);
			Link.Send(tos);
		}
		
		void ProcessOutgoing (string raw)
		{
			Line l = new Line(raw, LineDirection.Outgoing);
			LogDebugLine(LogTag.RawOutgoing, l);
			ProcessOutgoing(l);
		}
		
		void ProcessIncoming (string raw)
		{
			Line l = new Line(raw, LineDirection.Incoming);
			LogDebugLine(LogTag.RawIncoming, l);
			
			try { ProcessIncoming(l); }
			
			#if DEBUG
				catch (Exception e) { Console.WriteLine(l.Plain + "\n" + e.ToString()); }
			#else
				catch { /* Who cares? */ }
			#endif
		}
		
	#endregion
	
	
	public override void Send (Slash s)
	{
		switch (s.Command)
		{
			case "CTCP":
				if (s.Post == null) break;
				Send(Line.Make("PRIVMSG", s.First, Line.Ctcp(s.Post)));
			break;
			
			case "JOIN":
				if (s.All == null) break;
				Send("JOIN " + (s.All.HasChanPrefix() ? s.All : "#" + s.All));
			break;
			
			case "MSG":
				if (s.Post == null) break;
				Send("PRIVMSG " + s.First + " :" + s.Post);
			break;
			
			case "MODE":
				if (s.First == null) break;
				Send("MODE " + CurrentNick + " " + s.First);
			break;
			
			case "NICK":
				if (s.All == null) break;
				Send("NICK " + s.All);
			break;
			
			case "NOTICE":
				if (s.Post == null) break;
				Send("NOTICE " + s.First + " :" + s.Post);
			break;
			
			case "QUIT":
				if (s.All == null) Send("QUIT");
				else Send("QUIT :" + s.All);
			break;
		}
	}
	
	public override void ProcessOutgoing (Line l)
	{
		switch (l.Command)
		{
			case Irc.LIST: StartChanList(); break;
			case Irc.NICK: if (!welcomed) SetCurrentNick(l.Args[0]); break;
			case Irc.QUIT: quitByUser = true; break;
			
			case Irc.NOTICE:
				if (l.CtcpCommand != null) break;
				Log.Push(LogTag.OutgoingNotice, "→ %0: %1", l.Args[0], l.Postfix);
			break;
			
			case Irc.PRIVMSG:
				
				if (
					l.CtcpCommand != null &&
					l.CtcpCommand != "ACTION"
				) break;
				
				if (l.Args[0].HasChanPrefix()) {
					if (ToChannel(l.Args[0], l)) break;
				} else if (ToQuery(l.Args[0], l)) break;
				
				Log.Push(LogTag.OutgoingSpeech, "→ %0: %1", l.Args[0], l.Postfix);
				
			break;
		}
	}
	
	public override void ProcessIncoming (Line l)
	{
		switch (l.Command)
		{
			case Irc.PING:
				Send(Line.Make("PONG", null, l.Postfix));
			break;
			
			case Irc.NOTICE:
				
				if (l.CtcpCommand != null)
				{
					switch (l.CtcpCommand)
					{
						case "PING":
							int dif = (int) DateTime.Now.Subtract(l.CtcpMessage.ParseUnixTime()).TotalSeconds;
							Log.Push(LogTag.Info, "%0 ping reply: %1 sec", l.From, dif.ToString());
						break;
						
						case "VERSION": Log.Push(LogTag.Info, "%0 version: %1", l.From, l.CtcpMessage); break;
						case "FINGER": Log.Push(LogTag.Info, "%0 finger: %1", l.From, l.CtcpMessage); break;
						case "TIME": Log.Push(LogTag.Info, "%0 time: %1", l.From, l.CtcpMessage); break;
					}
				}
				else
				{
					if (l.From == null) Log.Push(LogTag.IncomingNotice, l.Postfix);
					else if (l.Args[0].HasChanPrefix()) ToChannel(l.Args[0], l);
					else
					{
						Log.Push(LogTag.IncomingNotice, "%0: %1", l.From, l.Postfix);
						
						if (!suppressNotify)
						{
							if (Settings.NoticesInvitesNotify)
							{
								this.Announce(NotifyType.Info, l.From ?? Title, l.Postfix);
							}
							
							Log.Unread |= Unread.Message;
						}
					}
				}
				
			break;
			
			case Irc.MODE:
				if (l.Args.Length > 1 && l.Args[0].HasChanPrefix()) ToChannel(l.Args[0], l);
				else Log.Push(LogTag.Mode, "%0 sets %1 %2", l.From, l.Postfix, l.PlainArgs);
			break;
			
			case Irc.KICK:
				if (l.Args[1].ToID() == currentID) Log.Push(LogTag.Kick, "Kicked from %0 by %1 (%2)", l.Args[0], l.From, l.Postfix);
				ToChannel(l.Args[0], l);
			break;
			
			case Irc.ERROR:
			case Irc.ERR_USERSDONTMATCH:
			case Irc.ERR_ALREADYREGISTERED:
			case Irc.ERR_NICKTOOFAST:
				Log.Push(LogTag.Error, l.Postfix);
			break;
			
			case Irc.JOIN:
				ToChannel(l.Postfix ?? l.Args[0], l, true);
			break;
			
			case Irc.PART:
				ToChannel(l.Postfix ?? l.Args[0], l);
			break;
			
			case Irc.NICK:
				
				if (l.From.ToID() == currentID)
				{
					SetCurrentNick(l.Postfix);
					Log.Push(LogTag.Name, "Your nick is now %0", l.Postfix);
				}
				
				ToQuery(l.From, l);
				ToAllChannels(l);
				
			break;
			
			case Irc.PRIVMSG:
				
				if (
					l.CtcpCommand != null &&
					l.CtcpCommand != "ACTION"
				) {
					Log.Push(LogTag.Info, "%0 from %1", l.CtcpCommand, l.From);
					
					switch (l.CtcpCommand)
					{
						case "PING":
							Send(Line.Make("NOTICE", l.From, l.Postfix));
						break;
						
						case "VERSION":
							Send(
								Line.Make(
									"NOTICE", l.From,
									Line.Ctcp("VERSION Aiarsi " + Application.ProductVersion.ToString())
								)
							);
						break;
						
						case "TIME":
							Send(Line.Make("NOTICE", l.From, Line.Ctcp("TIME " + DateTime.Now.ToString())));
						break;
						
						case "FINGER":
							Send(Line.Make("NOTICE", l.From, Line.Ctcp("FINGER " + FullName)));
						break;
					}
				}
				else if (l.Args[0].HasChanPrefix()) ToChannel(l.Args[0], l);
				else ToQuery(l.From, l, true);
				
			break;
			
			case Irc.QUIT:
				ToAllChannels(l);
				ToQuery(l.From, l);
			break;
			
			case Irc.RPL_CHANNELMODEIS:
				Log.Push(LogTag.Info, "%0 modes: %1", l.Args[1], l.Args[2]);
			break;
			
			case Irc.RPL_CREATIONTIME:
				Log.Push(LogTag.Info, "%0 created on: %1", l.Args[1], l.Args[2].ParseUnixTime().ToString());
			break;
			
			case Irc.RPL_NAMREPLY:
				ToChannel(l.Args[2], l);
			break;
			
			case Irc.RPL_WELCOME:
				Log.Push(LogTag.Useless, l.Postfix);
				suppressTimer.Start();
				SetWelcomed(true);
				PerformPerform();
			break;
			
			case Irc.WTF_PLEASEWAIT:
			case Irc.RPL_YOURHOST:
			case Irc.RPL_CREATED:
			case Irc.RPL_MOTDSTART:
			case Irc.RPL_MOTD:
			case Irc.RPL_LUSERME:
			case Irc.RPL_LUSERCLIENT:
			case Irc.RPL_LOCALUSERS:
			case Irc.RPL_GLOBALUSERS:
				Log.Push(LogTag.Useless, l.Postfix);
			break;
			
			case Irc.RPL_UNAWAY:
			case Irc.RPL_NOWAWAY:
				Log.Push(LogTag.Info, l.Postfix);
			break;
			
			case Irc.RPL_LUSEROP:
			case Irc.RPL_LUSERUNKNOWN:
			case Irc.RPL_LUSERCHANNELS:
				Log.Push(LogTag.Useless, l.Args[1] + " " + l.Postfix);
			break;
			
			case Irc.RPL_NOTOPIC:
			case Irc.RPL_TOPIC:
			case Irc.RPL_TOPICWHOTIME:
				ToChannel(l.Args[1], l);
			break;
			
			case Irc.TOPIC:
				ToChannel(l.Args[0], l);
			break;
			
			case Irc.ERR_NOSUCHNICK:
				ToQuery(l.Args[1], l);
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
			break;
			
			case Irc.RPL_AWAY:
				ToQuery(l.Args[1], l);
				Log.Push(LogTag.Info, "%0 is away (%1)", l.Args[1], l.Postfix);
			break;
			
			case Irc.ERR_NICKNAMEINUSE:
			case Irc.ERR_ERRONEUSNICKNAME:
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
				if (!welcomed) TryAnotherNick();
			break;
			
			case Irc.ERR_WASNOSUCHNICK:
			case Irc.ERR_NOSUCHCHANNEL:
			case Irc.ERR_UNKNOWNCOMMAND:
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
			break;
			
			case Irc.ERR_CANNOTSENDTOCHAN:
			case Irc.ERR_KEYSET:
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
				ToChannel(l.Args[1], l);
			break;
			
			case Irc.ERR_USERONCHANNEL:
				Log.Push(LogTag.Error, "%0: %1 %2", l.Args[2], l.Args[1], l.Postfix);
				ToChannel(l.Args[2], l);
			break;
			
			case Irc.ERR_CHANNELISFULL:
			case Irc.ERR_INVITEONLYCHAN:
			case Irc.ERR_BANNEDFROMCHAN:
			case Irc.ERR_BADCHANNELKEY:
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
				ToChannel(l.Args[1], l);
				if (Settings.ErrorsNotify) this.Announce(NotifyType.Error, l.Args[1], l.Postfix);
			break;
			
			case Irc.ERR_CHANOPRIVSNEEDED:
				Log.Push(LogTag.Error, "%0: %1", l.Args[1], l.Postfix);
				ToChannel(l.Args[1], l);
			break;
			
			case Irc.RPL_WHOISUSER: Log.Push(LogTag.Info, "%0 is: %1", l.Args[1], l.PlainSub(2) + " " + l.Postfix); break;
			case Irc.RPL_WHOWASUSER: Log.Push(LogTag.Info, "%0 was: %1", l.Args[1], l.PlainSub(2) + " " + l.Postfix); break;
			case Irc.RPL_WHOISSERVER: Log.Push(LogTag.Info, "%0 server: %1 %2", l.Args[1], l.Args[2], l.Postfix); break;
			case Irc.RPL_WHOISCHANNELS: Log.Push(LogTag.Info, "%0 on: %1", l.Args[1], l.Postfix); break;

			case Irc.RPL_WHOISIDLE:
				
				DateTime signon = l.Args[3].ParseUnixTime();
				TimeSpan its = TimeSpan.FromSeconds(int.Parse(l.Args[2]));
				
				string idle = "";
				if (its.Days > 0) idle += " " + Own.Line("%0d", its.Days.ToString());
				if (its.Hours > 0) idle += " " + Own.Line("%0h", its.Hours.ToString());
				if (its.Minutes > 0) idle += " " + Own.Line("%0m", its.Minutes.ToString());
				if (its.Seconds > 0) idle += " " + Own.Line("%0s", its.Seconds.ToString());
				
				Log.Push(LogTag.Info, "%0 signed on: %1; idle:%2", l.Args[1], signon.ToString(), idle);
				
			break;
			
			case Irc.RPL_INVITING:
				Log.Push(LogTag.Info, "%0 was invited to %1", l.Args[1], l.Args[2]);
				ToChannel(l.Args[2], l);
			break;
			
			case Irc.INVITE:
				Entry e = Log.Push(LogTag.Info, "%0 invites you to %1", l.From, l.Postfix);
				if (Settings.NoticesInvitesNotify) this.Announce(NotifyType.Info, l.Postfix, e.Plain);
				Log.Unread |= Unread.Message;
			break;
			
			case Irc.RPL_LIST: ListChannel(l.Args[1], l.Args[2], l.Postfix); break;
			case Irc.RPL_LISTEND: FinishChanList(); break;
		}
	}
}