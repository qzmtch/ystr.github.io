class Slash
{
	public readonly string Raw;
	public readonly string Command;
	
	public readonly string All = null;
	public readonly string First = null;
	public readonly string Post = null;
	
	public Slash (string input)
	{
		Raw = input;
		
		string[] raws = Raw.Split(' ', 2);
		Command = raws[0].Substring(1).ToUpper();
		
		if (raws.Length > 1)
		{
			All = raws[1];
			string[] alls = All.Split(' ', 2);
			First = alls[0];
			
			if (alls.Length > 1)
			{
				Post = alls[1];
			}
		}
		
		switch (Command)
		{
			case "/": Command = "ME"; break;
			case "I": Command = "INVITE"; break;
			case "J": Command = "JOIN"; break;
			case "K": Command = "KICK"; break;
			case "M": Command = "MODE"; break;
			case "N": Command = "NICK"; break;
			case "P": Command = "PART"; break;
			case "T": Command = "TOPIC"; break;
			case "Q": Command = "QUERY"; break;
		}
	}
	
	public static bool IsIt (string s)
	{
		return s.StartsWith("/");
	}
}