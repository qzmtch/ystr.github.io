class User
{
	string id;
	string nick;
	string prefixed;
	string prefix;
	char? status;
	
	public string Nick
	{
		get { return nick; }
		set {
			nick = value;
			id = nick.ToID();
			prefixed = prefix + value;
		}
	}
	
	public char? Status
	{
		get { return status; }
		set {
			status = value;
			prefix = (value == null) ? "" : value.ToString();
			prefixed = prefix + nick;
		}
	}
	
	public string ID { get { return id; } }
	public string Prefixed { get { return prefixed; } }
	public string Prefix { get { return prefix; } }
	
	public User (string prefixed)
	{
		this.prefixed = prefixed;
		nick = Unprefix(prefixed);
		Status = GetPrefix(prefixed);
		id = nick.ToID();
	}
	
	public void ApplyMode (string m)
	{
		char sign = m[0];
		char mode = m[1];
		
		if (sign == '-')
		{
			if (status == '@' && mode == 'o') Status = null;
			if (status == '+' && mode == 'v') Status = null;
		}
		else
		{
			if (mode == 'v' && status == null) Status = '+';
			if (mode == 'o') Status = '@';
		}
	}
	
	public static char? GetPrefix (string u)
	{
		char first = u[0];
		if (first == '@' || first == '+') return first;
		else return null;
	}
	
	public static string Unprefix (string pre)
	{
		if (GetPrefix(pre) == null) return pre;
		else return pre.Substring(1);
	}
	
	public override string ToString ()
	{
		return prefixed;
	}
	
	public delegate void Action (User u);
}