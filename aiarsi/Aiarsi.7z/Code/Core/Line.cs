using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

enum LineDirection
{
	Incoming,
	Outgoing
}

class Line
{
	public readonly LineDirection Direction;
	public readonly bool In, Out;
	
	public readonly string Plain = null;
	
	public readonly string Prefix = null;
	public readonly string Command = null;
	public readonly string[] Args = null;
	public readonly string Postfix = null;
	
	public readonly string RawCommand = null;
	public readonly string ComArgs = null;
	public readonly string PlainArgs = null;
	
	public readonly string From = null;
	
	public readonly string CtcpPlain = null;
	public readonly string CtcpCommand = null;
	public readonly string CtcpMessage = null;
	
	static string GetFrom (string prefix)
	{
		if (prefix == null) return null;
		if (prefix.Contains("!")) return prefix.Substring(0, prefix.IndexOf("!"));
		else return prefix;
	}
	
	public static string Make (string com, string args, string post)
	{
		string l = com;
		if (args != null) l = l + " " + args;
		if (post != null) l = l + " :" + post;
		return l;
	}
	
	public static string Ctcp (string msg)
	{
		return "\u0001" + msg + "\u0001";
	}
	
	public Line (string raw, LineDirection dir)
	{
		Plain = raw;
		Direction = dir;
		
		In = (Direction == LineDirection.Incoming);
		Out = !In;
		
		int comArgsStart = 0;
		int comArgsEnd = raw.Length;
		
		if (raw.StartsWith(":"))
		{
			int prefixSep = raw.IndexOf(" ");
			Prefix = raw.Substring(1, prefixSep - 1);
			comArgsStart = prefixSep + 1;
		}
		
		if (raw.Contains(" :"))
		{
			comArgsEnd = raw.IndexOf(" :");
			Postfix = raw.Substring(comArgsEnd + 2);
		}
		
		ComArgs = raw.Substring(comArgsStart, comArgsEnd - comArgsStart);
		string[] cp = ComArgs.Split(' ');
		RawCommand = cp[0];
		Command = RawCommand.ToUpper();
		
		if (cp.Length > 1)
		{
			Args = new string[cp.Length - 1];
			Array.Copy(cp, 1, Args, 0, Args.Length);
			PlainArgs = string.Join(" ", Args);
		}
		
		From = GetFrom(Prefix);
		
		if (Postfix != null && Postfix.StartsWith("\u0001"))
		{
			CtcpPlain = Postfix.Trim('\u0001');
			string[] ctcp = CtcpPlain.Split(new char[]{' '}, 2);
			if (ctcp.Length > 0) CtcpCommand = ctcp[0];
			if (ctcp.Length > 1) CtcpMessage = ctcp[1];
		}
	}
	
	public string[] Sub (int fr, int to)
	{
		string[] sub = new string[to - fr + 1];
		Array.Copy(Args, fr, sub, 0, to - fr + 1);
		return sub;
	}
	
	public string[] Sub (int fr)
	{
		return Sub(fr, Args.Length - 1);
	}
	
	public string PlainSub (int fr, int to)
	{
		return string.Join(" ", Sub(fr, to));
	}
	
	public string PlainSub (int fr)
	{
		return string.Join(" ", Sub(fr));
	}
}