using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Text;

class ComTab : Tab
{
	public string BaseFont { get { return fontCombo.Text; } }
	public int FontSize { get { return (int) fontSizeNum.Value; } }
	public bool ShowTime { get { return timeCheck.Checked; } }
	public bool ShowSeconds { get { return secondsCheck.Checked; } }
	public bool SaveLogs { get { return saveCheck.Checked; } }
	public string LogRoot { get { return Settings.Portable ? Settings.LogRoot : pathField.Text; } }
	
	Table fontTable = new Table(0, 100, 0);
	Lable fontLable = new Lable("Font:");
	ComboBox fontCombo = new ComboBox();
	NumericUpDown fontSizeNum = new NumericUpDown();
	
	Group timeGroup = new Group("Time");
	Check timeCheck = new Check("Show timestamp");
	Check secondsCheck = new Check("Show seconds");
	
	Group fileGroup = new Group("Files");
	Check saveCheck = new Check("Save logs to this folder:");
	Table pathTable = new Table(100, 0);
	Field pathField = new Field();
	Knob browseKnob = new Knob("…");
	
	public ComTab () : base ("Logs")
	{
		timeCheck.Checked = Settings.ShowTime;
		secondsCheck.Checked = Settings.ShowSeconds;
		timeGroup.Controls.Add(new Vertable(timeCheck, secondsCheck));
		
		fontCombo.DropDownStyle = ComboBoxStyle.DropDownList;
		FontFamily[] fs = new InstalledFontCollection().Families;
		foreach (FontFamily f in fs) fontCombo.Items.Add(f.Name);
		int fi = fontCombo.FindStringExact(Settings.BaseFont);
		fontCombo.SelectedIndex = fi < 0 ? 0 : fi;
		
		fontSizeNum.Minimum = 8; fontSizeNum.Maximum = 32;
		fontSizeNum.Value = Settings.FontSize;
		fontSizeNum.AutoSize = true;
		
		saveCheck.Checked = Settings.SaveLogs;
		
		browseKnob.Size = new Size(pathField.Height, pathField.Height);
		
		browseKnob.Click += (o, e) =>
		{
			FolderBrowserDialog fb = new FolderBrowserDialog();
			if (fb.ShowDialog() == DialogResult.OK) pathField.Text = fb.SelectedPath;
		};
		
		pathTable.Put(pathField, browseKnob);
		fileGroup.Controls.Add(new Vertable(saveCheck, pathTable));
		
		fontTable.Put(fontLable, fontCombo, fontSizeNum);
		Controls.Add(new Vertable(fontTable, timeGroup, fileGroup));
		
		Settings.Changed += RevealLogPath;
		RevealLogPath();
	}
	
	protected override void Dispose (bool disposing)
	{
		Settings.Changed -= RevealLogPath;
		base.Dispose(disposing);
	}
	
	void RevealLogPath ()
	{
		pathField.Enabled = browseKnob.Enabled = !Settings.Portable;
		pathField.Text = Settings.Portable ? Own.Line("%0 (portable mode)", "Logs") : Settings.LogRoot;
	}
}