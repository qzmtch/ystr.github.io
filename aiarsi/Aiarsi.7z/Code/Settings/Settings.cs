using System;
using System.Drawing;
using System.Windows.Forms;

class Settings : UtilityWindow
{
	static string skin;
	static string locale;
	static bool closeToTray;
	static bool startHidden;
	static bool showMinimizeButton;
	static bool inTaskbar;
	static string rosterTitle;
	static string baseFont;
	static int fontSize;
	static bool showTime;
	static bool showSeconds;
	static bool saveLogs;
	static string logRoot;
	static bool notifySound;
	static bool notifyBalloon;
	static string[] highlightWords;
	static bool highlightNick;
	static bool watchNewQueries;
	static bool noticesInvitesNotify;
	static bool errorsNotify;
	static bool portable;
	static bool suppressWelcomes;
	static bool hideRawPing;
	static bool hideRawList;
	static bool hideRawPrivmsg;
	static bool hideRawKnown;
	
	public static string Skin { get { return skin; } }
	public static string Locale { get { return locale; } }
	public static bool CloseToTray { get { return closeToTray; } }
	public static bool StartHidden { get { return startHidden; } }
	public static bool ShowMinimizeButton { get { return showMinimizeButton; } }
	public static bool InTaskbar { get { return inTaskbar; } }
	public static string RosterTitle { get { return rosterTitle; } }
	public static string BaseFont { get { return baseFont; } }
	public static int FontSize { get { return fontSize; } }
	public static bool ShowTime { get { return showTime; } }
	public static bool ShowSeconds { get { return showSeconds; } }
	public static bool SaveLogs { get { return saveLogs; } }
	public static string LogRoot { get { return logRoot; } }
	public static bool NotifySound { get { return notifySound; } }
	public static bool NotifyBalloon { get { return notifyBalloon; } }
	public static string[] HighlightWords { get { return highlightWords; } }
	public static bool HighlightNick { get { return highlightNick; } }
	public static bool WatchNewQueries { get { return watchNewQueries; } }
	public static bool NoticesInvitesNotify { get { return noticesInvitesNotify; } }
	public static bool ErrorsNotify { get { return errorsNotify; } }
	public static bool Portable { get { return portable; } }
	public static bool SuppressWelcomes { get { return suppressWelcomes; } }
	public static bool HideRawPing { get { return hideRawPing; } }
	public static bool HideRawList { get { return hideRawList; } }
	public static bool HideRawPrivmsg { get { return hideRawPrivmsg; } }
	public static bool HideRawKnown { get { return hideRawKnown; } }
	
	TabControl tabs = new TabControl();
	
	AppTab appTab = new AppTab();
	ComTab commTab = new ComTab();
	NotifyTab notifyTab = new NotifyTab();
	MiscTab miscTab = new MiscTab();
	
	Table buttonsTable = new Table(33, 34, 33);
	Knob cancelBtn = new Knob("Cancel");
	Knob applyBtn = new Knob("Apply");
	Knob saveBtn = new Knob("Save");
	
	void Localize () { Text = Own.Line("Settings"); }
	void Skinize () { Icon = Own.Icon("Settings"); }
	
	Settings () : base(sig)
	{
		Skinize(); Own.SkinChanged += Skinize;
		Localize(); Own.LocaleChanged += Localize;
		
		Size = new Size(300, 420);
		
		tabs.Dock = DockStyle.Top;
		Controls.Add(tabs);
		
		buttonsTable.Dock = DockStyle.Bottom;
		Controls.Add(buttonsTable);
		
		cancelBtn.Click += (o, e) => { Load(); Changed(); Close(); };
		applyBtn.Click += (o, e) => { Apply(); Changed(); };
		saveBtn.Click += (o, e) => { Apply(); Changed(); Save(); Close(); };
		
		AcceptButton = saveBtn;
		saveBtn.Margin = new Padding(0);
		cancelBtn.Margin = applyBtn.Margin = new Padding(0, 0, 10, 0);
		
		buttonsTable.Put(cancelBtn, applyBtn, saveBtn);
		
		tabs.Height = buttonsTable.Top - tabs.Top - 10;
		tabs.Put(appTab, commTab, notifyTab, miscTab);
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.SkinChanged -= Skinize;
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
	
	void Apply ()
	{
		skin = appTab.Skin;
		locale = appTab.Locale;
		closeToTray = appTab.CloseToTray;
		startHidden = appTab.StartHidden;
		showMinimizeButton = appTab.ShowMinimizeButton;
		inTaskbar = appTab.InTaskbar;
		rosterTitle = appTab.RosterTitle;
		baseFont = commTab.BaseFont;
		fontSize = commTab.FontSize;
		showTime = commTab.ShowTime;
		showSeconds = commTab.ShowSeconds;
		saveLogs = commTab.SaveLogs;
		logRoot = commTab.LogRoot;
		notifySound = notifyTab.NotifySound;
		notifyBalloon = notifyTab.NotifyBalloon;
		highlightWords = notifyTab.HighlightWords;
		highlightNick = notifyTab.HighlightNick;
		watchNewQueries = notifyTab.WatchNewQueries;
		noticesInvitesNotify = notifyTab.NoticesInvitesNotify;
		errorsNotify = notifyTab.ErrorsNotify;
		portable = miscTab.Portable;
		suppressWelcomes = miscTab.SuppressWelcomes;
		hideRawPing = miscTab.HideRawPing;
		hideRawList = miscTab.HideRawList;
		hideRawPrivmsg = miscTab.HideRawPrivmsg;
		hideRawKnown = miscTab.HideRawKnown;
	}
	
	static new void Load ()
	{
		skin = Options.Root.Get("Skin", Own.DefaultSkin);
		locale = Options.Root.Get("Locale", Own.DefaultLocale);
		closeToTray = Options.Root.Get("CloseToTray", true);
		startHidden = Options.Root.Get("StartHidden", false);
		showMinimizeButton = Options.Root.Get("ShowMinimizeButton", false);
		inTaskbar = Options.Root.Get("InTaskbar", false);
		rosterTitle = Options.Root.Get("RosterTitle", "Aiarsi");
		baseFont = Options.Root.Get("BaseFont", "Courier New");
		fontSize = Options.Root.Get("FontSize", 10);
		showTime = Options.Root.Get("ShowTime", false);
		showSeconds = Options.Root.Get("ShowSeconds", true);
		saveLogs = Options.Root.Get("SaveLogs", false);
		logRoot = Options.Root.Get("LogRoot", "%UserProfile%\\Logs");
		notifySound = Options.Root.Get("NotifySound", true);
		notifyBalloon = Options.Root.Get("NotifyBalloon", true);
		highlightWords = Options.Root.Get("HighlightWords", new string[0]);
		highlightNick = Options.Root.Get("HighlightNick", true);
		watchNewQueries = Options.Root.Get("WatchNewQueries", true);
		noticesInvitesNotify = Options.Root.Get("NoticesInvitesNotify", false);
		errorsNotify = Options.Root.Get("ErrorsNotify", false);
		portable = Options.Portable;
		suppressWelcomes = Options.Root.Get("SuppressWelcomes", true);
		hideRawPing= Options.Root.Get("HideRawPing", true);
		hideRawList = Options.Root.Get("HideRawList", true);
		hideRawPrivmsg = Options.Root.Get("HideRawPrivmsg", false);
		hideRawKnown = Options.Root.Get("HideRawKnown", false);
	}
	
	static void Save ()
	{
		Options.Root.Set("Skin", skin);
		Options.Root.Set("Locale", locale);
		Options.Root.Set("CloseToTray", closeToTray);
		Options.Root.Set("StartHidden", startHidden);
		Options.Root.Set("ShowMinimizeButton", showMinimizeButton);
		Options.Root.Set("InTaskbar", inTaskbar);
		Options.Root.Set("RosterTitle", rosterTitle);
		Options.Root.Set("BaseFont", baseFont);
		Options.Root.Set("FontSize", fontSize);
		Options.Root.Set("ShowTime", showTime);
		Options.Root.Set("ShowSeconds", showSeconds);
		Options.Root.Set("SaveLogs", saveLogs);
		Options.Root.Set("LogRoot", logRoot);
		Options.Root.Set("NotifySound", notifySound);
		Options.Root.Set("NotifyBalloon", notifyBalloon);
		Options.Root.Set("HighlightWords", highlightWords);
		Options.Root.Set("HighlightNick", highlightNick);
		Options.Root.Set("WatchNewQueries", watchNewQueries);
		Options.Root.Set("NoticesInvitesNotify", noticesInvitesNotify);
		Options.Root.Set("ErrorsNotify", errorsNotify);
		Options.Root.Set("SuppressWelcomes", suppressWelcomes);
		Options.Root.Set("HideRawPing", hideRawPing);
		Options.Root.Set("HideRawList", hideRawList);
		Options.Root.Set("HideRawPrivmsg", hideRawPrivmsg);
		Options.Root.Set("HideRawKnown", hideRawKnown);
		Options.Portable = portable;
	}
	
	static Settings () { Load(); }
	public static void Open () { if (!Open(sig)) Open(new Settings()); }
	public static event Action Changed = () => {};
	const string sig = "Windows\\Settings";
}