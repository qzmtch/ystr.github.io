using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Text;

class AppTab : Tab
{
	public string Skin { get { return skinCombo.Text; } }
	public string Locale { get { return Own.GetLocaleCode(localeCombo.Text) ?? Own.DefaultLocale; } }
	
	Table table = new Table(0, 100);
	
	Lable skinLable = new Lable("Skin:");
	ComboBox skinCombo = new ComboBox();
	Lable localeLable = new Lable("Language:");
	ComboBox localeCombo = new ComboBox();
	
	Group rosterGroup = new Group("Main window");
	
	public bool CloseToTray { get { return closeCk.Checked; } }
	public bool StartHidden { get { return hiddenCk.Checked; } }
	public bool ShowMinimizeButton { get { return showMinCk.Checked; } }
	public bool InTaskbar { get { return inTaskbarCk.Checked; } }
	public string RosterTitle { get { return titleField.Text; } }
	
	Check closeCk = new Check("Close to tray");
	Check hiddenCk = new Check("Start hidden");
	Check showMinCk = new Check("Minimize button");
	Check inTaskbarCk = new Check("Show in Taskbar");
	
	Table titleTable = new Table(0, 100);
	Lable titleLable = new Lable("Title:");
	Field titleField = new Field();
	
	public AppTab () : base ("Appearance")
	{
		skinCombo.DropDownStyle = ComboBoxStyle.DropDownList;
		skinCombo.Items.AddRange(Own.ListSkins());
		int si = skinCombo.FindStringExact(Settings.Skin);
		skinCombo.SelectedIndex = si < 0 ? 0 : si;
		
		localeCombo.DropDownStyle = ComboBoxStyle.DropDownList;
		foreach (KeyValuePair<string, string> kv in Own.ListLocales()) localeCombo.Items.Add(kv.Value);
		int ti = localeCombo.FindStringExact(Own.GetLocaleName(Settings.Locale));
		localeCombo.SelectedIndex = ti < 0 ? 0 : ti;
		
		table[0,0] = skinLable; table[1,0] = skinCombo;
		table[0,1] = localeLable; table[1,1] = localeCombo;
		
		titleField.Text = Settings.RosterTitle;
		
		titleTable.Dock = DockStyle.Top;
		titleTable.AutoSize = true;
		titleTable.Put(titleLable, titleField);
		
		closeCk.Checked = Settings.CloseToTray;
		hiddenCk.Checked = Settings.StartHidden;
		showMinCk.Checked = Settings.ShowMinimizeButton;
		inTaskbarCk.Checked = Settings.InTaskbar;
		
		rosterGroup.Controls.Add(new Vertable(closeCk, hiddenCk, showMinCk, inTaskbarCk, titleTable));
		Controls.Add(new Vertable(rosterGroup, table));
	}
}