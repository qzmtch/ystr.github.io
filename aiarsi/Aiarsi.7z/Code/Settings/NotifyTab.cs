using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Text;

class NotifyTab : Tab
{
	public bool NotifySound { get { return soundCk.Checked; } }
	public bool NotifyBalloon { get { return balloonCk.Checked; } }
	public bool HighlightNick { get { return hiliNickCk.Checked; } }
	public bool WatchNewQueries { get { return watchNewQueriesCk.Checked; } }
	public bool NoticesInvitesNotify { get { return noticesInvitesCk.Checked; } }
	public bool ErrorsNotify { get { return errorsCk.Checked; } }
	public string[] HighlightWords { get { return hiliWordsField.List;} }
	
	Group watchGroup = new Group("Events");
	Check watchNewQueriesCk = new Check("Watch new queries");
	Check noticesInvitesCk = new Check("Notices and invites");
	Check errorsCk = new Check("Errors and problems");
	
	Group howGroup = new Group("How to notify");
	Check soundCk = new Check("Play sound");
	Check balloonCk = new Check("Show tray balloon");
	
	Group hiliGroup = new Group("Highlight words");
	Field hiliWordsField = new Field();
	Check hiliNickCk = new Check("My current nickname");
	
	public NotifyTab () : base ("Notify")
	{
		soundCk.Checked = Settings.NotifySound;
		balloonCk.Checked = Settings.NotifyBalloon;
		hiliNickCk.Checked = Settings.HighlightNick;
		watchNewQueriesCk.Checked = Settings.WatchNewQueries;
		noticesInvitesCk.Checked = Settings.NoticesInvitesNotify;
		errorsCk.Checked = Settings.ErrorsNotify;
		hiliWordsField.List = Settings.HighlightWords;
		
		watchGroup.Controls.Add(new Vertable(watchNewQueriesCk, noticesInvitesCk, errorsCk));
		howGroup.Controls.Add(new Vertable(soundCk, balloonCk));
		hiliGroup.Controls.Add(new Vertable(hiliWordsField, hiliNickCk));
		Controls.Add(new Vertable(howGroup, hiliGroup, watchGroup));
	}
}