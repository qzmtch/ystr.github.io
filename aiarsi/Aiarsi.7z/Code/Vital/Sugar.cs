using System;
using System.IO;

static class Sugar
{
	static readonly DateTime Epoch = new DateTime (
		1970, 1, 1, 0, 0, 0, DateTimeKind.Utc
	).ToLocalTime();
	
	static public string ToUnixString (this DateTime dt)
	{
		return ((int)(dt.Subtract(Epoch).TotalSeconds)).ToString();
	}
	
	static public DateTime ParseUnixTime (this string s)
	{
		return Epoch.AddSeconds(double.Parse(s));
	}
	
	static public bool Contains (this string hay, string needle, bool ignoreCase)
	{
		if (ignoreCase)
		{
			hay = hay.ToLower();
			needle = needle.ToLower();
		}
		
		return hay.Contains(needle);
	}
	
	static public bool Contains (this string hay, string[] needles)
	{
		return hay.Contains(needles, false);
	}
	
	static public bool Contains (this string hay, string[] needles, bool ignoreCase)
	{
		if (ignoreCase) hay = hay.ToLower();
		
		foreach (string n in needles)
		{
			if (
				!string.IsNullOrEmpty(n) &&
				hay.Contains(n.ToLower())
			) return true;
		}
		
		return false;
	}
	
	static public void Chop (this string s, Action<string> dosmth) { Chop (s, 255, dosmth); }
	static public void Chop (this string s, int cle, Action<string> dosmth)
	{
		for (int i = 0; i < s.Length - 1; i += cle)
		{
			if (i > s.Length - cle) dosmth(s.Substring(i));
			else dosmth(s.Substring(i, cle));
		}
	}
	
	static public string[] Split (this string s, char sep, int max)
	{
		return s.Split(new char[]{sep}, max);
	}
	
	static public string[] Cut (this string[] ia, int start)
	{
		string[] oa = new string[ia.Length - start];
		Array.Copy(ia, start, oa, 0, oa.Length);
		return oa;
	}
	
	static public string Join (this string[] a, string glu)
	{
		return string.Join(glu, a);
	}
	
	static public bool IsWordSep (this char c)
	{
		return c == ' ' || c == '\n' || c == '\r';
	}
	
	static public string WordFromIndex (this string s, int i)
	{
		if (s[i].IsWordSep()) return null;
		
		int li = i, ri = i;
		
		do { li -= 1; } while (li >= 0 && !s[li].IsWordSep());
		do { ri += 1; } while (ri < s.Length - 1 && !s[ri].IsWordSep());
		
		return s.Substring(li + 1, ri - li - 1);
	}
	
	static public bool LooksLikeUri (this string s)
	{
		return (
			s.StartsWith("http://") ||
			s.StartsWith("https://") ||
			s.StartsWith("ftp://") ||
			s.StartsWith("www.")
		);
	}
	
	static public string EscapeFileName (this string name)
	{
		foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
		return name;
	}
	
	static public bool Has (this Enum e, Enum f)
	{
		ulong el = Convert.ToUInt64(e);
		ulong fl = Convert.ToUInt64(f);
		return (el & fl) == fl;
	}
}