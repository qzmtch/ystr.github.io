using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;


enum LinkStatus
{
	Connecting, Connected,
	Disconnecting, Disconnected
}

delegate void BytesHandler (byte[] b);


class Link
{
	Socket sock;
	
	public event Action StatusChanged = () => {};
	public event BytesHandler DataReceived = (b) => {};
	public event BytesHandler DataSent = (b) => {};
	
	object statusLock = new object();
	LinkStatus status = LinkStatus.Disconnected;
	LinkStatus? oldStatus = null;
	Exception lastError = null;
	
	public LinkStatus Status { get { lock (statusLock) return status; } }
	public LinkStatus? OldStatus { get { lock (statusLock) return oldStatus; } }
	public Exception LastError { get { lock (statusLock) return lastError; } }
	
	bool SetStatus (LinkStatus ns)
	{
		if (status == ns) return false;
		oldStatus = status; status = ns;
		return true;
	}
	
	void Fail (Exception e)
	{
		#if DEBUG
			Console.WriteLine(e.ToString());
		#endif
		
		if (sock != null) sock.Close();
		
		lock (statusLock)
		{
			lastError = e;
			if (!SetStatus(LinkStatus.Disconnected)) return;
		}
		
		StatusChanged();
	}
	
	public void Connect (string host, int port)
	{
		lock (statusLock)
		{
			if (status != LinkStatus.Disconnected) return;
			SetStatus(LinkStatus.Connecting);
		}
		
		StatusChanged();
		
		sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
		try { sock.BeginConnect(host, port, ConnectCallback, null); }
		catch (Exception e) { Fail(e); }
	}
	
	public void Disconnect ()
	{
		lock (statusLock)
		{
			if (
				status == LinkStatus.Disconnecting ||
				status == LinkStatus.Disconnected
			) return;
			
			SetStatus(LinkStatus.Disconnecting);
		}
		
		StatusChanged();
		
		try {
			sock.Shutdown(SocketShutdown.Both);
			sock.Close();
		} catch (Exception e) { Fail(e); }
	}
	
	
	public void Send (byte[] bu)
	{
		try { sock.BeginSend(bu, 0, bu.Length, SocketFlags.None, SendCallback, bu); }
		catch (Exception e) { Fail(e); }
	}
	
	
	void ConnectCallback (IAsyncResult result)
	{
		try {
			sock.EndConnect(result);
			byte[] buffer = new byte[sock.ReceiveBufferSize];
			sock.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, ReceiveCallback, buffer);
			lock (statusLock) SetStatus(LinkStatus.Connected);
			StatusChanged();
		} catch (Exception e) { Fail(e); }
	}
	
	void ReceiveCallback (IAsyncResult result)
	{
		try
		{
			int length = sock.EndReceive(result);
			if (length == 0) throw new Exception("");
			byte[] buffer = (byte[]) result.AsyncState;
			
			byte[] msg = new byte[length];
			Array.Copy(buffer, msg, length);
			DataReceived(msg);
			
			sock.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, ReceiveCallback, buffer);
		}
		catch (Exception e) { Fail(e); }
	}
	
	void SendCallback (IAsyncResult result)
	{
		try { sock.EndSend(result); } catch (Exception e) { Fail(e); }
		DataSent((byte[])result.AsyncState);
	}
	
	void DisconnectCallback (IAsyncResult result)
	{
		try { sock.EndDisconnect(result); } catch (Exception e) { Fail(e); }
		lock (statusLock) SetStatus(LinkStatus.Disconnected);
		StatusChanged();
	}
}