using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Windows;

class Style
{
	static Font BaseFont;
	public static Style Default = new Style();
	
	static Dictionary<string, string> ini = new Dictionary<string, string>();
	static Dictionary<string, Style> all = new Dictionary<string, Style>();
	
	public static Style Get (string key)
	{
		lock (all)
		{
			if (all.ContainsKey(key)) return all[key];
			else {
				Style ns = all[key] = new Style();
				ns.Reload(key); return ns;
			}
		}
	}
	
	public static event Action Changed = () => {};
	
	Font font; public Font Font { get { return font; } }
	Color fore; public Color Fore { get { return fore; } }
	Color back; public Color Back { get { return back; } }
	
	void Set (FontStyle style, Color fore, Color back)
	{
		this.font = new Font(BaseFont, style);
		this.fore = fore;
		this.back = back;
	}
	
	static Color ParseColor (string s)
	{
		if (s[0] == '#') return ColorTranslator.FromHtml(s);
		else return Color.FromName(s);
	}
	
	void Reload (string key)
	{
		FontStyle style = Default.Font.Style;
		
		Color fore = Default.Fore;
		Color back = Default.Back;
		
		if (ini.ContainsKey(key))
		{
			string val = ini[key];
			
			List<string> args = new List<string>();
			string[] unparsed = val.Split(' ');
			foreach (string u in unparsed) {
				string arg = u.Trim();
				if (arg.Length > 0) args.Add(arg.ToLower());
			}
			
			foreach (string a in args)
			{
				if (a.Contains(":"))
				{
					string[] spl = a.Split(':');
					string arg = spl[1];
					
					switch (spl[0])
					{
						case "bg": back = ParseColor(arg); break;
					}
				}
				else switch (a)
				{
					case "bold": style |= FontStyle.Bold; break;
					case "italic": style |= FontStyle.Italic; break;
					default: fore = ParseColor(a); break;
				}
			}
		}
		
		Set(style, fore, back);
	}
	
	static Style ()
	{
		Settings.Changed += PrepareStyles;
		PrepareStyles();
	}
	
	static void PrepareStyles ()
	{
		BaseFont = new Font(Settings.BaseFont, Settings.FontSize);
		Default.Set(FontStyle.Regular, SystemColors.WindowText, SystemColors.Window);
		
		ini.Clear();
		
		foreach (string line in Own.Read("Style.ini").Split('\n'))
		{
			if (!line.Contains("=")) continue;
			string[] split = line.Split('=');
			
			string key = split[0].Trim(); if (key.Length == 0) continue;
			string val = split[1].Trim(); if (val.Length == 0) continue;
			
			ini[key] = val;
		}
		
		Default.Reload("Default");
		foreach (string k in all.Keys) all[k].Reload(k);
		
		Changed();
	}
}