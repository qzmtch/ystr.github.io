using System;
using System.IO;
using System.Reflection;
using System.Globalization;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

static class Own
{
	public const string DefaultSkin = "Default";
	public const string DefaultLocale = "en";
	
	
	static string skin = DefaultSkin;
	static string locale = DefaultLocale;
	
	
	public static event Action SkinChanged;
	public static event Action LocaleChanged;
	
	
	public static string Skin
	{
		get { return skin; }
		set {
			if (skin == value) return;
			cachedIcons.Clear();
			cachedImages.Clear();
			skin = value; SkinChanged();
		}
	}
	
	public static string Locale
	{
		get { return locale; }
		set {
			if (locale == value) return;
			locale = value; Prepare();
			LocaleChanged();
		}
	}
	
	
	static readonly Assembly me = Assembly.GetExecutingAssembly();
	public static readonly string Place = Path.GetDirectoryName(me.CodeBase).Replace("file:\\", "");
	
	
	static Stream stream;
	
	static public string Find (string name)
	{
		string x;
		
		if (File.Exists(x = Place + "\\Skin\\" + skin + "\\" + name)) return x;
		if (File.Exists(x = Place + "\\Skin\\" + DefaultSkin + "\\" + name)) return x;
		if (File.Exists(x = Place + "\\Local\\" + name)) return x;
		if (File.Exists(x = Place + "\\Local\\" + locale + "\\" + name)) return x;
		if (File.Exists(x = Place + "\\Local\\" + DefaultLocale + "\\" + name)) return x;
		
		throw new Exception(name);
	}
	
	public static Stream Get (string name)
	{
		if (stream != null) stream.Close();
		stream = me.GetManifestResourceStream(name); if (stream != null) return stream;
		return new FileStream(Find(name), FileMode.Open, FileAccess.Read);
	}
	
	static Stream Get (string name, string type)
	{
		if (name.Contains(".")) return Get(name);
		else return Get(name + "." + type);
	}
	
	
	static readonly Dictionary<string, Icon> cachedIcons = new Dictionary<string, Icon>();
	static readonly Dictionary<string, Image> cachedImages = new Dictionary<string, Image>();
	
	
	public static Icon Icon (string name)
	{
		if (cachedIcons.ContainsKey(name)) return cachedIcons[name];
		
		Icon i;
		
		try { i = new System.Drawing.Icon(Get(name, "ico")); }
		catch { i = System.Drawing.Icon.FromHandle(new Bitmap(Image(name)).GetHicon()); }
		
		cachedIcons[name] = i;
		
		return i;
	}
	
	public static Image Image (string name)
	{
		if (cachedImages.ContainsKey(name)) return cachedImages[name];
		
		Image i;
		
		try { i = System.Drawing.Image.FromStream(Get(name, "png")); }
		catch { i = new Bitmap(Get(name, "ico")); }
		
		cachedImages[name] = i;
		
		return i;
	}
	
	public static Cursor Cursor (string name)
	{
		return new Cursor(Get(name, "cur"));
	}
	
	public static string Read (string name)
	{
		using (StreamReader r = new StreamReader(Get(name)))
		{
			return r.ReadToEnd();
		}
	}
	
	
	static Dictionary<string, string> lines = new Dictionary<string, string>();
	
	public static string Line (string line)
	{
		lock (lines)
		{
			if (lines.ContainsKey(line)) return lines[line];
			else return line;
		}
	}
	
	public static string Line (string line, params string[] rep)
	{
		line = Line(line);
		for (int i = 0; i < rep.Length; i++) line = line.Replace("%" + i, rep[i]);
		return line;
	}
	
	
	static Own ()
	{
		skin = Settings.Skin;
		locale = Settings.Locale;
		
		Settings.Changed += () =>
		{
			Skin = Settings.Skin;
			Locale = Settings.Locale;
		};
		
		Prepare();
	}
	
	static void Prepare ()
	{
		lock (lines)
		{
			lines.Clear();
			
			string[] list = Read("Lines.ini").Split('\n');
			
			foreach (string line in list)
			{
				if (line.Contains("="))
				{
					string[] pair = line.Split('=');
					lines[pair[0].Trim()] = pair[1].Trim();
				}
			}
		}
	}
	
	
	static string[] GetDirs (string path)
	{
		string[] dirs = Directory.GetDirectories(Place + "\\" + path);
		for (int i = 0; i < dirs.Length; i++) dirs[i] = Path.GetFileName(dirs[i]);
		return dirs;
	}
	
	public static string[] ListSkins ()
	{
		return GetDirs("Skin");
	}
	
	public static string GetLocaleName (string code)
	{
		try { return Read(code + "\\Lines.ini").Split('\n')[0].Trim(); }
		catch { return code; }
	}
	
	public static string GetLocaleCode (string name)
	{
		Dictionary<string, string> ts = Own.ListLocales();
		foreach (KeyValuePair<string, string> kv in ts) if (kv.Value == name) return kv.Key;
		return null;
	}
	
	public static Dictionary<string, string> ListLocales ()
	{
		string[] codes = GetDirs("Local");
		Dictionary<string, string> ts = new Dictionary<string, string>();
		foreach (string code in codes) ts[code] = GetLocaleName(code);
		return ts;
	}
}