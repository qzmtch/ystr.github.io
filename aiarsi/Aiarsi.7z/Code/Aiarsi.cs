using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;


#if !DEBUG
	[assembly: AssemblyProduct("Aiarsi")]
	[assembly: AssemblyVersion("0.0.6.*")]
	[assembly: AssemblyInformationalVersion("0.0.6")]
	[assembly: AssemblyCopyright("ES <izt@ya.ru> GPL3")]
	[assembly: AssemblyCompany("E Strunnikov")]
#endif


static class Aiarsi
{
	static Mutex singleInstance = new Mutex(false, "Aiarsi");
	
	[STAThread] static void Main ()
	{
		if (!singleInstance.WaitOne(0, false)) return;
		Application.EnableVisualStyles();
		
		AppDomain.CurrentDomain.ProcessExit += (o, e) => Quit();
		
		Server.Initialize();
		Tray.Initialize();
		
		if (!Settings.StartHidden) Roster.ShowRoster();
		
		Application.Run();
		Tray.Exit();
	}
	
	static void Quit ()
	{
		Server.Cleanup();
		
		foreach (Server s in Server.List)
		{
			if (s.Welcomed)
			{
				s.ManualQuit();
			}
		}
		
		Options.Save();
	}
}