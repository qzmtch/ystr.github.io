using System;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;


[assembly: AssemblyTitle("Raskadrovka")]
[assembly: AssemblyProduct("Raskadrovka")]
[assembly: AssemblyDescription("Storyboard")]
[assembly: AssemblyCompany("E Strunnikov")]
[assembly: AssemblyCopyright("GPL3")]

#if !DEBUG
	[assembly: AssemblyVersion("0.0.0.*")]
	[assembly: AssemblyInformationalVersion("0.0.0")]
#endif


class Raskadrovka : Form
{
	string filePath = null;
	
	public readonly Document Document;
	
	ToolBase toolbar;
	
	ToolStripButton saveBtn = new ToolStripButton("Save");
	ToolStripButton saveAsBtn = new ToolStripButton("As");
	
	ToolStripButton moveLeftBtn = new ToolStripButton("←");
	ToolStripButton moveRightBtn = new ToolStripButton("→");
	ToolStripButton removeBtn = new ToolStripButton("-");
	ToolStripButton addBtn = new ToolStripButton("+");
	
	SplitContainer split1;
	SplitContainer split2;
	
	Canvas canvas;
	Caption caption;
	Film film;
	
	bool pathChanged = true;
	
	void Reveal ()
	{
		if (pathChanged)
		{
			Text = (
				filePath != null ? Path.GetFileName(filePath) + " - " : ""
			) + "Raskadrovka";
		}
		
		pathChanged = false;
	}
	
	void Save ()
	{
		if (filePath != null) SaveTo(filePath);
		else SaveAs();
	}
	
	void SaveTo (string path)
	{
		try { Document.SaveTo(path); filePath = path; pathChanged = true; Reveal(); }
		catch (Exception e) { Dialogs.ShowError("Can't save to " + path, e); }
	}
	
	void SaveAs ()
	{
		SaveFileDialog saver = new SaveFileDialog();
		saver.Filter = "Ras files|*.ras";
		if (saver.ShowDialog() == DialogResult.OK) SaveTo(saver.FileName);
	}
	
	public Raskadrovka (string path)
	{
		filePath = path;
		
		try { Document = new Document(filePath); }
		catch (Exception e) {
			Dialogs.ShowError("Can't open " + filePath, e);
			Environment.Exit(1);
		}
		
		ClientSize = new Size(640, 480);
		Icon = Own.Icon("Skin/Raskadrovka.ico");
		
		toolbar = new ToolBase();
		
		saveBtn.Click += (o, e) => Save();
		saveAsBtn.Click += (o, e) => SaveAs();
		moveLeftBtn.Click += (o, e) => MoveFrame(-1);
		moveRightBtn.Click += (o, e) => MoveFrame(+1);
		removeBtn.Click += (o, e) => DeleteFrame();
		addBtn.Click += (o, e) => AddFrame();
		
		toolbar.Items.Add(saveBtn);
		toolbar.Items.Add(saveAsBtn);
		toolbar.Items.Add(addBtn);
		toolbar.Items.Add(removeBtn);
		toolbar.Items.Add(moveRightBtn);
		toolbar.Items.Add(moveLeftBtn);
		
		addBtn.Alignment =
		removeBtn.Alignment =
		moveRightBtn.Alignment =
		moveLeftBtn.Alignment =
		ToolStripItemAlignment.Right;
		
		Controls.Add(toolbar);
		
		split1 = new SplitContainer();
		split2 = new SplitContainer();
		
		split1.Top = toolbar.Height;
		split1.Width = ClientSize.Width;
		split1.Height = ClientSize.Height - toolbar.Height;
		split1.Anchor = AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		
		split2.Dock = DockStyle.Fill;
		split1.Orientation = split2.Orientation = Orientation.Horizontal;
		split1.Panel1MinSize = split2.Panel2MinSize = 16;
		
		film = new Film(Document);
		film.Dock = DockStyle.Fill;
		film.BorderStyle = BorderStyle.Fixed3D;
		
		film.SelectedChanged += (i) =>
		{
			canvas.Frame = Document[i];
			caption.Frame = Document[i];
		};
		
		canvas = new Canvas(Document[film.Selected]);
		canvas.Dock = DockStyle.Fill;
		canvas.BorderStyle = BorderStyle.Fixed3D;
		
		caption = new Caption(Document[film.Selected]);
		caption.Dock = DockStyle.Fill;
		
		split2.Panel1.Controls.Add(canvas);
		split2.Panel2.Controls.Add(caption);
		split1.Panel2.Controls.Add(split2);
		split1.Panel1.Controls.Add(film);
		
		Controls.Add(split1);
		
		split1.SplitterDistance = 64;
		split2.SplitterDistance = split2.Height - 64;
		
		KeyPreview = true;
		
		split1.TabStop = false;
		split2.TabStop = false;
		
		Reveal();
	}
	
	protected override void OnKeyDown (KeyEventArgs e)
	{
		bool ctrl = (e.Modifiers == Keys.Control);
		bool ctrlShift = (e.Modifiers == (Keys.Control | Keys.Shift));
		
		switch (e.KeyCode)
		{
			case Keys.S: if (ctrl) Save(); else if (ctrlShift) SaveAs(); break;
			case Keys.N: if (ctrl) AddFrame(); break;
			case Keys.Delete: if (ctrl) DeleteFrame(); break;
			case Keys.Left: if (ctrl) SelectFrame(-1); else if (ctrlShift) MoveFrame(-1); break;
			case Keys.Right: if (ctrl) SelectFrame(+1); else if (ctrlShift) MoveFrame(+1); break;
			case Keys.F1: Process.Start(Own.ExeDir + "/Readme.txt"); break;
			case Keys.A: if (ctrl) caption.SelectAll(); break;
		}
	}
	
	void AddFrame ()
	{
		Document.AddFrame(film.Selected + 1);
	}
	
	void DeleteFrame ()
	{
		Document.RemoveFrame(film.Selected);
	}
	
	void SelectFrame (int delta)
	{
		int newsel = film.Selected + delta;
		if (newsel < 0 || newsel >= Document.Count) return;
		film.Selected = newsel;
	}
	
	void MoveFrame (int delta)
	{
		Document.MoveFrame(film.Selected, delta);
	}
	
	[STAThread] static void Main (string[] args)
	{
		Application.EnableVisualStyles();
		Application.Run(new Raskadrovka(args.Length > 0 ? args[0] : null));
	}
}
