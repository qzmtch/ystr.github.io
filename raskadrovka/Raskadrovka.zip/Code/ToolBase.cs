using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;


class ToolBase : MenuStrip
{
	public ToolBase ()
	{
		Padding = new Padding(2, 1, 2, 1);
		GripStyle = ToolStripGripStyle.Hidden;
		OS.ThemeChanged += SetStyle;
		SetStyle();
	}
	
	protected override void Dispose (bool disposing)
	{
		OS.ThemeChanged -= SetStyle;
		base.Dispose(disposing);
	}
	
	void SetStyle ()
	{
		if (Application.RenderWithVisualStyles) Renderer = new ModernRenderer();
		else Renderer = new ClassicRenderer();
	}
	
	class ModernRenderer : ToolStripSystemRenderer
	{
		protected override void OnRenderToolStripBackground (ToolStripRenderEventArgs e) {}
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e) {}
	}
	
	class ClassicRenderer : ToolStripSystemRenderer
	{
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e) {}
	}
}