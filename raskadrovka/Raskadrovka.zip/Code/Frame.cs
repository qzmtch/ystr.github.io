using System;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.Collections.Generic;


class Frame
{
	public string Caption = "";
	
	List<List<PointF>> strokes = new List<List<PointF>>();
	List<PointF> currentStroke = null;
	
	public void Write (BinaryWriter w)
	{
		w.Write(strokes.Count);
		
		foreach (var s in strokes)
		{
			w.Write(s.Count);
			
			foreach (var p in s)
			{
				w.Write(p.X);
				w.Write(p.Y);
			}
		}
		
		w.WriteUtf8(Caption);
	}
	
	public void Read (BinaryReader r)
	{
		uint sc = r.ReadUInt32();
		
		for (uint si = 0; si < sc; si++)
		{
			List<PointF> s = new List<PointF>();
			
			uint pc = r.ReadUInt32();
			
			for (uint pi = 0; pi < pc; pi++)
			{
				s.Add(new PointF(r.ReadSingle(), r.ReadSingle()));
			}
			
			strokes.Add(s);
		}
		
		Caption = r.ReadUtf8();
	}
	
	public Frame (BinaryReader r) { Read(r); }
	public Frame () {}
	
	public void StartStroke (float x, float y)
	{
		currentStroke = new List<PointF>{ new PointF(x, y) };
		strokes.Add(currentStroke);
	}
	
	public void DrawTo (float x, float y)
	{
		currentStroke.Add(new PointF(x, y));
	}
	
	public void EndStroke ()
	{
		if (currentStroke == null) return;
		if (currentStroke.Count < 2) strokes.Remove(currentStroke);
		currentStroke = null;
	}
	
	public void Commit ()
	{
		if (Changed != null) Changed();
	}
	
	public void EraseArea (RectangleF area)
	{
		var todel = new List<List<PointF>>();
		
		foreach (List<PointF> s in strokes)
		{
			foreach (PointF p in s)
			{
				if (area.Contains(p))
				{
					todel.Add(s);
					break;
				}
			}
		}
		
		foreach (List<PointF> del in todel) strokes.Remove(del);
	}
	
	public void Draw (Graphics g, Rectangle tgt, Color color)
	{
		Pen pen = new Pen(color);
		g.SmoothingMode = SmoothingMode.AntiAlias;
		
		foreach (List<PointF> stroke in strokes)
		{
			PointF[] ps = new PointF[stroke.Count];
			
			for (int i = 0; i < stroke.Count; i++)
			{
				PointF step = stroke[i];
				ps[i] = new PointF(step.X * tgt.Width, step.Y * tgt.Height);
			}
			
			g.DrawCurve(pen, ps);
		}
	}
	
	public event Action Changed;
}
