using System;
using System.Drawing;
using System.Windows.Forms;

static class Dialogs
{
	public static void ShowError (string title, Exception e)
	{
		MessageBox.Show (
			e.ToString(), title,
			MessageBoxButtons.OK, MessageBoxIcon.Error
		);
	}
}