using System;
using System.Drawing;
using System.Windows.Forms;

class Preview : Panel
{
	public readonly Frame Frame;
	
	bool selected = false;
	
	public bool Selected {
		get { return selected; }
		set { selected = value; RevealSelected(); }
	}
	
	void RevealSelected ()
	{
		if (selected)
		{
			BackColor = SystemColors.Highlight;
			ForeColor = SystemColors.HighlightText;
		}
		else
		{
			BackColor = SystemColors.Window;
			ForeColor = SystemColors.WindowText;
		}
	}
	
	public Preview (Frame frame)
	{
		this.Frame = frame;
		DoubleBuffered = true;
		BackColor = Color.White;
		BorderStyle = BorderStyle.Fixed3D;
		ResizeRedraw = true;
		
		Frame.Changed += () => Invalidate();
		
		RevealSelected();
	}
	
	protected override void OnPaint (PaintEventArgs e)
	{
		Frame.Draw (
			e.Graphics,
			new Rectangle(0, 0, ClientSize.Width, ClientSize.Height),
			ForeColor
		);
	}
}
