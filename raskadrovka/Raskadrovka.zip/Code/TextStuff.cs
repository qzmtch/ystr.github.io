using System;
using System.Text;
using System.Collections.Generic;
using System.IO;

static class TextStuff
{
	public static string ReadUtf8 (this BinaryReader r, int len)
	{
		return System.Text.Encoding.UTF8.GetString(r.ReadBytes(len));
	}
	
	public static string ReadUtf8 (this BinaryReader r)
	{
		List<byte> bytes = new List<byte>();
		
		byte b; do { b = r.ReadByte(); if (b != 0) bytes.Add(b); }
		while (b != 0);
		
		return Encoding.UTF8.GetString(bytes.ToArray());
	}
	
	public static void WriteUtf8 (this BinaryWriter w, string str)
	{
		w.Write(System.Text.Encoding.UTF8.GetBytes(str));
		w.Write('\0');
	}
}