using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

using Microsoft.Win32;

static class OS
{
	public static event Action ThemeChanged;
	public static string Theme { get { return VisualStyleInformation.DisplayName; } }
	static string oldTheme = Theme;
	
	static OS ()
	{
		SystemEvents.UserPreferenceChanged += (o, e) =>
		{
			if (oldTheme != Theme)
			{
				oldTheme = Theme;
				if (ThemeChanged != null) ThemeChanged();
			}
		};
	}
}