using System;
using System.Drawing;
using System.Windows.Forms;

class FrameMenu : ContextMenu
{
	public readonly Document Document;
	public readonly Frame Frame;
	
	MenuItem moveLeftRow;
	MenuItem moveRightRow;
	MenuItem deleteRow;
	
	public FrameMenu (Document doc, int fi)
	{
		this.Document = doc;
		this.Frame = doc[fi];
		
		moveLeftRow = new MenuItem("Move Left", (o, e) => Document.MoveFrame(Frame, -1));
		moveRightRow = new MenuItem("Move Right", (o, e) => Document.MoveFrame(Frame, +1));
		deleteRow = new MenuItem("Delete", (o, e) => Document.RemoveFrame(Frame), Shortcut.CtrlD);
		
		moveLeftRow.Enabled = fi > 0;
		moveRightRow.Enabled = fi < doc.Count - 1;
		
		MenuItems.Add(moveLeftRow);
		MenuItems.Add(moveRightRow);
		MenuItems.Add("-");
		MenuItems.Add(deleteRow);
	}
}