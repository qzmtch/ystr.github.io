using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

static class Own
{
	static readonly Assembly ass = Assembly.GetExecutingAssembly();
	
	public static readonly string ExePath = ass.Location;
	public static readonly string ExeFile = Path.GetFileName(ExePath);
	public static readonly string ExeDir = Path.GetDirectoryName(ass.Location);
	
	static Stream Stream (string path)
	{
		try { return new FileStream(ExeDir + "/" + path, FileMode.Open, FileAccess.Read); }
		catch { return ass.GetManifestResourceStream(Path.GetFileName(path)); }
	}
	
	public static Icon Icon (string path) { return new Icon(Stream(path)); }
}