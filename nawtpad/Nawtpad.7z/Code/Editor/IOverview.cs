using System.Drawing;

interface IOverview
{
	void DrawMark (Graphics g, int start, int size, Brush br);
}