using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;


class Editor : Control
{
	public readonly Document D;
	readonly List<Visual> visuals = new List<Visual>();
	
	static List<Editor> all = new List<Editor>();
	public static void ToAll (Action<Editor> act)
	{
		foreach (Editor e in all) act(e);
	}
	
	public Editor (Document D)
	{
		ResizeRedraw = false;
		DoubleBuffered = true;
		
		this.D = D;
		
		D.LineAdded += OnLineAdded;
		D.LinesRemoved += OnLinesRemoved;
		D.LineUpdated += OnLineUpdated;
		D.LinesCleared += OnLinesCleared;
		D.Updated += Refresh;
		D.Inserted += OnInserted;
		D.Removed += OnRemoved;
		D.Loaded += OnLoaded;
		D.IndentSizeChanged += OnIndentSizeChanged;
		D.MarksChanged += Refresh;
		
		GotFocus += (o, e) => { Invalidate(); };
		LostFocus += (o, e) => { Invalidate(); };
		PreviewKeyDown += (o, e) => e.IsInputKey = true;
		scrollTicker.Tick += (o, e) => OnScrollTick();
		
		Scheme.StyleChanged += Refresh;
		AltSearchEnabledChanged += UpdateSelectionSearch;
		
		UpdateFont();
		
		foreach (Line l in D)
		{
			Visual nv = new Visual(l);
			visuals.Add(nv);
			RecalcLine(nv);
		}
		
		AccomodateBounds();
		all.Add(this);
	}
	
	protected override void Dispose (bool disposing)
	{
		all.Remove(this);
		
		D.LineAdded -= OnLineAdded;
		D.LinesRemoved -= OnLinesRemoved;
		D.LineUpdated -= OnLineUpdated;
		D.LinesCleared -= OnLinesCleared;
		D.Updated -= Refresh;
		D.Inserted -= OnInserted;
		D.Removed -= OnRemoved;
		D.Loaded -= OnLoaded;
		D.IndentSizeChanged -= OnIndentSizeChanged;
		D.MarksChanged -= Refresh;
		
		AltSearchEnabledChanged -= UpdateSelectionSearch;
		
		scrollTicker.Stop(); scrollTicker.Dispose();
		
		Scheme.StyleChanged -= Refresh;
		
		base.Dispose(disposing);
	}
	
	
	#region Caret
		
		bool matchBrace = false;
		BraceMatch? matchingBrace = null;
		
		Pos caret = new Pos(0, 0);
		public Pos Caret { get { return caret; } }
		public event Action CaretMoved = () => {};
		
		int keepVisualX = 0;
		bool rememberVisualX = true;
		bool scrollToCaret = false;
		
		void FinishCaretMove (bool sel)
		{
			if (sel) MakeSelection();
			else ResetSelection();
			
			D.CommitChanges();
			
			scrollToCaret = true;
			matchBrace = true;
			Invalidate();
		}
		
		void MoveCaretByWord (int delta, bool sel)
		{
			Transition(delta, sel);
			
			Limits wb = D[caret.Line].FindWordBounds(caret.Char);
			
			if (delta > 0) {
				if (caret.Char != wb.Start) caret.Char = wb.End;
			} else caret.Char = wb.Start;
			
			FinishCaretMove(sel);
		}
		
		void MoveCaretToLineStart (bool sel)
		{
			caret.Char = 0;
			FinishCaretMove(sel);
		}
		
		void MoveCaretToLineEnd (bool sel)
		{
			caret.Char = D[caret.Line].Length;
			FinishCaretMove(sel);
		}
		
		void Transition (int delta, bool sel)
		{
			if (delta < 0)
			{
				if (!sel && selected) caret = selectionStart;
				if (caret.Char == 0) {
					if (caret.Line == 0) return;
					caret.Line -= 1; caret.Char = D[caret.Line].Length;
				} else caret.Char += delta;
			}
			else if (delta > 0)
			{
				if (!sel && selected) caret = selectionEnd;
				if (caret.Char == D[caret.Line].Length) {
					if (caret.Line == D.Count - 1) return;
					caret.Line += 1; caret.Char = 0;
				} else caret.Char += delta;
			}
		}
		
		void MoveCaretHorizontal (int delta, bool sel)
		{
			Transition(delta, sel);
			FinishCaretMove(sel);
		}
		
		void MoveCaretVertical (int delta, bool sel)
		{
			rememberVisualX = false;
			
			if (!sel && selected && selectionStart.Line != selectionEnd.Line)
			{
				if (delta < 0) caret = selectionStart;
				else caret = selectionEnd;
			}
			
			Cell vc = VisualFromSource(caret);
			
			vc.X = keepVisualX;
			vc.Y += delta;
			
			if (vc.Y < 0) vc.Y = 0;
			else if (vc.Y >= bounds.Height) vc.Y = bounds.Height - 1;
			
			caret = SourceFromVisual(vc.X, vc.Y).Source;
			FinishCaretMove(sel);
		}
		
		public void MoveCaretVerticalPage (int delta, bool sel)
		{
			MoveCaretVertical(delta * view.Height, sel);
		}
		
		void ScrollToCaret ()
		{
			Cell vc = VisualFromSource(caret);
			
			if (vc.Y < view.Y) view.Y = vc.Y;
			else if (vc.Y >= view.Y + view.Height) view.Y = vc.Y - view.Height + 1;
			
			if (vc.X < view.X) view.X = vc.X;
			else if (vc.X >= view.X + view.Width) view.X = vc.X - view.Width + 1;
		}
		
		void FixCaret ()
		{
			if (caret.Line >= D.Count) caret.Line = D.Count - 1;
			if (caret.Char > D[caret.Line].Length) caret.Char = D[caret.Line].Length;
		}
		
		void MatchBrace ()
		{
			if (braceMatching) matchingBrace = D.Scheme.MatchBrace(D, caret);
			else matchingBrace = null;
		}
		
	#endregion
	
	
	#region Display
		
		Graphics display = null;
		
		Size bounds = new Size(0, 0);
		Rectangle view = new Rectangle(0, 0, 0, 0);
		Rectangle textArea = new Rectangle(0, 0, 0, 0);
		
		Index topLeft = new Index();
		
		public event Action ViewChanged = () => {};
		public event Action Rendered = () => {};
		
		Pos oldPos;
		Size oldBounds;
		Rectangle oldView;
		Pos oldCaret;
		
		Rectangle caretCell;
		Rectangle caretItself;
		bool caretVisible;
		
		void UpdateSizes ()
		{
			int left = 0;
			int right = 0;
			
			if (numbers)
			{
				int nums = D.Count.ToString().Length;
				numbersArea = new Rectangle(0, 0, nums * numbersCharSize.Width + numbersPadding * 2, ClientSize.Height);
				left += numbersArea.Width;
			}
			
			textArea = new Rectangle(left, 0, ClientSize.Width - left - right, ClientSize.Height);
			if (textArea.Width < 0) textArea.Width = 0; if (textArea.Height < 0) textArea.Height = 0;
			view.Size = new Size(textArea.Width / charSize.Width, textArea.Height / charSize.Height);
			
			if (wrap && view.Width != oldView.Width) MarkAllForRecalc();
		}
		
		void RenderEverything ()
		{
			if (display == null) return;
			if (D.Operating) return;
			
			UpdateSizes();
			RecalcChanged();
			
			if (matchBrace) MatchBrace();
			if (scrollToCaret) ScrollToCaret();
			
			if (caret != oldCaret)
			{
				if (rememberVisualX) keepVisualX = VisualFromSource(caret).X;
				CaretMoved();
			}
			
			if (view.Y <= 0) view.Y = 0;
			else if (view.Y >= bounds.Height) view.Y = bounds.Height - 1;
			
			if (wrap) view.X = 0;
			else if (view.X <= 0) view.X = 0;
			else if (view.X >= bounds.Width) view.X = bounds.Width - 1;
			
			if (wrap)
			{
				if (view.Y != oldView.Y || caret != oldCaret) oldPos = SourceFromVisual(0, view.Y).Source;
				if (view.Width != oldView.Width || view.Y >= bounds.Height) view.Y = VisualFromSource(oldPos).Y;
			}
			
			topLeft = SubFromVisual(view.Y);
			
			Cell cpl = PlaceFromChar(caret);
			Point cpi = PixelFromPlace(cpl);
			caretVisible = IsPlaceVisible(cpl);
			caretCell = new Rectangle(cpi, charSize);
			const int caretWidth = 1;
			
			if (Scheme.Style.Default.BackBrush != null)
				display.Clear((Scheme.Style.Default.BackBrush as SolidBrush).Color);
			else display.Clear(SystemColors.Window);
			
			if (numbers) DrawNumbers();
			
			DrawText();
			
			if (bounds != oldBounds || view != oldView) ViewChanged();
			
			oldView = view;
			oldBounds = bounds;
			oldCaret = caret;
			
			matchBrace = false;
			scrollToCaret = false;
			rememberVisualX = true;
			
			if (caretVisible)
			{
				caretItself = overwrite ? (
					new Rectangle(caretCell.Left, caretCell.Top + caretCell.Height - 2, caretCell.Width, 2)
				) : new Rectangle(caretCell.Left - caretWidth / 2, caretCell.Top, caretWidth, caretCell.Height);
			
				display.FillRectangle(Scheme.Style["Default"].ForeBrush, caretItself);
			}
			
			Rendered();
		}
		
		protected override void OnResize (EventArgs e)
		{
			Invalidate();
		}
		
		protected override void OnPaint (PaintEventArgs e)
		{
			display = e.Graphics;
			RenderEverything();
		}
		
	#endregion
	
	
	#region Fonts
		
		void GenerateFont (Dictionary<FontStyle, Font> dic, Font o, FontStyle style)
		{
			dic[style] = new Font(o, style);
		}
		
		Dictionary<FontStyle, Font> GenerateFonts (Font o)
		{
			Dictionary<FontStyle, Font> d = new Dictionary<FontStyle, Font>();
			
			d[FontStyle.Regular] = o;
			
			GenerateFont(d, o, FontStyle.Bold);
			GenerateFont(d, o, FontStyle.Italic);
			GenerateFont(d, o, FontStyle.Underline);
			GenerateFont(d, o, FontStyle.Strikeout);
			
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Italic);
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Underline);
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Strikeout);
			GenerateFont(d, o, FontStyle.Italic | FontStyle.Underline);
			GenerateFont(d, o, FontStyle.Italic | FontStyle.Strikeout);
			GenerateFont(d, o, FontStyle.Underline | FontStyle.Strikeout);
			
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline);
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Italic | FontStyle.Strikeout);
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Underline | FontStyle.Strikeout);
			GenerateFont(d, o, FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout);
			
			GenerateFont(d, o, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout);
			
			return d;
		}
		
		Font normalFont;
		Font halfFont;
		Font numbersFont;
		
		Dictionary<FontStyle, Font> fonts;
		Dictionary<FontStyle, Font> numFonts;
		
		Size charSize, half, quarter;
		Size numbersCharSize;
		
		void UpdateFont ()
		{
			float fixdsize = fontSize - 0.5F;
			
			normalFont = new Font(fontName, fixdsize, FontStyle.Regular);
			fonts = GenerateFonts(normalFont);
			
			halfFont = new Font(fontName, fixdsize / 2);
			numbersFont = normalFont;
			numFonts = GenerateFonts(numbersFont);
			
			charSize = normalFont.GetCharMetrics();
			numbersCharSize = numbersFont.GetCharMetrics();
			half = new Size(charSize.Width / 2, charSize.Height / 2);
			quarter = new Size(charSize.Width / 4, charSize.Height / 4);
			
			Invalidate();
		}
		
	#endregion
	
	
	#region Keys
		
		KeyEventArgs latestKeyDownArgs;
		
		protected override void OnKeyPress (KeyPressEventArgs e)
		{
			if (latestKeyDownArgs == null) return;
			
			if (
				(latestKeyDownArgs.Modifiers & Keys.Control) == Keys.Control &&
				(latestKeyDownArgs.Modifiers & Keys.Alt) != Keys.Alt
			) return;
			
			switch (latestKeyDownArgs.KeyCode)
			{
				case Keys.Escape: return;
				case Keys.Enter: return;
				case Keys.Back: return;
				case Keys.Tab: return;
			}
			
			Type(e.KeyChar.ToString());
		}
		
		protected override void OnKeyDown (KeyEventArgs e)
		{
			latestKeyDownArgs = e;
			
			bool ctrl = (e.Modifiers == Keys.Control);
			bool shift = (e.Modifiers == Keys.Shift);
			bool ctrlShift = (e.Modifiers == (Keys.Control | Keys.Shift));
			
			switch (e.KeyCode)
			{
				case Keys.A:
					if (ctrl) SelectAll();
					else if (ctrlShift) SelectLine();
				break;
				case Keys.C: if (ctrl) CopySelected(); break;
				case Keys.V: if (ctrl) Paste(); break;
				case Keys.Q:
					if (ctrl) LineComment();
					else if (ctrlShift) StreamComment();
				break;
				case Keys.X: if (ctrl) CutSelected(); break;
				
				case Keys.Up: MoveCaretVertical(-1, e.Shift); break;
				case Keys.Down: MoveCaretVertical(+1, e.Shift); break;
				case Keys.Left:
					if (e.Control && e.Alt) MoveCaretToLineStart(e.Shift);
					else if (e.Control) MoveCaretByWord(-1, e.Shift);
					else MoveCaretHorizontal(-1, e.Shift);
				break;
				case Keys.Right:
					if (e.Control && e.Alt) MoveCaretToLineEnd(e.Shift);
					else if (e.Control) MoveCaretByWord(+1, e.Shift);
					else MoveCaretHorizontal(+1, e.Shift);
				break;
				
				case Keys.Back:
					if (ctrl) WordBackspace();
					else if (ctrlShift) LineBackspace();
					else Backspace();
				break;
				
				case Keys.Delete:
					if (ctrl) WordDelete();
					else if (ctrlShift) LineDelete();
					else Delete();
				break;
				
				case Keys.Enter: InsertLineBreak(); break;
				
				case Keys.Apps:
					Cell cc = PlaceFromChar(caret);
					if (IsPlaceVisible(cc)) ContextRequested(PixelFromPlace(cc));
					else ContextRequested(new Point(0, 0));
				break;
				
				case Keys.Tab:
					
					bool indent = false;
					
					switch (tabKeyFunction)
					{
						case "Indent": indent = true; break;
						case "InsertTab": indent = false; break;
						default: if (Selected) {
							indent = (SelectionStart.Line != SelectionEnd.Line);
						} break;
					}
					
					if (e.Control) indent = !indent;
					
					if (indent) {
						if (shift) Unindent();
						else Indent();
					} else Type("\t");
					
				break;
			}
		}
		
	#endregion
	
	
	#region Mapping
		
		Index SubFromVisual (int vy)
		{
			Index i = new Index();
			
			if (wrap)
			{
				int y = 0;
				
				foreach (Visual v in visuals)
				{
					int nexty = y + v.Bounds.Height;
					
					if (nexty > vy)
					{
						i.Sub = v.Subs.Count - (nexty - vy);
						break;
					}
					
					y = nexty;
					i.Line++;
				}
			}
			else
			{
				i.Line = vy;
				i.Sub = 0;
			}
			
			return i;
		}
		
		Stride SourceFromVisual (int vx, int vy)
		{
			Index i = new Index();
			
			if (vy >= bounds.Height)
			{
				i.Line = visuals.Count - 1;
				i.Sub = visuals[i.Line].Subs.Count - 1;
			}
			else if (vy > 0)
			{
				i = SubFromVisual(vy);
			}
			
			Visual lv = visuals[i.Line];
			
			Line l = lv.Source;
			Sub sub = lv.Subs[i.Sub];
			
			Stride s = new Stride();
			
			s.Source.Line = i.Line;
			s.Source.Char = sub.Start;
			
			int x = sub.VisualStart;
			
			while (x < sub.VisualEnd)
			{
				s.VisualStart = x;
				
				if (l.Text[s.Source.Char] == '\t') x += D.IndentSize - (x % D.IndentSize);
				else x += 1;
				
				if (x > vx) break;
				
				s.Source.Char++;
			}
			
			s.VisualLength = x - s.VisualStart;
			
			return s;
		}
		
		Pos SourceFromPixel (Point p, bool between)
		{
			int px = p.X - textArea.Left;
			int py = p.Y - textArea.Top;
			
			int vx = view.X + px / charSize.Width;
			int vy = view.Y + py / charSize.Height;
			
			Stride s = SourceFromVisual(vx, vy);
			
			Visual lv = visuals[s.Source.Line];
			if (s.Source.Char >= lv.Source.Length) return new Pos(s.Source.Line, lv.Source.Length);
			
			if (between)
			{
				int intpos = px - charSize.Width * (s.VisualStart - view.X);
				if (intpos > charSize.Width * s.VisualLength / 2) return new Pos(s.Source.Line, s.Source.Char + 1);
				else return new Pos(s.Source.Line, s.Source.Char);
			}
			else return s.Source;
		}
		
		Cell VisualFromSource (Pos src)
		{
			Cell vc = new Cell();
			
			int vi = 0;
			int start = 0;
			Visual v = null;
			Sub s = null;
			
			if (wrap)
			{
				while (true)
				{
					v = visuals[vi];
					if (vi == src.Line) break;
					vc.Y += v.Bounds.Height;
					vi++;
				}
				
				int sub = v.Subs.Count - 1;
				
				while (true)
				{
					start = v.Subs[sub].Start;
					if (start <= src.Char) break;
					sub--;
				}
				
				vc.Y += sub;
				vc.X = v.Subs[sub].VisualStart;
			}
			else
			{
				v = visuals[src.Line];
				vc.Y = src.Line;
				s = v.Subs[0];
			}
			
			int sci = start;
			Line l = v.Source;
			
			while (sci < src.Char && sci < l.Length)
			{
				if (l.Text[sci] == '\t') vc.X += D.IndentSize - (vc.X % D.IndentSize);
				else vc.X += 1;
				sci++;
			}
			
			return vc;
		}
		
		bool IsPlaceVisible (Cell c)
		{
			return (
				c.X >= 0 && c.X < view.Width &&
				c.Y >= 0 && c.Y < view.Height
			);
		}
		
		Cell PlaceFromChar (Pos p)
		{
			Cell v = VisualFromSource(p);
			return new Cell(v.X - view.X, v.Y - view.Y);
		}
		
		Point PixelFromPlace (Cell c)
		{
			return new Point
			(
				textArea.Left + c.X * charSize.Width,
				textArea.Top + c.Y * charSize.Height
			);
		}
		
	#endregion
	
	
	#region Mouse
		
		int clickCount = 1;
		Point prevClickPoint;
		DateTime prevClickTime = DateTime.Now;
		Timer scrollTicker = new Timer() { Interval = 100 };
		bool scrolling = false;
		Point curMousePoint;
		
		void OnScrollTick ()
		{
			view.X += (curMousePoint.X - prevClickPoint.X) / charSize.Width;
			view.Y += (curMousePoint.Y - prevClickPoint.Y) / charSize.Height;
			
			Invalidate();
		}
		
		protected override void OnMouseDown (MouseEventArgs e)
		{
			if (!Focused) Focus();
			curMousePoint = new Point(e.X, e.Y);
			
			if (
				e.Button == MouseButtons.Left &&
				DateTime.Now.Subtract(prevClickTime).TotalMilliseconds < SystemInformation.DoubleClickTime &&
				Math.Abs(e.X - prevClickPoint.X) < SystemInformation.DoubleClickSize.Width &&
				Math.Abs(e.Y - prevClickPoint.Y) < SystemInformation.DoubleClickSize.Height
			) {
				clickCount++;
				
				if (clickCount == 2) OnDoubleDown(e);
				else if (clickCount == 3) OnTripleDown(e);
				else clickCount = 1;
			}
			else
			{
				OnSingleDown(e);
				clickCount = 1;
			}
			
			prevClickTime = DateTime.Now;
			prevClickPoint = new Point(e.X, e.Y);
		}
		
		void OnSingleDown (MouseEventArgs e)
		{
			Pos nc = SourceFromPixel(curMousePoint, true);
			
			if (e.Button == MouseButtons.Middle)
			{
				scrolling = true;
				Cursor = Cursors.SizeAll;
				scrollTicker.Start();
				return;
			}
			
			if (e.Button == MouseButtons.Right && IsSelected(nc.Line, nc.Char)) return;
			if (e.Button == MouseButtons.Left) selecting = true;
			
			caret = nc;
			FinishCaretMove(Control.ModifierKeys == Keys.Shift);
		}
		
		void OnDoubleDown (MouseEventArgs e)
		{
			SelectWord();
		}
		
		void OnTripleDown (MouseEventArgs e)
		{
			SelectLine();
		}
		
		protected override void OnMouseUp (MouseEventArgs e)
		{
			if (scrolling) {
				scrollTicker.Stop();
				Cursor = Cursors.Arrow;
				scrolling = false;
			} if (e.Button == MouseButtons.Right) {
				Point cp = new Point(e.X, e.Y);
				if (numbers && numbersArea.Contains(cp)) NumbersContextRequested(cp);
				else ContextRequested(cp);
			} else selecting = false;
		}
		
		protected override void OnMouseMove (MouseEventArgs e)
		{
			curMousePoint = new Point(e.X, e.Y);
			
			if (scrolling) return;
			if (textArea.Contains(curMousePoint)) Cursor = Cursors.IBeam;
			else Cursor = Cursors.Arrow;
			
			if (selecting)
			{
				Pos nc = SourceFromPixel(curMousePoint, true);
				if (nc == caret) return;
				
				caret = nc;
				MakeSelection();
				D.CommitChanges();
				scrollToCaret = true;
				
				Invalidate();
			}
		}
		
	#endregion
	
	
	#region Numbers
		
		Rectangle numbersArea;
		const int numbersPadding = 2;
		
		struct NumbersRenderPass
		{
			public FontStyle Font;
			public Brush Fore;
			public Rectangle Rect;
		}
		
		void ApplyNumberStyle (ref NumbersRenderPass pass, Style.Component style)
		{
			if (style.NumFont != null) pass.Font |= style.NumFont.Value;
			if (style.NumForeBrush != null) pass.Fore = style.NumForeBrush;
			if (style.NumBackBrush != null) display.FillRectangle(style.NumBackBrush, pass.Rect);
		}
		
		void DrawNumbers ()
		{
			NumbersRenderPass pass = new NumbersRenderPass();
			
			Brush bb = Scheme.Style.Default.NumBackBrush;
			if (bb != null) display.FillRectangle(bb, numbersArea);
			
			Index i = topLeft;
			int digs = D.Count.ToString().Length;
			int y = textArea.Top;
			
			for (;;)
			{
				pass.Rect = new Rectangle (
					numbersArea.Left, y, numbersArea.Width,
					charSize.Height * (visuals[i.Line].Subs.Count - i.Sub)
				);
				
				pass.Fore = Scheme.Style.Default.NumForeBrush;
				pass.Font = numbersFont.Style;
				
				if (LineHasSelection(i.Line)) ApplyNumberStyle(ref pass, Scheme.Style.Selected);
				if (visuals[i.Line].Found.Count > 0) ApplyNumberStyle(ref pass, Scheme.Style.Found);
				if (visuals[i.Line].FoundAlt.Count > 0) ApplyNumberStyle(ref pass, Scheme.Style.FoundAlt);
				if (visuals[i.Line].Source.Marked) ApplyNumberStyle(ref pass, Scheme.Style.Mark);
				
				string num = (i.Line + 1).ToString();
				int x = numbersPadding;
				x += (digs - num.Length) * numbersCharSize.Width;
				
				for (int ni = 0; ni < num.Length; ni++)
				{
					display.DrawChar(num[ni], numFonts[pass.Font], pass.Fore, x, y);
					x += numbersCharSize.Width;
				}
				
				y += pass.Rect.Height; if (y > textArea.Bottom) break;
				i.Line++; if (i.Line >= D.Count) break;
				i.Sub = 0;
			}
		}
		
	#endregion
	
	
	#region Options
		
		static public bool DefaultOverwrite = false;
		static public bool DefaultWrap = true;
		static public bool DefaultShowSpace = false;
		static public string DefaultTabKeyFunction = "Auto";
		static public bool DefaultAutoPasteIndent = true;
		static public bool DefaultShowControl = true;
		static public bool DefaultNumbers = true;
		static public bool DefaultSearchIncremental = true;
		static public bool DefaultSearchCaseInvariant = true;
		static public bool DefaultSearchUnescape = false;
		static public bool DefaultSearchWords = false;
		static public bool DefaultAltSearchEnabled = true;
		static public float DefaultFontSize = 10;
		static public string DefaultFontName = "Lucida Console";
		static public bool DefaultGuides = true;
		static public bool DefaultWrapIndent = true;
		static public int DefaultWrapIndentExtra = 1;
		static public bool DefaultBraceMatching = true;
		
		bool showSpace = DefaultShowSpace;
		bool autoPasteIndent = DefaultAutoPasteIndent;
		bool showControl = DefaultShowControl;
		bool wrap = DefaultWrap;
		bool overwrite = DefaultOverwrite;
		string tabKeyFunction = DefaultTabKeyFunction;
		bool numbers = DefaultNumbers;
		bool searchIncremental = DefaultSearchIncremental;
		bool searchCaseInvariant = DefaultSearchCaseInvariant;
		bool searchUnescape = DefaultSearchUnescape;
		bool searchWords = DefaultSearchWords;
		bool altSearchEnabled = DefaultAltSearchEnabled;
		float fontSize = DefaultFontSize;
		string fontName = DefaultFontName;
		bool guides = DefaultGuides;
		bool wrapIndent = DefaultWrapIndent;
		int wrapIndentExtra = DefaultWrapIndentExtra;
		bool braceMatching = DefaultBraceMatching;
		
		public static string GlobalTabKeyFunction { set { ToAll((e) => e.TabKeyFunction = value); } }
		public static bool GlobalSearchIncremental { set { ToAll((e) => e.SearchIncremental = value); } }
		public static bool GlobalAltSearchEnabled { set { ToAll((e) => e.AltSearchEnabled = value); } }
		public static float GlobalFontSize { set { ToAll((e) => e.FontSize = value); } }
		public static bool GlobalBraceMatching { set { ToAll((e) => e.BraceMatching = value); } }
		public static string GlobalFontName { set { ToAll((e) => e.FontName = value); } }
		public static bool GlobalWrapIndent { set { ToAll((e) => e.WrapIndent = value); } }
		public static int GlobalWrapIndentExtra { set { ToAll((e) => e.WrapIndentExtra = value); } }
		
		public event Action AutoPasteIndentChanged = () => {};
		public event Action ShowSpaceChanged = () => {};
		public event Action ShowControlChanged = () => {};
		public event Action WrapChanged = () => {};
		public event Action OverwriteChanged = () => {};
		public event Action TabKeyFunctionChanged = () => {};
		public event Action NumbersChanged = () => {};
		public event Action SearchIncrementalChanged = () => {};
		public event Action SearchCaseInvariantChanged = () => {};
		public event Action SearchUnescapeChanged = () => {};
		public event Action SearchWordsChanged = () => {};
		public event Action AltSearchEnabledChanged = () => {};
		public event Action FontSizeChanged = () => {};
		public event Action FontNameChanged = () => {};
		public event Action GuidesChanged = () => {};
		public event Action WrapIndentChanged = () => {};
		public event Action WrapIndentExtraChanged = () => {};
		public event Action BraceMatchingChanged = () => {};
		
		public bool ShowSpace {
			get { return showSpace; }
			set { showSpace = value; ShowSpaceChanged(); Invalidate(); }
		}
		
		public bool ShowControl {
			get { return showControl; }
			set { showControl = value; ShowControlChanged(); MarkAllForRecalc(); Invalidate(); }
		}
		
		public bool Wrap {
			get { return wrap; }
			set { wrap = value; MarkAllForRecalc(); Invalidate(); WrapChanged(); }
		}
		
		public bool Overwrite {
			get { return overwrite; }
			set { overwrite = value; OverwriteChanged(); Invalidate(); }
		}
		
		public string TabKeyFunction {
			get { return tabKeyFunction; }
			set { tabKeyFunction = value; TabKeyFunctionChanged(); }
		}
		
		public bool Numbers {
			get { return numbers; }
			set { numbers = value; NumbersChanged(); Invalidate(); }
		}
		
		public bool SearchIncremental {
			get { return searchIncremental; }
			set { searchIncremental = value; SearchIncrementalChanged(); }
		}
		
		public bool SearchCaseInvariant {
			get { return searchCaseInvariant; }
			set { searchCaseInvariant = value; SearchCaseInvariantChanged(); if (searchIncremental) FindAll(); }
		}
		
		public bool SearchWords {
			get { return searchWords; }
			set { searchWords = value; SearchWordsChanged(); if (searchIncremental) FindAll(); }
		}
		
		public bool SearchUnescape {
			get { return searchUnescape; }
			set { searchUnescape = value; SearchUnescapeChanged(); if (searchIncremental) FindAll(); }
		}
		
		public bool AltSearchEnabled {
			get { return altSearchEnabled; }
			set { altSearchEnabled = value; AltSearchEnabledChanged(); }
		}
		
		public float FontSize {
			get { return fontSize; }
			set { if (value < 2) return; else fontSize = value; FontSizeChanged(); UpdateFont(); }
		}
		
		public string FontName {
			get { return fontName; }
			set { fontName = value; FontNameChanged(); UpdateFont(); }
		}
		
		public bool AutoPasteIndent {
			get { return autoPasteIndent; }
			set { autoPasteIndent = value; AutoPasteIndentChanged(); }
		}
		
		public bool Guides {
			get { return guides; }
			set { guides = value; GuidesChanged(); Invalidate(); }
		}
		
		public bool WrapIndent {
			get { return wrapIndent; }
			set { wrapIndent = value; WrapIndentChanged(); MarkAllForRecalc(); Invalidate(); }
		}
		
		public int WrapIndentExtra {
			get { return wrapIndentExtra; }
			set { wrapIndentExtra = value; WrapIndentExtraChanged(); MarkAllForRecalc(); Invalidate(); }
		}
		
		public bool BraceMatching {
			get { return braceMatching; }
			set { braceMatching = value; BraceMatchingChanged(); MatchBrace(); Invalidate(); }
		}
		
	#endregion
	
	
	#region Overview
		
		public void PaintTrack (IOverview to, Graphics g, Rectangle track)
		{
			int li = 0;
			int top = 0;
			
			int selStart = 0;
			int selEnd = 0;
			
			Brush foundBrush = Scheme.Style.Found.StripBrush ?? Scheme.Style.Default.ForeBrush;
			Brush foundAltBrush = Scheme.Style.FoundAlt.StripBrush ?? Scheme.Style.Default.ForeBrush;
			Brush markBrush = Scheme.Style.Mark.StripBrush ?? Scheme.Style.Default.ForeBrush;
			Brush selectedBrush = Scheme.Style.Selected.StripBrush;
			
			foreach (Visual v in visuals)
			{
				if (v.Found.Count > 0) to.DrawMark(g, top, v.Bounds.Height, foundBrush);
				if (v.FoundAlt.Count > 0) to.DrawMark(g, top, v.Bounds.Height, foundAltBrush);
				if (v.Source.Marked) to.DrawMark(g, top, v.Bounds.Height, markBrush);
				
				if (selectionStart.Line == li) selStart = top;
				top += v.Bounds.Height;
				if (selectionEnd.Line == li) selEnd = top;
				
				li++;
			}
			
			to.DrawMark(g, selStart, selEnd - selStart, selectedBrush);
		}
		
	#endregion
	
	
	#region Recalc
		
		bool linesCleared = true;
		bool linesRemoved = false;
		List<Visual> toRecalc = new List<Visual>();
		
		void RecalcChanged ()
		{
			if (linesRemoved || linesCleared || toRecalc.Count > 1)
			{
				foreach (Visual v in toRecalc)
				{
					RecalcLine(v);
					Find(v);
				}
				
				AccomodateBounds();
			}
			else if (toRecalc.Count == 1)
			{
				Visual only = toRecalc[0];
				int oldh = only.Bounds.Height;
				
				RecalcLine(only);
				Find(only);
				
				if (only.Bounds.Width > bounds.Width) bounds.Width = only.Bounds.Width;
				bounds.Height = bounds.Height - oldh + only.Bounds.Height;
			}
			else return;
			
			matchBrace = true;
			linesRemoved = false;
			toRecalc.Clear();
		}
		
		void RecalcLine (Visual v)
		{
			v.Subs.Clear();
			v.Subs.Add(new Sub { Start = 0, VisualStart = 0 });
			
			v.Bounds.Height = 1;
			
			if (wrap)
			{
				v.Bounds.Width = view.Width;
				
				int x = 0;
				int ci = 0;
				int sub = 0;
				
				int lastBreaker = 0;
				int lastX = 0;
				
				bool indenting = true;
				int indent = 0;
				
				while (ci < v.Source.Length)
				{
					CharMeta c = v.Source.Meta[ci];
					char cc = v.Source.Text[ci];
					
					if (c.IsBreaker)
					{
						lastBreaker = ci;
						lastX = x;
					}
					
					if (cc == '\t') x += D.IndentSize - (x % D.IndentSize);
					else x += 1;
					
					if (!c.IsSpace) indenting = false;
					if (indenting) indent = x;
					
					ci++;
					
					if (x >= view.Width)
					{
						if (lastBreaker != 0) {
							ci = lastBreaker + 1;
							lastBreaker = 0;
							v.Subs[sub].VisualEnd = lastX;
						} else v.Subs[sub].VisualEnd = x;
						
						v.Bounds.Height++;
						
						v.Subs[sub].End = ci;
						v.Subs[sub].VisualIndent = indent;
						
						if (!wrapIndent) indent = 0;
						
						v.Subs.Add(new Sub { Start = ci });
						
						sub++;
						
						if (wrapIndent) v.Subs[sub].VisualStart = indent + wrapIndentExtra * D.IndentSize;
						else v.Subs[sub].VisualStart = 0;
						
						x = v.Subs[sub].VisualStart;
						lastX = v.Subs[sub].VisualStart;
					}
				}
				
				v.Subs[sub].End = v.Source.Length;
				v.Subs[sub].VisualEnd = x;
				v.Subs[sub].VisualIndent = indent;
			}
			else
			{
				v.Bounds.Width = 0;
				bool indenting = true;
				int indent = 0;
				
				for (int i = 0; i < v.Source.Text.Length; i++)
				{
					CharMeta s = v.Source.Meta[i];
					char c = v.Source.Text[i];
					
					if (c == '\t') v.Bounds.Width += D.IndentSize - (v.Bounds.Width % D.IndentSize);
					else v.Bounds.Width += 1;
					
					if (!s.IsSpace) indenting = false;
					if (indenting) indent = v.Bounds.Width;
				}
				
				v.Subs[0].End = v.Source.Length;
				v.Subs[0].VisualEnd = v.Bounds.Width;
				v.Subs[0].VisualIndent = indent;
			}
		}
		
		void MarkForRecalc (Visual v)
		{
			if (toRecalc.Contains(v)) return;
			toRecalc.Add(v);
		}
		
		void MarkAllForRecalc ()
		{
			foreach (Visual v in visuals) MarkForRecalc(v);
		}
		
		void OnLineAdded (int li, Line l)
		{
			Visual nv = new Visual(l);
			visuals.Insert(li, nv);
			MarkForRecalc(nv);
		}
		
		void OnLinesRemoved (int at, int n)
		{
			linesRemoved = true;
			
			for (int i = at; i < at + n; ++i)
			{
				Visual vtr = visuals[i];
				if (toRecalc.Contains(vtr)) toRecalc.Remove(vtr);
			}
			
			visuals.RemoveRange(at, n);
		}
		
		void OnLineUpdated (int li, Line l)
		{
			MarkForRecalc(visuals[li]);
		}
		
		void OnLinesCleared ()
		{
			linesCleared = true;
			toRecalc.Clear();
			visuals.Clear();
		}
		
		void OnInserted (Range r)
		{
			caret.AdjustAfterAddition(r.Start, r.End);
			selectionStart.AdjustAfterAddition(r.Start, r.End);
			selectionEnd.AdjustAfterAddition(r.Start, r.End);
			selectionOrigin.AdjustAfterAddition(r.Start, r.End);
			ConcludeSelection();
		}
		
		void OnRemoved (Range r)
		{
			caret.AdjustAfterRemoval(r.Start, r.End);
			selectionStart.AdjustAfterRemoval(r.Start, r.End);
			selectionEnd.AdjustAfterRemoval(r.Start, r.End);
			selectionOrigin.AdjustAfterRemoval(r.Start, r.End);
			ConcludeSelection();
		}
		
		void OnIndentSizeChanged ()
		{
			MarkAllForRecalc();
			Invalidate();
		}
		
		void OnLoaded ()
		{
			FixCaret();
			ResetSelection();
		}
		
		void AccomodateBounds ()
		{
			bounds.Width = 0;
			bounds.Height = 0;
			
			foreach (Visual v in visuals)
			{
				if (v.Bounds.Width > bounds.Width) bounds.Width = v.Bounds.Width;
				bounds.Height += v.Bounds.Height;
			}
		}
		
	#endregion
	
	
	#region Scroll
		
		public int VScrollMax {
			get {
				if (bounds.Height - view.Y >= view.Height - 1) return bounds.Height;
				else return view.Y + view.Height - 1;
			}
		}
		
		public int HScrollMax {
			get {
				if (bounds.Width - view.X >= view.Width) return bounds.Width;
				else return view.X + view.Width - 1;
			}
		}
		
		public int VPageScrollSpan { get { return view.Height; } }
		public int HPageScrollSpan { get { return view.Width; } }
		
		public bool VScrollRequired { get { return view.Y != 0 || bounds.Height > view.Height; } }
		public bool HScrollRequired { get { return !wrap && (view.X != 0 || bounds.Width > view.Width); } }
		
		public int VScrollPos { get { return view.Y; } }
		public int HScrollPos { get { return view.X; } }
		
		public void VScrollTo (int li)
		{
			view.Y = li;
			Invalidate();
		}
		
		public void HScrollTo (int ci)
		{
			view.X = ci;
			Invalidate();
		}
		
		public void VScroll (int delta)
		{
			VScrollTo(view.Y + delta);
		}
		
		public void VScrollPage (int delta)
		{
			VScroll(delta * view.Height);
		}
		
	#endregion
	
	
	#region Search
		
		string search = null;
		string actualSearch = null;
		string altSearch = null;
		
		Regex actualSearchRex = null;
		Regex altSearchRex = null;
		
		public event Action ActualSearchChanged = () => {};
		public event Action SearchChanged = () => {};
		
		public string ActualSearch { get { return actualSearch; } }
		
		public string Search {
			get { return search; }
			set {
				if (search == value) return;
				search = (value != null && value.Length > 0) ? value : null;
				if (searchIncremental || search == null) FindAll();
				SearchChanged();
			}
		}
		
		void SetAltSearch (string altSearch)
		{
			if (this.altSearch == altSearch) return;
			this.altSearch = (altSearch != null && altSearch.Trim().Length > 0) ? altSearch : null;
			FindAll();
		}
		
		public void FindAll ()
		{
			actualSearch = search;
			ActualSearchChanged();
			
			actualSearchRex = MakeSearchRex(search, searchCaseInvariant, searchWords, searchUnescape);
			altSearchRex = MakeSearchRex(altSearch, searchCaseInvariant, searchWords, false);
			
			foreach (Visual v in visuals) Find(v);
			
			Invalidate();
		}
		
		void Find (Visual v)
		{
			v.Found.Clear();
			v.FoundAlt.Clear();
			
			if (actualSearch != null) Find(v, actualSearchRex, v.Found);
			if (altSearch != null) Find(v, altSearchRex, v.FoundAlt);
			
			v.Found.Sort();
			v.FoundAlt.Sort();
		}
		
		Regex MakeSearchRex (string search, bool nocase, bool words, bool unesc)
		{
			if (String.IsNullOrEmpty(search)) return null;
			
			try { if (unesc) search = Regex.Unescape(search); } catch {}
			string rex = Regex.Escape(search);
			
			if (searchWords) rex = "\\b" + rex + "\\b";
			if (searchCaseInvariant) rex = "(?i)" + rex;
			
			return new Regex(rex);
		}
		
		void Find (Visual v, Regex srex, List<Limits> tgtlist)
		{
			MatchCollection matches = srex.Matches(v.Source.Text);
			foreach (Match m in matches) tgtlist.Add(new Limits(m.Index, m.Index + m.Length));
		}
		
		public bool SelectNextFound (int dir) { return SelectNextFound(dir, caret); }
		public bool SelectNextFound (int dir, Pos start)
		{
			if (search != null && !searchIncremental) FindAll();
			
			for (
				int li = start.Line;
				dir < 0 ? li >= 0 : li < D.Count;
				li += dir
			) {
				Visual v = visuals[li];
				if (v.Found.Count == 0) continue;
				
				for (
					int fi = dir < 0 ? v.Found.Count - 1 : 0;
					dir < 0 ? fi >= 0 : fi < v.Found.Count;
					fi += dir
				) {
					Limits f = v.Found[fi];
					
					if (
						li == start.Line &&
						(dir < 0 ? f.End >= start.Char : f.End <= start.Char)
					) continue;
					
					Select(new Pos(li, f.Start), new Pos(li, f.End));
					scrollToCaret = true;
					Invalidate();
					
					return true;
				}
			}
			
			Pos over = dir < 0 ?
				new Pos(D.Count - 1, D[D.Count - 1].Length)
			: new Pos(0, 0);
			
			if (start != over) return SelectNextFound(dir, over);
			
			return false;
		}
		
		void UpdateSelectionSearch ()
		{
			if (
				altSearchEnabled && selected &&
				selectionStart.Line == selectionEnd.Line
			) SetAltSearch(D.Export(selectionStart, selectionEnd));
			else SetAltSearch(null);
		}
		
		public int Replace (string find, string rep, bool nocase, bool words, bool unescape)
		{
			int repd = 0;
			
			Regex frex = MakeSearchRex(find, nocase, words, unescape);
			if (unescape) rep = Regex.Unescape(rep);
			
			D.CommitChanges();
			D.StartOperation();
			
			bool sel = selected && selectionStart.Line != selectionEnd.Line;
			
			int ss = sel ? selectionStart.Line : 0;
			int se = sel ? selectionEnd.Line : visuals.Count - 1;
			
			for (int vi = ss; vi <= se; vi++)
			{
				Visual v = visuals[vi];
				
				int next = 0;
				Match m;
				
				while ((m = frex.Match(v.Source.Text, next)).Success)
				{
					Pos s = new Pos(vi, m.Index);
					Pos e = new Pos(vi, m.Index + m.Length);
					
					D.Remove(s, e);
					Pos np = D.Insert(s, rep);
					repd++;
					
					next = np.Char;
					
					if (np.Line > vi) break;
				}
			}
			
			FindAll();
			D.EndOperation();
			
			return repd;
		}
		
	#endregion
	
	
	#region Selection
		
		public event Action SelectionChanged = () => {};
		
		bool selected = false;
		
		Pos selectionOrigin;
		Pos selectionStart;
		Pos selectionEnd;
		
		public bool Selected { get { return selected; } }
		public Pos SelectionStart { get { return selectionStart; } }
		public Pos SelectionEnd { get { return selectionEnd; } }
		
		void ResetSelection ()
		{
			selectionOrigin = caret;
			selectionStart = caret;
			selectionEnd = caret;
			ConcludeSelection();
		}
		
		void MakeSelection ()
		{
			if (selectionOrigin != caret)
			{
				if (selectionOrigin < caret) { selectionStart = selectionOrigin; selectionEnd = caret; }
				else { selectionStart = caret; selectionEnd = selectionOrigin; }
			}
			
			ConcludeSelection();
		}
		
		bool IsSelected (int li, int ci)
		{
			if (!selected) return false;
			
			if (li > selectionStart.Line && li < selectionEnd.Line) return true;
			else if (li == selectionStart.Line && selectionStart.Line == selectionEnd.Line) {
				if (ci >= selectionStart.Char && ci < selectionEnd.Char) return true;
			} else if (li == selectionStart.Line && ci >= selectionStart.Char) return true;
			else if (li == selectionEnd.Line && ci < selectionEnd.Char) return true;
			
			return false;
		}
		
		bool LineHasSelection (int li)
		{
			return (li >= selectionStart.Line && li <= selectionEnd.Line);
		}
		
		void Select (Pos start) { Select(start, start); }
		void Select (Pos start, Pos end)
		{
			selectionStart = selectionOrigin = start;
			selectionEnd = caret = end;
			ConcludeSelection();
		}
		
		public void SelectAll ()
		{
			Select (
				new Pos(0, 0),
				new Pos(D.Count - 1, D[D.Count - 1].Length)
			);
			
			Invalidate();
		}
		
		public void SelectWord ()
		{
			Limits wl = D[caret.Line].FindWordBounds(caret.Char);
			selectionOrigin = new Pos(caret.Line, wl.Start);
			caret.Char = wl.End;
			MakeSelection();
			Invalidate();
		}
		
		public void SelectLine ()
		{
			Select (
				new Pos(selectionStart.Line, 0),
				new Pos(selectionEnd.Line, D[selectionEnd.Line].Length)
			);
			
			Invalidate();
		}
		
		void ConcludeSelection ()
		{
			selected = (selectionStart != selectionEnd);
			UpdateSelectionSearch();
			SelectionChanged();
		}
		
	#endregion
	
	
	#region Text
		
		struct TextRenderPass
		{
			public CharMeta CharMeta;
			public char Char;
			public Index Index;
			public int CharIndex;
			public int VisualX;
			public Point Pixel;
			public Cell Table;
			public Pen ForePen;
			public Brush ForeBrush;
			public FontStyle Font;
			public Rectangle Rect;
			public bool Found;
			public bool FoundAlt;
		}
		
		struct Limiter
		{
			public int First;
			public Limits Limits;
			public bool FoundAnything;
			public List<Limits> List;
			public int FindX;
			
			public void Preposition ()
			{
				foreach (Limits fl in List)
				{
					if (fl.End < First) FindX++;
					else {
						FoundAnything = true;
						if (fl.Start < First) Limits = new Limits(First, fl.End);
						else Limits = fl;
						return;
					}
				}
			}
			
			public void Check (int charIndex, ref bool found)
			{
				if (FoundAnything)
				{
					if (charIndex == Limits.End)
					{
						found = false;
						FindX++;
						if (FindX < List.Count) Limits = List[FindX];
					}
					
					if (charIndex == Limits.Start) found = true;
				}
			}
		}
		
		void DrawText ()
		{
			TextRenderPass pass = new TextRenderPass();
			
			pass.Index = topLeft;
			pass.Pixel.Y = textArea.Y;
			pass.Table.Y = 0;
			
			while (true)
			{
				Visual vis = visuals[pass.Index.Line];
				Line line = vis.Source;
				
				while (true)
				{
					Sub s = vis.Subs[pass.Index.Sub];
					
					pass.CharIndex = s.Start;
					pass.VisualX = s.VisualStart;
					
					if (s.VisualEnd < view.X) goto Next;
					
					if (LineHasSelection(pass.Index.Line))
					{
						if (Scheme.Style.Selected.FillBrush != null)
						{
							display.FillRectangle(Scheme.Style.Selected.FillBrush, textArea.X, pass.Pixel.Y, textArea.Width, charSize.Height);
						}
					}
					
					if (vis.Source.Marked)
					{
						if (Scheme.Style["Mark"].FillBrush != null)
						{
							display.FillRectangle(Scheme.Style["Mark"].FillBrush, textArea.X, pass.Pixel.Y, textArea.Width, charSize.Height);
						}
					}
					
					while (pass.VisualX < view.X)
					{
						if (line.Text[pass.CharIndex] == '\t')
						{
							pass.VisualX += D.IndentSize - (pass.VisualX % D.IndentSize);
							if (pass.VisualX <= view.X) pass.CharIndex++;
						}
						else
						{
							pass.VisualX++;
							pass.CharIndex++;
						}
					}
					
					Limiter found = new Limiter();
					Limiter foundAlt = new Limiter();
					found.FindX = foundAlt.FindX = 0;
					found.First = foundAlt.First = pass.CharIndex;
					found.Limits = foundAlt.Limits = new Limits(pass.CharIndex, pass.CharIndex);
					found.FoundAnything = foundAlt.FoundAnything = false;
					found.List = vis.Found; foundAlt.List = vis.FoundAlt;
					found.Preposition(); foundAlt.Preposition();
					pass.Found = pass.FoundAlt = false;
					
					if (pass.VisualX > view.X) pass.VisualX = view.X;
					
					pass.Table.X = s.VisualStart;
					pass.Pixel.X = textArea.X + pass.Table.X * charSize.Width;
					
					while (pass.Table.X < view.Width && pass.CharIndex < s.End)
					{
						found.Check(pass.CharIndex, ref pass.Found);
						foundAlt.Check(pass.CharIndex, ref pass.FoundAlt);
						
						pass.CharMeta = line.Meta[pass.CharIndex];
						pass.Char = line.Text[pass.CharIndex];
						DrawCharMeta(ref pass);
						pass.CharIndex += 1;
					}
					
					if (IsSelected(pass.Index.Line, pass.CharIndex))
					{
						if (Scheme.Style.Selected.BackBrush != null)
						{
							display.FillRectangle(Scheme.Style.Selected.BackBrush, pass.Pixel.X, pass.Pixel.Y, half.Width, charSize.Height);
						}
					}
					
					if (guides && !showSpace)
					{
						int y0 = pass.Pixel.Y;
						int y1 = y0 + charSize.Height;
						
						int ind = s.VisualIndent - Zmod(s.VisualIndent);
						
						int tx0 = textArea.Left;
						int tx1 = textArea.Left + (ind - view.X) * charSize.Width;
						
						int tabWidth = D.IndentSize * charSize.Width;
						
						for (int x = tx1; x >= tx0; x -= tabWidth) {
							display.DrawLine(Scheme.Style.Default.GuidePen, x, y0, x, y1);
						}
						
						int prev = 0;
						int next = 0;
						
						if (pass.Index.Line > 0) { Visual pv = visuals[pass.Index.Line - 1]; prev = pv.Subs[pv.Subs.Count - 1].VisualEnd; }
						if (pass.Index.Line < visuals.Count - 1) next = visuals[pass.Index.Line + 1].Subs[0].VisualEnd;
						
						prev += D.IndentSize - Zmod(prev);
						next += D.IndentSize - Zmod(next);
						
						bool frst = ind >= prev && pass.Index.Sub == 0;
						bool last = ind >= next && pass.Index.Sub == vis.Subs.Count - 1;
						
						int x1 = textArea.Left + (s.VisualIndent - view.X) * charSize.Width;
						
						if (frst) {
							int x0 = textArea.Left + (prev < view.X ? 0 : prev - view.X) * charSize.Width;
							display.DrawLine(Scheme.Style.Default.GuidePen, x0, y0, x1, y0);
						}
						
						if (last) {
							int x0 = textArea.Left + (next < view.X ? 0 : next - view.X) * charSize.Width;
							display.DrawLine(Scheme.Style.Default.GuidePen, x0, y1, x1, y1);
						}
					}
					
					Next:
					
					pass.Pixel.Y += charSize.Height;
					pass.Table.Y++; if (pass.Table.Y >= view.Height) return;
					pass.Index.Sub++; if (pass.Index.Sub >= vis.Subs.Count) break;
				}
				
				pass.Index.Line++; if (pass.Index.Line >= visuals.Count) return;
				pass.Index.Sub = 0;
			}
		}
		
		void ApplyStyle (ref TextRenderPass pass, Style.Component style)
		{
			if (style.Font != null) pass.Font |= style.Font.Value;
			if (style.ForePen != null) pass.ForePen = style.ForePen;
			if (style.ForeBrush != null) pass.ForeBrush = style.ForeBrush;
			if (style.BackBrush != null) display.FillRectangle(style.BackBrush, pass.Rect);
		}
		
		void DrawCharMeta (ref TextRenderPass pass)
		{
			int span = (pass.Char == '\t') ? D.IndentSize - (pass.VisualX % D.IndentSize) : 1;
			pass.Rect = new Rectangle(pass.Pixel.X, pass.Pixel.Y, charSize.Width * span, charSize.Height);
			
			pass.ForePen = Scheme.Style[pass.CharMeta.Style].ForePen ?? Scheme.Style.Default.ForePen;
			pass.ForeBrush = Scheme.Style[pass.CharMeta.Style].ForeBrush ?? Scheme.Style.Default.ForeBrush;
			
			pass.Font = Scheme.Style[pass.CharMeta.Style].Font != null ? Scheme.Style[pass.CharMeta.Style].Font.Value : normalFont.Style;
			
			if (
				matchingBrace != null && (
					(
						pass.Index.Line == matchingBrace.Value.Self.Line &&
						pass.CharIndex == matchingBrace.Value.Self.Char
					) || (
						pass.Index.Line == matchingBrace.Value.That.Line &&
						pass.CharIndex == matchingBrace.Value.That.Char
					)
				)
			) ApplyStyle(ref pass, Scheme.Style.Match);
			
			if (pass.Found) ApplyStyle(ref pass, Scheme.Style.Found);
			if (pass.FoundAlt) ApplyStyle(ref pass, Scheme.Style.FoundAlt);
			
			if (IsSelected(pass.Index.Line, pass.CharIndex)) ApplyStyle(ref pass, Scheme.Style.Selected);
			
			if (pass.Char == '\t') { if (showSpace) DrawTab(ref pass); }
			else if (pass.CharMeta.IsSpace) {
				if (showSpace) {
					if (pass.Char == ' ') DrawSpace(ref pass);
					else DrawSpecialChar(ref pass);
				}
			} else if (pass.CharMeta.IsSpecial) {
				if (showControl) DrawSpecialChar(ref pass);
			} else DrawChar(ref pass);
			
			pass.VisualX += span;
			pass.Table.X += span;
			pass.Pixel.X += pass.Rect.Width;
		}
		
		void DrawTab (ref TextRenderPass pass)
		{
			int ym = pass.Pixel.Y + half.Height;
			int y0 = ym - quarter.Height;
			int y1 = ym + quarter.Height;
			
			int x0 = pass.Pixel.X;
			int x1 = x0 + pass.Rect.Width - 1;
			
			x0 += quarter.Width;
			x1 -= quarter.Width;
			
			int xm = x1 - half.Width;
			
			display.DrawLine(pass.ForePen, x0, ym, x1, ym);
			display.DrawLine(pass.ForePen, x1, ym, xm, y0);
			display.DrawLine(pass.ForePen, x1, ym, xm, y1);
		}
		
		void DrawSpace (ref TextRenderPass pass)
		{
			display.FillRectangle(pass.ForeBrush, pass.Pixel.X + half.Width - 1, pass.Pixel.Y + half.Height - 1, 2, 2);
		}
		
		void DrawChar (ref TextRenderPass pass)
		{
			display.DrawChar(pass.Char, fonts[pass.Font], pass.ForeBrush, pass.Pixel.X, pass.Pixel.Y);
		}
		
		void DrawSpecialChar (ref TextRenderPass pass)
		{
			string abbr = Abc.GetCodeOrAbbr(pass.Char);
			
			int ai = 0;
			
			display.DrawChar(abbr[ai++], halfFont, pass.ForeBrush, pass.Pixel.X, pass.Pixel.Y);
			if (abbr.Length >= 3) display.DrawChar(abbr[ai++], halfFont, pass.ForeBrush, pass.Pixel.X + half.Width, pass.Pixel.Y);
			if (abbr.Length == 4) display.DrawChar(abbr[ai++], halfFont, pass.ForeBrush, pass.Pixel.X, pass.Pixel.Y + half.Height);
			display.DrawChar(abbr[ai++], halfFont, pass.ForeBrush, pass.Pixel.X + half.Width, pass.Pixel.Y + half.Height);
		}
		
		int Zmod (int x)
		{
			int mod = x % D.IndentSize;
			return mod == 0 ? D.IndentSize : mod;
		}
		
	#endregion
	
	
	#region User
		
		bool selecting = false;
		
		public event Action<Point> ContextRequested = (p) => {};
		public event Action<Point> NumbersContextRequested = (p) => {};
		
		public string ExportSelected ()
		{
			return D.Export(selectionStart, selectionEnd);
		}
		
		public void CopySelected ()
		{
			if (!selected) return;
			Clipboard.SetText(ExportSelected());
		}
		
		public void CutSelected ()
		{
			if (!selected) return;
			CopySelected();
			scrollToCaret = true;
			D.Remove(selectionStart, selectionEnd);
			ResetSelection();
		}
		
		public void Paste ()
		{
			if (!Clipboard.ContainsText()) return;
			string pasta = Clipboard.GetText();
			
			D.CommitChanges();
			D.StartOperation();
			
			if (autoPasteIndent)
			{
				string[] plines = pasta.SplitToLines();
				
				string srcBase = ExtractIndent(plines[0]);
				string dstBase = ExtractIndent(D[selectionStart.Line].Text);
				
				for (int i = 1; i < plines.Length; i++)
				{
					string cur = ExtractIndent(plines[i]);
					
					if (cur.Length == 0) { srcBase = ""; break; }
					if (cur.Length < srcBase.Length) srcBase = cur;
				}
				
				for (int i = selectionStart.Line + 1; i <= selectionEnd.Line; i++)
				{
					string cur = ExtractIndent(D[i].Text);
					
					if (cur.Length == 0) { dstBase = ""; break; }
					if (cur.Length < dstBase.Length) dstBase = cur;
				}
				
				if (selectionStart.Char > 0 && selectionStart.Char < dstBase.Length)
					dstBase = dstBase.Substring(0, selectionStart.Char);
				
				if (selectionStart.Char <= dstBase.Length)
					plines[0] = plines[0].Substring(ExtractIndent(plines[0]).Length);
				
				if (dstBase.Length > selectionStart.Char)
					plines[0] = dstBase.Substring(0, dstBase.Length - selectionStart.Char) + plines[0];
				
				for (int i = 1; i < plines.Length; i++)
					plines[i] = dstBase + plines[i].Substring(srcBase.Length);
				
				pasta = String.Join(D.Newline, plines);
			}
			
			if (selected) RemoveSelected();
			
			caret = D.Insert(caret, pasta);
			scrollToCaret = true;
			
			D.EndOperation();
			D.CommitChanges();
		}
		
		void RemoveSelected ()
		{
			caret = selectionStart;
			D.CommitChanges();
			scrollToCaret = true;
			D.Remove(selectionStart, selectionEnd);
			ResetSelection();
		}
		
		public void Type (string input)
		{
			D.StartOperation();
			
			if (selected) RemoveSelected();
			else if (
				overwrite && caret.Char < D[caret.Line].Length
			) D.Remove(caret, new Pos(caret.Line, caret.Char + 1));
			
			D.Insert(caret, input);
			
			scrollToCaret = true;
			D.EndOperation();
		}
		
		public void Indent ()
		{
			D.CommitChanges();
			D.StartOperation();
			string ins = D.IndentWithSpaces ? new string(' ', D.IndentSize) : "\t";
			for (int li = selectionStart.Line; li <= selectionEnd.Line; li++) D.Insert(new Pos(li, 0), ins);
			scrollToCaret = true;
			D.EndOperation();
		}
		
		public void Unindent ()
		{
			D.CommitChanges();
			D.StartOperation();
			
			for (int li = selectionStart.Line; li <= selectionEnd.Line; li++)
			{
				Line l = D[li];
				
				if (l.Length == 0) continue;
				else if (l.Text[0] == '\t') D.Remove(new Pos(li, 0), new Pos(li, 1));
				else if (l.Text[0] == ' ')
				{
					int count = 0;
					while (count < D.IndentSize && count < l.Length && l.Text[count] == ' ') count++;
					D.Remove(new Pos(li, 0), new Pos(li, count));
				}
			}
			
			scrollToCaret = true;
			D.EndOperation();
		}
		
		public void Backspace ()
		{
			scrollToCaret = true;
			if (selected) RemoveSelected();
			else if (caret.Char > 0) D.Remove(new Pos(caret.Line, caret.Char - 1), caret);
			else if (caret.Line > 0) D.Remove(new Pos(caret.Line - 1, D[caret.Line - 1].Length), caret);
		}
		
		public void LineBackspace ()
		{
			scrollToCaret = true;
			if (selected) RemoveSelected();
			else if (caret.Char > 0) D.Remove(new Pos(caret.Line, 0), caret);
			else if (caret.Line > 0) D.Remove(new Pos(caret.Line - 1, 0), caret);
		}
		
		public void WordBackspace ()
		{
			scrollToCaret = true;
			if (selected) RemoveSelected();
			else if (caret.Char > 0) {
				Limits wl = D[caret.Line].FindWordBounds(caret.Char - 1);
				D.Remove(new Pos(caret.Line, wl.Start), caret);
			} else if (caret.Line > 0) {
				Limits wl = D[caret.Line - 1].FindWordBounds(D[caret.Line - 1].Length);
				D.Remove(new Pos(caret.Line - 1, wl.Start), caret);
			}
		}
		
		public void Delete ()
		{
			if (selected) RemoveSelected();
			else if (caret.Char < D[caret.Line].Length) D.Remove(caret, new Pos(caret.Line, caret.Char + 1));
			else if (caret.Line + 1 < D.Count) D.Remove(caret, new Pos(caret.Line + 1, 0));
		}
		
		public void LineDelete ()
		{
			if (selected) RemoveSelected();
			else if (caret.Char < D[caret.Line].Length) D.Remove(caret, new Pos(caret.Line, D[caret.Line].Length));
			else if (caret.Line + 1 < D.Count) D.Remove(caret, new Pos(caret.Line + 1, D[caret.Line + 1].Length));
		}
		
		public void WordDelete ()
		{
			if (selected) RemoveSelected();
			else if (caret.Char < D[caret.Line].Length) {
				Limits wl = D[caret.Line].FindWordBounds(caret.Char);
				D.Remove(caret, new Pos(caret.Line, wl.End));
			} else if (caret.Line + 1 < D.Count) {
				Limits wl = D[caret.Line + 1].FindWordBounds(0);
				D.Remove(caret, new Pos(caret.Line + 1, wl.End));
			}
		}
		
		string ExtractIndent (string l) { return ExtractIndent(l, 0, l.Length); }
		string ExtractIndent (string l, int start) { return ExtractIndent(l, start, l.Length); }
		string ExtractIndent (string l, int start, int end)
		{
			if (end > l.Length) end = l.Length;
			StringBuilder ind = new StringBuilder("");
			
			for (int ci = start; ci < end; ci++)
			{
				char c = l[ci];
				if (c != ' ' && c != '\t') break;
				ind.Append(c);
			}
			
			return ind.ToString();
		}
		
		public void InsertLineBreak ()
		{
			D.CommitChanges();
			D.StartOperation();
			
			if (selected) RemoveSelected();
			
			Line cur = D[caret.Line];
			Line nln = caret.Line < D.Count - 1 ? D[caret.Line + 1] : null;
			
			string ind = ExtractIndent(cur.Text);
			
			if (nln != null)
			{
				string nind = ExtractIndent(nln.Text, 0, caret.Char);
				if (nind.Length > ind.Length) ind = nind;
			}
			
			Pos next = D.Insert(caret, "\n");
			D.Insert(next, ind);
			
			scrollToCaret = true;
			D.EndOperation();
		}
		
		public void DuplicateLine ()
		{
			D.CommitChanges();
			Pos lend = new Pos(caret.Line, D[caret.Line].Length);
			D.Insert(lend, "\n" + D[caret.Line].Export());
		}
		
		public void LineComment ()
		{
			if (!D.Scheme.LineCommentSupported) return;
			
			D.CommitChanges();
			D.StartOperation();
			D.Scheme.LineComment(D, selectionStart.Line, selectionEnd.Line);
			D.EndOperation();
		}
		
		public void StreamComment ()
		{
			if (!D.Scheme.StreamCommentSupported) return;
			
			D.CommitChanges();
			D.StartOperation();
			Range r = D.Scheme.StreamComment(D, selectionStart, selectionEnd);
			Select(r.Start, r.End);
			D.EndOperation();
		}
		
		public void GoTo (int li, int ci)
		{
			if (li < 0) li = 0;
			if (ci < 0) ci = 0;
			
			if (li >= D.Count) li = D.Count - 1;
			if (ci > D[li].Length) ci = D[li].Length;
			
			D.CommitChanges();
			Select(new Pos(li, ci));
			
			scrollToCaret = true;
			Invalidate();
		}
		
		public void GoToLineStart ()
		{
			GoTo(caret.Line, 0);
		}
		
		public void GoToLineEnd ()
		{
			GoTo(caret.Line, D[caret.Line].Length - 1);
		}
		
		public void GoToStart ()
		{
			GoTo(0, 0);
		}
		
		public void GoToEnd ()
		{
			GoTo(D.Count - 1, D[D.Count - 1].Length);
		}
		
		public void GoToCaret ()
		{
			ScrollToCaret();
			Invalidate();
		}
		
		public void ToggleMark ()
		{
			Line ml = D[caret.Line];
			
			if (ml.Marked) {
				D.RemoveMark(caret.Line);
				return;
			}
			
			string name;
			
			if (selected && selectionStart.Line == selectionEnd.Line) name = ExportSelected();
			else name = ml.Export();
			
			name = name.Trim();
			if (name.Length > 64) name = name.Substring(0, 64) + "…";
			
			D.SetMark(caret.Line, name);
		}
		
		public void GoToMark (int mi)
		{
			if (mi >= D.Marks.Count) return;
			int li = D.IndexOf(D.Marks[mi]);
			GoTo(li, 0);
		}
		
	#endregion
}