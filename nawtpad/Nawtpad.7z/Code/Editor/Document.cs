using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Document : List<Line>
{
	public Document () { Open(null); }
	public Document (string path) { Open(path); }
	
	#region Updates
		
		bool operating = false;
		public bool Operating { get { return operating; } }
		public event Action Updated = () => {};
		
		public void StartOperation ()
		{
			operating = true;
		}
		
		public void EndOperation ()
		{
			operating = false;
			BroadcastUpdate();
		}
		
		void BroadcastUpdate ()
		{
			if (!operating) Updated();
		}
		
		bool unsaved = false;
		public bool Unsaved { get { return unsaved; } }
		void SetUnsaved (bool u) { if (unsaved != u) { unsaved = u; UnsavedChanged(); } }
		public event Action UnsavedChanged = () => {};
		
	#endregion
	
	#region Properties
		
		static bool defaultSaveBom = false;
		static Encoding defaultEncoding = Encoding.UTF8;
		static string defaultNewline = "\n";
		static string defaultScheme = "Plain";
		
		static public event Action DefaultSaveBomChanged = () => {};
		static public event Action DefaultEncodingChanged = () => {};
		static public event Action DefaultNewlineChanged = () => {};
		static public event Action DefaultSchemeChanged = () => {};
		
		static public bool DefaultSaveBom
		{
			get { return defaultSaveBom; }
			set { defaultSaveBom = value; DefaultSaveBomChanged(); }
		}
		
		static public Encoding DefaultEncoding
		{
			get { return defaultEncoding; }
			set { defaultEncoding = value; DefaultEncodingChanged(); }
		}
		
		static public string DefaultNewline
		{
			get { return defaultNewline; }
			set { defaultNewline = value; DefaultNewlineChanged(); }
		}
		
		static public string DefaultScheme
		{
			get { return defaultScheme; }
			set { defaultScheme = value; DefaultSchemeChanged(); }
		}
		
		bool saveBom = defaultSaveBom;
		Encoding encoding = defaultEncoding;
		string newline = defaultNewline;
		Scheme scheme;
		
		public event Action SaveBomChanged = () => {};
		public event Action EncodingChanged = () => {};
		public event Action NewlineChanged = () => {};
		public event Action SchemeChanged = () => {};
		
		public bool SaveBom
		{
			get { return saveBom; }
			set { saveBom = value; SaveBomChanged(); }
		}
		
		public Encoding Encoding
		{
			get { return encoding; }
			set { encoding = value; EncodingChanged(); }
		}
		
		public string Newline
		{
			get { return newline; }
			set { newline = value; NewlineChanged(); }
		}
		
		public Scheme Scheme
		{
			get { return scheme; }
			set { scheme = value; scheme.Prepare(this); SchemeChanged(); Updated(); }
		}
		
	#endregion
	
	#region Lines
		
		public readonly List<Line> Marks = new List<Line>();
		
		public event Action MarksChanged = () => {};
		public event Action MarksChangedInternally = () => {};
		
		public event Action LinesCleared = () => {};
		public event IndexLineHandler LineAdded = (i, l) => {};
		public event IndexLineHandler LineUpdated = (i, l) => {};
		public event LineRangeHandler LinesRemoved = (at, n) => {};
		
		public delegate void LineHandler (Line l);
		public delegate void IndexLineHandler (int li, Line l);
		public delegate void LineRangeHandler (int at, int n);
		
		public void AppendLine (Line l)
		{
			Add(l); int li = Count - 1;
			LineAdded(li, l);
		}
		
		public void InsertLine (int at, Line l)
		{
			Insert(at, l);
			LineAdded(at, l);
		}
		
		public void RemoveLines (int at, int n)
		{
			bool mcha = false;
			
			for (int li = at; li < at + n; li++)
			{
				Line l = base[li];
				
				if (l.Marked && Marks.Contains(l))
				{
					Marks.Remove(l);
					mcha = true;
				}
			}
			
			RemoveRange(at, n);
			LinesRemoved(at, n);
			
			if (mcha) MarksChangedInternally();
		}
		
		public void ClearLines ()
		{
			if (Marks.Count > 0)
			{
				Marks.Clear();
				MarksChangedInternally();
			}
			
			base.Clear();
			LinesCleared();
		}
		
		public void SetMark (int li, string name)
		{
			Line l = base[li];
			
			l.Marked = true;
			l.MarkName = name;
			
			if (!Marks.Contains(l)) Marks.Add(l);
			
			MarksChanged();
		}
		
		public void RemoveMark (int li)
		{
			Line l = base[li];
			
			l.Marked = false;
			l.MarkName = null;
			
			if (Marks.Contains(l)) Marks.Remove(l);
			
			MarksChanged();
		}
		
		public void ClearMarks ()
		{
			foreach (Line l in Marks)
			{
				l.Marked = false;
				l.MarkName = null;
			}
			
			Marks.Clear();
			MarksChanged();
		}
		
	#endregion
	
	#region Indentation
		
		static bool detectIndent = true;
		static public event Action DetectIndentChanged = () => {};
		static public bool DetectIndent {
			get { return detectIndent; }
			set {
				detectIndent = value;
				DetectIndentChanged();
			}
		}
		
		
		static bool defaultIndentWithSpaces = false;
		static public event Action DefaultIndentWithSpacesChanged = () => {};
		static public bool DefaultIndentWithSpaces {
			get { return defaultIndentWithSpaces; }
			set {
				defaultIndentWithSpaces = value;
				DefaultIndentWithSpacesChanged();
			}
		}
		
		static int defaultIndentSize = 4;
		static public event Action DefaultIndentSizeChanged = () => {};
		static public int DefaultIndentSize {
			get { return defaultIndentSize; }
			set {
				defaultIndentSize = value;
				DefaultIndentSizeChanged();
			}
		}
		
		
		bool indentWithSpaces = defaultIndentWithSpaces;
		public event Action IndentWithSpacesChanged = () => {};
		public bool IndentWithSpaces {
			get { return indentWithSpaces; }
			set {
				indentWithSpaces = value;
				IndentWithSpacesChanged();
			}
		}
		
		int indentSize = defaultIndentSize;
		public event Action IndentSizeChanged = () => {};
		public int IndentSize {
			get { return indentSize; }
			set {
				indentSize = value;
				IndentSizeChanged();
			}
		}
		
		
		void AutoDetectIndent ()
		{
			indentSize = defaultIndentSize;
			indentWithSpaces = defaultIndentWithSpaces;
			
			for (int i = 1; i < Count; i++)
			{
				Line l = base[i];
				if (l.Length == 0) continue;
				
				char c0 = l.Text[0];
				
				if (c0 == '\t')
				{
					indentWithSpaces = false;
					break;
				}
				else if (c0 == ' ')
				{
					int cnt = 0; while (cnt < l.Length && cnt <= 9)
					{
						if (l.Text[cnt] != ' ') break;
						cnt++;
					}
					
					if (cnt >= 2 && cnt < 9)
					{
						indentWithSpaces = true;
						indentSize = cnt;
						break;
					}
				}
			}
			
			IndentWithSpacesChanged();
			IndentSizeChanged();
		}
		
	#endregion
	
	#region History
		
		int historyPosition = 0;
		List<List<Change>> history = new List<List<Change>>();
		List<Change> pendingChanges = null;
		int savePosition = 0;
		
		public bool CanUndo { get { return historyPosition > 0 || pendingChanges != null; } }
		public bool CanRedo { get { return historyPosition < history.Count; } }
		
		public void CommitChanges ()
		{
			if (pendingChanges == null || pendingChanges.Count == 0) return;
			if (historyPosition < history.Count) history.RemoveRange(historyPosition, history.Count - historyPosition);
			history.Add(pendingChanges);
			pendingChanges = null;
			historyPosition++;
		}
		
		void Remember (ChangeType type, Pos start, Pos end)
		{
			if (pendingChanges == null) pendingChanges = new List<Change>();
			pendingChanges.Add(new Change(type, start, Export(start, end), end));
			SetUnsaved(true);
		}
		
		void DoRemove (Change c)
		{
			ServiceRemove(c.Start, c.End);
		}
		
		void DoAdd (Change c)
		{
			ServiceInsert(c.Start, c.Content);
		}
		
		void Undo (Change un)
		{
			switch (un.Type)
			{
				case ChangeType.Removed: DoAdd(un); break;
				case ChangeType.Added: DoRemove(un); break;
			}
		}
		
		void Redo (Change re)
		{
			switch (re.Type)
			{
				case ChangeType.Added: DoAdd(re); break;
				case ChangeType.Removed: DoRemove(re); break;
			}
		}
		
		public void Undo ()
		{
			CommitChanges();
			if (historyPosition == 0) return;
			List<Change> uns = history[--historyPosition];
			for (int i = uns.Count - 1; i >= 0; --i) Undo(uns[i]);
			SetUnsaved(historyPosition != savePosition);
			BroadcastUpdate();
		}
		
		public void Redo ()
		{
			if (historyPosition >= history.Count) return;
			List<Change> res = history[historyPosition++];
			for (int i = 0; i < res.Count; ++i) Redo(res[i]);
			SetUnsaved (historyPosition != savePosition);
			BroadcastUpdate();
		}
		
		void ClearHistory ()
		{
			historyPosition = 0;
			history = new List<List<Change>>();
			pendingChanges = null;
		}
		
	#endregion
	
	#region Files
		
		public event Action Loaded = () => {};
		public event Action<Exception> SavingFailed;
		public event Func<bool> OverwritingModified;
		
		DateTime lastWriteTime;
		
		string fileName = "Untitled";
		string filePath = null;
		string fileExtension = "";
		
		public string FileName { get { return fileName; } }
		public string FilePath { get { return filePath; } }
		public string FileExtension { get { return fileExtension; } }
		
		public delegate void OldNewPathHandler (string op, string np);
		public event OldNewPathHandler FilePathChanged = (op, np) => {};
		
		void SetFilePath (string path)
		{
			string old = filePath;
			filePath = path;
			
			if (path != null) fileName = System.IO.Path.GetFileName(path);
			fileExtension = Path.GetExtension(fileName).Trim('.').ToLower();
			
			FilePathChanged(old, path);
		}
		
		void Load (string path)
		{
			byte[] raw;
			
			try {
				if (Directory.Exists(path)) throw new Exception("%0 is a directory.");
				raw = File.ReadAllBytes(path);
			} catch (Exception e) { throw e; }
			
			StartOperation();
			
			SetFilePath(path);
			lastWriteTime = File.GetLastWriteTime(path);
			
			MemoryStream ms = new MemoryStream(raw);
			StreamReader sr = new StreamReader(ms, encoding);
			
			string src = sr.ReadToEnd();
			encoding = sr.CurrentEncoding;
			
			byte[] pre = sr.CurrentEncoding.GetPreamble();
			if (pre.Length > raw.Length) saveBom = false;
			else
			{
				for (int i = 0; i < pre.Length; i++)
				{
					if (raw[i] == pre[i]) saveBom = true;
					else { saveBom = false; break; }
				}
			}
			
			EncodingChanged();
			SaveBomChanged();
			
			sr.Close();
			ms.Close();
			
			if (src.Contains("\r\n")) Newline = "\r\n";
			else if (src.Contains("\r")) Newline =  "\r";
			else Newline = "\n";
			
			SetUnsaved(false);
			
			ClearHistory();
			ClearLines();
			
			string[] sls = src.SplitToLines();
			foreach (string sl in sls) AppendLine(new Line(sl));
			
			if (detectIndent) AutoDetectIndent();
			
			scheme = Scheme.Detect(this);
			scheme.Prepare(this);
			SchemeChanged();
			
			Loaded();
			EndOperation();
		}
		
		public void Reload ()
		{
			Load(FilePath);
		}
		
		public void Open (string path)
		{
			if (path != null) Load(path);
			else {
				SetFilePath(path);
				AppendLine(new Line());
				scheme = Scheme.FromID(defaultScheme);
				SchemeChanged();
			}
		}
		
		public bool Save ()
		{
			return SaveTo(filePath);
		}
		
		public bool SaveAs (string path)
		{
			SetFilePath(path);
			return SaveTo(path);
		}
		
		public bool SaveTo (string path)
		{
			string[] all = new string[this.Count];
			for (int i = 0; i < this.Count; ++i) all[i] = this[i].Export();
			byte[] raw = encoding.GetBytes(string.Join(newline, all));
			
			try {
				
				if (
					File.Exists(path) &&
					lastWriteTime != File.GetLastWriteTime(path)
				) {
					if (
						OverwritingModified != null &&
						!OverwritingModified()
					) return false;
				}
				
				using (FileStream fs = File.Open(path, FileMode.OpenOrCreate))
				using (BinaryWriter w = new BinaryWriter(fs))
				{
					if (saveBom) w.Write(encoding.GetPreamble());
					w.Write(raw);
					fs.SetLength(fs.Position);
				}
				
				lastWriteTime = File.GetLastWriteTime(path);
				
			} catch (Exception e) {
				if (SavingFailed != null) SavingFailed(e); else throw e;
				return false;
			}
			
			CommitChanges();
			savePosition = historyPosition;
			SetUnsaved(false);
			
			return true;
		}
		
	#endregion
	
	#region Actions
		
		public event Range.Action Removed = (r) => {};
		public event Range.Action Inserted = (r) => {};
		
		void ServiceRemove (Pos start, Pos end)
		{
			Line sl = base[start.Line];
			Line el = base[end.Line];
			
			if (sl == el) sl.RemoveRange (start.Char, end.Char - start.Char);
			else
			{
				sl.RemoveRange(start.Char, sl.Length - start.Char);
				for (int ci = end.Char; ci < el.Length; ci++) sl.Append(el.Meta[ci], el.Text[ci]);
				RemoveLines(start.Line + 1, end.Line - start.Line);
			}
			
			scheme.Parse(this, start.Line);
			LineUpdated(start.Line, sl);
			
			Removed(new Range(start, end));
		}
		
		Pos ServiceInsert (Pos at, string s)
		{
			string[] ss = s.SplitToLines();
			
			Line first = base[at.Line];
			
			if (ss.Length > 1)
			{
				Line tail = first.Cut(at.Char);
				first.Append(ss[0]);
				
				int sli = 1;
				int dli = at.Line + 1;
				
				while (sli < ss.Length - 1)
				{
					InsertLine(dli, new Line(ss[sli]));
					sli++; dli++;
				}
				
				InsertLine(dli, tail);
				tail.Insert(0, ss[sli]);
				scheme.Parse(this, at.Line);
				
				LineUpdated(at.Line, first);
				
				Pos end = new Pos(dli, ss[sli].Length);
				Inserted(new Range(at, end));
				return end;
			}
			else
			{
				first.Insert(at.Char, s);
				scheme.Parse(this, at.Line);
				
				LineUpdated(at.Line, first);
				
				Pos end = new Pos(at.Line, at.Char + s.Length);
				Inserted(new Range(at, end));
				return end;
			}
		}
		
		public void Remove (Pos start, Pos end)
		{
			Remember(ChangeType.Removed, start, end);
			ServiceRemove(start, end);
			BroadcastUpdate();
		}
		
		public Pos Insert (Pos at, string txt)
		{
			Pos end = ServiceInsert(at, txt);
			Remember(ChangeType.Added, at, end);
			BroadcastUpdate();
			return end;
		}
		
		public string Export (Pos beg, Pos end)
		{
			string[] ss = new string[1 + end.Line - beg.Line];
			
			for (int sli = beg.Line, dli = 0; sli <= end.Line; sli++, dli++)
			{
				Line l = base[sli];
				
				int b = (beg.Line == sli) ? beg.Char : 0;
				int e = (end.Line == sli) ? end.Char : l.Length;
				
				ss[dli] = l.Export(b, e);
			}
			
			return string.Join(Environment.NewLine, ss);
		}
		
	#endregion
}