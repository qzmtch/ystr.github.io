using System.Collections.Generic;

class Pass
{
	public string Mode = "Normal";
	public readonly List<string> Flags = new List<string>();
	
	public Pass () { }
	public Pass (Pass clone)
	{
		if (clone == null) return;
		foreach (string flag in clone.Flags) Flags.Add(flag);
		Mode = clone.Mode;
	}
	
	public static bool Equal (Pass p1, Pass p2)
	{
		if (p1 == null && p2 == null) return true;
		if (p1 == null || p2 == null) return false;
		
		if (p1.Mode != p2.Mode) return false;
		if (p1.Flags.Count != p2.Flags.Count) return false;
		foreach (string f in p1.Flags) if (!p2.Flags.Contains(f)) return false;
		
		return true;
	}
}