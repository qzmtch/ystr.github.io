struct Stride
{
	public Pos Source;
	
	public int VisualStart;
	public int VisualLength;
}