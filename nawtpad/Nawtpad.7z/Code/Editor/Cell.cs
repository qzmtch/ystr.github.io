using System;

struct Cell
{
	public int X;
	public int Y;
	
	public Cell (int x, int y)
	{
		X = x;
		Y = y;
	}
	
	static public bool operator == (Cell p1, Cell p2)
	{
		return p1.X == p2.X && p1.Y == p2.Y;
	}
	
	static public bool operator != (Cell p1, Cell p2)
	{
		return !(p1 == p2);
	}
	
	public override int GetHashCode () { return X ^ Y; }
	public override bool Equals (object o) { return (Cell) o == this; }
}