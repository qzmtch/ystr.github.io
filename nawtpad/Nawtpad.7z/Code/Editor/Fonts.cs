using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

static class Fonts
{
	static public Size GetCharMetrics (this Font f)
	{
		SizeF s2 = TextRenderer.MeasureText(":3", f);
		SizeF s3 = TextRenderer.MeasureText("^_^", f);
		
		return new Size((int) Math.Round(s3.Width - s2.Width), (int) s2.Height);
	}
	
	static public void DrawChar (this Graphics g, char c, Font font, Brush brush, int x, int y)
	{
		g.DrawString(c.ToString(), font, brush, x, y, StringFormat.GenericTypographic);
	}
}