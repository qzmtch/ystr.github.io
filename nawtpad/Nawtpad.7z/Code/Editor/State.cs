using System;
using System.Collections.Generic;

class State : List <Condition>
{
	public string LineCommentStart = null;
	public string LineCommentEnd = null;
	public string StreamCommentStart = null;
	public string StreamCommentEnd = null;
}