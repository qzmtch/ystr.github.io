struct Index
{
	public int Line;
	public int Sub;
}