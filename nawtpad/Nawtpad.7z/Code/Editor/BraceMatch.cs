using System;

struct BraceMatch
{
	public readonly Pos Self;
	public readonly Pos That;
	
	public BraceMatch (Pos self, Pos that)
	{
		Self = self;
		That = that;
	}
}