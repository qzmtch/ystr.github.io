using System.Collections.Generic;
using System.Globalization;

class CharMeta
{
	public readonly byte Flags = 0;
	
	public byte Style = 0;
	
	const byte spaceFlag = 1 << 0;
	const byte specialFlag = 1 << 1;
	const byte wordPartFlag = 1 << 2;
	const byte breakerFlag = 1 << 3;
	const byte numberFlag = 1 << 4;
	
	public bool IsSpace { get { return Check(spaceFlag); } }
	public bool IsSpecial { get { return Check(specialFlag); } }
	public bool IsWordPart { get { return Check(wordPartFlag); } }
	public bool IsBreaker { get { return Check(breakerFlag); } }
	public bool IsNumber { get { return Check(numberFlag); } }
	
	public CharMeta (char c)
	{
		switch (c)
		{
			case '\t': Flags = spaceFlag | breakerFlag; break;
			case ' ': Flags = spaceFlag | breakerFlag; break;
			case '_': Flags = wordPartFlag; break;
			
			case Abc.NBSP:
			case Abc.NNBSP:
				
				Flags = specialFlag;
				
			break;
			
			default:
				
				switch (char.GetUnicodeCategory(c))
				{
					case UnicodeCategory.UppercaseLetter:
					case UnicodeCategory.LowercaseLetter:
					case UnicodeCategory.TitlecaseLetter:
					case UnicodeCategory.ModifierLetter:
					case UnicodeCategory.OtherLetter:
					case UnicodeCategory.NonSpacingMark:
					case UnicodeCategory.LetterNumber:
					case UnicodeCategory.OtherNumber:
						
						Flags = wordPartFlag;
						
					break;
					
					case UnicodeCategory.DecimalDigitNumber:
						
						Flags = wordPartFlag | numberFlag;
						
					break;
					
					case UnicodeCategory.Control:
					case UnicodeCategory.Format:
					case UnicodeCategory.LineSeparator:
					case UnicodeCategory.ParagraphSeparator:
					case UnicodeCategory.Surrogate:
					case UnicodeCategory.PrivateUse:
					case UnicodeCategory.OtherNotAssigned:
					case UnicodeCategory.SpaceSeparator:
						
						Flags = specialFlag | breakerFlag;
						
					break;
					
					case UnicodeCategory.DashPunctuation:
					case UnicodeCategory.OpenPunctuation:
					case UnicodeCategory.ClosePunctuation:
					case UnicodeCategory.ConnectorPunctuation:
					case UnicodeCategory.OtherPunctuation:
					case UnicodeCategory.MathSymbol:
					case UnicodeCategory.InitialQuotePunctuation:
					case UnicodeCategory.FinalQuotePunctuation:
					case UnicodeCategory.SpacingCombiningMark:
					case UnicodeCategory.EnclosingMark:
					case UnicodeCategory.CurrencySymbol:
					case UnicodeCategory.ModifierSymbol:
					case UnicodeCategory.OtherSymbol:
						
						Flags = 0;
						
					break;
				}
				
			break;
		}
	}
	
	bool Check (byte flag)
	{
		return (Flags & flag) == flag;
	}
}