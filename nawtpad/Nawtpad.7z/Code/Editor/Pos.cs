using System;

struct Pos : IComparable
{
	public int Line;
	public int Char;
	
	public Pos (int li, int ci)
	{
		Line = li;
		Char = ci;
	}
	
	public void AdjustAfterRemoval (Pos start, Pos end)
	{
		if (this < start) return;
		if (this <= end) this = start;
		else {
			Line -= end.Line - start.Line;
			if (Line == start.Line) Char -= end.Char - start.Char;
		}
	}
	
	public void AdjustAfterAddition (Pos start, Pos end)
	{
		if (this < start) return;
		Line += end.Line - start.Line;
		if (Line == end.Line) Char += end.Char - start.Char;
	}
	
	public int CompareTo (object o)
	{
		Pos to = (Pos) o;
		
		if (Line < to.Line) return -1;
		else if (Line > to.Line) return +1;
		else {
			if (Char < to.Char) return -1;
			else if (Char > to.Char) return +1;
			else return 0;
		}
	}
	
	static public bool operator > (Pos p1, Pos p2) { return p1.CompareTo(p2) > 0; }
	static public bool operator < (Pos p1, Pos p2) { return p1.CompareTo(p2) < 0; }
	static public bool operator <= (Pos p1, Pos p2) { return p1.CompareTo(p2) <= 0; }
	static public bool operator >= (Pos p1, Pos p2) { return p1.CompareTo(p2) >= 0; }
	static public bool operator == (Pos p1, Pos p2) { return p1.Line == p2.Line && p1.Char == p2.Char; }
	static public bool operator != (Pos p1, Pos p2) { return !(p1 == p2); }
	
	public override int GetHashCode () { return Line ^ Char; }
	public override bool Equals (object o) { return (Pos) o == this; }
	
	public override string ToString ()
	{
		return Line.ToString() + " " + Char.ToString();
	}
}