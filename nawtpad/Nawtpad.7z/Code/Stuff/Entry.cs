abstract class Entry
{
	string icon = null;
	string name = null;
	string abbr = null;
	string keys = null;
	
	public string Keys
	{
		get { return keys; }
		set { keys = value; }
	}
	
	public string Name
	{
		get { return name ?? abbr; }
		set { name = value; }
	}
	
	public string Abbr
	{
		get { return abbr ?? name; }
		set { abbr = value; }
	}
	
	public string Icon
	{
		get { return icon ?? abbr ?? name; }
		set { icon = value; }
	}
	
	public abstract string AsString { get; }
}