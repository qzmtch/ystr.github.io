class Option <T> : Entry
{
	T value;
	
	public event System.Action <T> Changed;
	public event System.Action Changed_;
	
	public T Value
	{
		get { return value; }
		set {
			this.value = value;
			if (Changed != null) Changed(value);
			if (Changed_ != null) Changed_();
		}
	}
	
	public Option (T value)
	{
		this.value = value;
	}
	
	public override string AsString
	{
		get { return this.value.ToString(); }
	}
}