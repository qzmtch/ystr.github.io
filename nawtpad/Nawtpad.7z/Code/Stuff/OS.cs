using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

using Microsoft.Win32;

static class OS
{
	static string oldTheme = Theme;
	static int oldCaretBlinkInterval = CaretBlinkInterval;
	
	public static event Action ThemeChanged;
	public static event Action CaretBlinkIntervalChanged;
	
	public static string Theme { get { return VisualStyleInformation.DisplayName; } }
	public static bool CaretBlinkEnabled { get { return CaretBlinkInterval > 0; } }
	
	public static int CaretBlinkInterval {
		get {
			int cbt = SystemInformation.CaretBlinkTime;
			if (cbt < 0) return 0; else return cbt;
		}
	}
	
	static OS ()
	{
		SystemEvents.UserPreferenceChanged += (o, e) =>
		{
			if (oldTheme != Theme)
			{
				oldTheme = Theme;
				if (ThemeChanged != null) ThemeChanged();
			}
			
			if (oldCaretBlinkInterval != CaretBlinkInterval)
			{
				oldCaretBlinkInterval = CaretBlinkInterval;
				if (CaretBlinkIntervalChanged != null) CaretBlinkIntervalChanged();
			}
		};
	}
	
	public static Color Rip (this Color sysc)
	{
		return Color.FromArgb(sysc.A, sysc.R, sysc.G, sysc.B);
	}
}