using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Globalization;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

static class Own
{
	static readonly Assembly ass = Assembly.GetExecutingAssembly();
	
	public static readonly string Name = null;
	public static readonly string ExePath = ass.Location;
	public static readonly string ExeFile = Path.GetFileName(ExePath);
	public static readonly string ExeDir = Path.GetDirectoryName(ass.Location);
	
	public const string DefaultLocale = "en";
	public const string DefaultLocaleName = "English";
	public const string DefaultSkin = "Default";
	
	static string skin = DefaultSkin;
	static string locale = DefaultLocale;
	
	public static event Action LocaleChanged;
	public static event Action SkinChanged;
	
	public static string Skin
	{
		get { return skin; }
		set {
			cachedText.Clear();
			cachedIcons.Clear();
			cachedImages.Clear();
			skin = value;
			if (SkinChanged != null) SkinChanged();
		}
	}
	
	public static string Locale
	{
		get { return locale; }
		set {
			locale = value;
			LoadLines();
			if (LocaleChanged != null) LocaleChanged();
		}
	}
	
	
	static Stream GetExternal (string path)
	{
		path = ExeDir + "/" + path;
		if (File.Exists(path)) return new FileStream(path, FileMode.Open, FileAccess.Read);
		else return null;
	}
	
	static Stream GetInternal (string path)
	{
		return ass.GetManifestResourceStream(path);
	}
	
	public static Stream Get (string path)
	{
		Stream rstr = GetExternal(path); if (rstr != null) return rstr;
		return GetInternal(path);
	}
	
	
	static string[] ListFilesInternal (string dir)
	{
		dir = dir + "/";
		
		string[] paths = ass.GetManifestResourceNames();
		HashSet<string> files = new HashSet<string>();
		
		foreach (string path in paths)
		{
			if (!path.StartsWith(dir)) continue;
			files.Add(path.Substring(dir.Length).Split('/')[0]);
		}
		
		string[] ar = new string[files.Count];
		files.CopyTo(ar); return ar;
	}
	
	static string[] ListFilesExternal (string dir)
	{
		dir = ExeDir + "/" + dir + "/";
		
		if (!Directory.Exists(dir)) return new string[0];
		string[] files = Directory.GetFileSystemEntries(dir);
		
		for (int i = 0; i < files.Length; i++)
		{
			files[i] = files[i].Substring(dir.Length).Split('/')[0];
		}
		
		return files;
	}
	
	public static string[] ListFiles (string path)
	{
		HashSet<string> dirs = new HashSet<string>();
		
		dirs.UnionWith(ListFilesInternal(path));
		dirs.UnionWith(ListFilesExternal(path));
		
		
		string[] ar = new string[dirs.Count];
		dirs.CopyTo(ar); return ar;
	}
	
	
	public static string[] ListSkins ()
	{
		return ListFiles("Skin");
	}
	
	public static Dictionary<string, string> ListLocales ()
	{
		string[] codes = ListFiles("Local");
		Dictionary<string, string> ts = new Dictionary<string, string>();
		foreach (string code in codes) ts[code] = GetLocaleName(code);
		return ts;
	}
	
	public static string GetLocaleName (string code)
	{
		try { return Text(code + "/Lines.ini").Split('\n')[0].Trim(); }
		catch { return code == DefaultLocale ? DefaultLocaleName : code; }
	}
	
	
	static public string Locate (string name)
	{
		string x;
		
		if (File.Exists(x = ExeDir + "\\Skin\\" + skin + "\\" + name)) return x;
		if (File.Exists(x = ExeDir + "\\Skin\\" + DefaultSkin + "\\" + name)) return x;
		if (File.Exists(x = ExeDir + "\\Local\\" + name)) return x;
		if (File.Exists(x = ExeDir + "\\Local\\" + locale + "\\" + name)) return x;
		if (File.Exists(x = ExeDir + "\\Local\\" + DefaultLocale + "\\" + name)) return x;
		
		return null;
	}
	
	static Stream Fetch (string name)
	{
		Stream rstr;
		
		rstr = Get("Skin/" + skin + "/" + name); if (rstr != null) return rstr;
		rstr = Get("Skin/" + DefaultSkin + "/" + name); if (rstr != null) return rstr;
		rstr = Get("Local/" + name); if (rstr != null) return rstr;
		rstr = Get("Local/" + locale + "/" + name); if (rstr != null) return rstr;
		rstr = Get("Local/" + DefaultLocale + "/" + name); if (rstr != null) return rstr;
		
		return null;
	}
	
	static Stream Fetch (string name, string ext)
	{
		if (name.Contains(".")) return Fetch(name);
		else return Fetch(name + "." + ext);
	}
	
	delegate object StreamAction (Stream s);
	
	static object Fetch (
		string name, string ext,
		Dictionary<string, object> cache,
		StreamAction Action
	) {
		if (cache.ContainsKey(name)) return cache[name];
		
		Stream str = Fetch(name, ext);
		
		if (str == null) cache[name] = null;
		else cache[name] = Action(str);
		
		return cache[name];
	}
	
	static string Read (Stream s)
	{
		using (StreamReader r = new StreamReader(s))
		{
			return r.ReadToEnd();
		}
	}
	
	
	static readonly Dictionary<string, object> cachedText = new Dictionary<string, object>();
	static readonly Dictionary<string, object> cachedImages = new Dictionary<string, object>();
	static readonly Dictionary<string, object> cachedIcons = new Dictionary<string, object>();
	
	
	public static string Text (string name)
	{
		return (string) Fetch (
			name, "txt", cachedText,
			(s) => Read(s)
		);
	}
	
	public static Image Image (string name)
	{
		return (Image) Fetch (
			name, "png", cachedImages,
			(s) => System.Drawing.Image.FromStream(s)
		);
	}
	
	public static Icon Icon (string name)
	{
		return (Icon) Fetch (
			name, "ico", cachedIcons,
			(s) => new System.Drawing.Icon(s)
		);
	}
	
	
	static Dictionary<string, string> lines = new Dictionary<string, string>();
	
	public static string Line (string line) { return TryLine(line, line); }
	public static string TryLine (string line, string fallback)
	{
		if (lines.ContainsKey(line)) return lines[line];
		else return fallback;
	}
	
	public static string Line (string line, params string[] rep)
	{
		line = Line(line);
		for (int i = 0; i < rep.Length; i++) line = line.Replace("%" + i, rep[i]);
		return line;
	}
	
	static void LoadLines ()
	{
		lines.Clear();
		cachedText.Clear();
		
		string lt = Text("Lines.ini");
		if (lt == null) return;
		
		string[] list = lt.Split('\n');
		
		foreach (string line in list)
		{
			if (line.Contains("="))
			{
				string[] pair = line.Split(new char[] {'='}, 2);
				lines[pair[0].Trim()] = pair[1].Trim();
			}
		}
	}
	
	
	static Own ()
	{
		object[] atts = ass.GetCustomAttributes(false);
		
		foreach (object att in atts)
		{
			if (att.GetType() == typeof(AssemblyProductAttribute))
			{
				Name = (att as AssemblyProductAttribute).Product;
				
				#if DEBUG
					Name += ".Debug";
				#endif
			}
		}
	}
}