using System;
using System.IO;
using System.IO.Pipes;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows.Forms;



[assembly: AssemblyTitle("Nawtpad")]
[assembly: AssemblyProduct("Nawtpad")]
[assembly: AssemblyDescription("Code editor")]
[assembly: AssemblyCompany("E Strunnikov")]
[assembly: AssemblyCopyright("GPL3")]

#if !DEBUG
	[assembly: AssemblyVersion("0.14.16.*")]
	[assembly: AssemblyInformationalVersion("0.14.16")]
#endif



class Nawtpad
{
	static Mutex singleInstanceMtx = new Mutex(false, Own.Name);
	static readonly bool singleInstance = singleInstanceMtx.WaitOne(0, false);
	
	static Form dummyForm = new Form();
	static List<Face> faces = new List<Face>();
	static Dictionary<Document, List<Face>> docs = new Dictionary<Document, List<Face>>();
	static Dictionary<string, List<Face>> paths = new Dictionary<string, List<Face>>();
	
	public static int CountInstances (Document d)
	{
		if (!docs.ContainsKey(d)) return 0;
		return docs[d].Count;
	}
	
	static bool remain = false;
	public static event Action RemainChanged = () => {};
	public static bool Remain {
		get { return remain; }
		set {
			remain = value;
			RemainChanged();
		}
	}
	
	public static void Instantiate (Document d)
	{
		List<Face> sess = docs[d];
		Face nf = new Face(d);
		
		nf.Disposed += OnFormDisposed;
		
		sess.Add(nf);
		faces.Add(nf);
		
		nf.Show();
	}
	
	static void OnFormDisposed (object o, EventArgs e)
	{
		Face nf = (Face) o;
		
		List<Face> sess = docs[nf.D];
		
		faces.Remove(nf);
		sess.Remove(nf);
		
		if (sess.Count == 0)
		{
			docs.Remove(nf.D);
			if (nf.D.FilePath != null) paths.Remove(nf.D.FilePath);
		}
		
		nf.Disposed -= OnFormDisposed;
		if (docs.Count == 0) Quit();
	}
	
	static void Quit ()
	{
		if (remain) return;
		Process.GetCurrentProcess().Kill();
	}
	
	static void Repath (Document d, string old)
	{
		List<Face> se = docs[d];
		if (old != null) paths.Remove(old);
		paths[d.FilePath] = se;
	}
	
	static void Start (string path)
	{
		if (path == null)
		{
			Document nd = new Document(null);
			nd.FilePathChanged += (op, np) => Repath(nd, op);
			docs[nd] = new List<Face>();
			Instantiate(nd);
			return;
		}
		
		path = Path.GetFullPath(path);
		
		if (paths.ContainsKey(path)) paths[path][0].Summon();
		else
		{
			#if !DEBUG
			try {
			#endif
				
				Document d = new Document(path);
				d.FilePathChanged += (op, np) => Repath(d, op);
				paths[path] = docs[d] = new List<Face>();
				Instantiate(d);
				
			#if !DEBUG
			}
			catch (Exception e)
			{
				MessageBox.Show (
					Own.Line(e.Message, path),
					Own.Line("Unable to open %0", path),
					MessageBoxButtons.OK, MessageBoxIcon.Error
				);
				
				if (docs.Count == 0) Quit();
			}
			#endif
		}
	}
	
	static void WaitConnection ()
	{
		using (var ps = new NamedPipeServerStream(Own.Name))
		{
			while (true)
			{
				ps.WaitForConnection();
				
				string[] args = (string[]) new BinaryFormatter().Deserialize(ps);
				
				if (args.Length == 0) dummyForm.Sync(() => Start(null));
				else foreach (string arg in args) dummyForm.Sync(() => Start(arg));
				
				ps.Disconnect();
			}
		}
	}
	
	[STAThread] static void Main (string[] args)
	{
		for (int i = 0; i < args.Length; i++) args[i] = Path.GetFullPath(args[i]);
		Directory.SetCurrentDirectory(Own.ExeDir);
		
		if (!singleInstance)
		{
			using (var pc = new NamedPipeClientStream(Own.Name))
			{
				pc.Connect();
				
				new BinaryFormatter().Serialize(pc, args);
				
				pc.Flush();
				pc.Close();
			}
			
			return;
		}
		
		remain = Config.Get("Remain", remain);
		
		Application.EnableVisualStyles();
		
		Own.Skin = Config.Get("Skin", Own.DefaultSkin);
		Own.Locale = Config.Get("Locale", Own.DefaultLocale);
		
		Scheme.Style = new Style(Own.Text("Style.ini"));
		Own.SkinChanged += () => { Scheme.Style = new Style(Own.Text("Style.ini")); };
		
		Document.DefaultIndentWithSpaces = Config.Get("IndentWithSpaces", Document.DefaultIndentWithSpaces);
		Document.DefaultIndentSize = Config.Get("IndentSize", Document.DefaultIndentSize);
		Document.DetectIndent = Config.Get("DetectIndent", Document.DetectIndent);
		Document.DefaultEncoding = Config.Get("DefaultEncoding", Document.DefaultEncoding);
		
		Editor.DefaultShowSpace = Config.Get("ShowSpace", Editor.DefaultShowSpace);
		Editor.DefaultFontName = Config.Get("FontName", Editor.DefaultFontName);
		Editor.DefaultFontSize = Config.Get("FontSize", Editor.DefaultFontSize);
		Editor.DefaultOverwrite = Config.Get("Overwrite", Editor.DefaultOverwrite);
		Editor.DefaultWrap = Config.Get("Wrap", Editor.DefaultWrap);
		Editor.DefaultAltSearchEnabled = Config.Get("AltSearchEnabled", Editor.DefaultAltSearchEnabled);
		Editor.DefaultSearchIncremental = Config.Get("SearchIncremental", Editor.DefaultSearchIncremental);
		Editor.DefaultSearchCaseInvariant = Config.Get("SearchCaseInvariant", Editor.DefaultSearchCaseInvariant);
		Editor.DefaultSearchWords = Config.Get("SearchWords", Editor.DefaultSearchWords);
		Editor.DefaultSearchUnescape = Config.Get("SearchUnescape", Editor.DefaultSearchUnescape);
		Editor.DefaultTabKeyFunction = Config.Get("TabKeyFunction", Editor.DefaultTabKeyFunction);
		Editor.DefaultAutoPasteIndent = Config.Get("AutoPasteIndent", Editor.DefaultAutoPasteIndent);
		Editor.DefaultShowControl = Config.Get("ShowControl", Editor.DefaultShowControl);
		Editor.DefaultNumbers = Config.Get("Numbers", Editor.DefaultNumbers);
		Editor.DefaultWrapIndent = Config.Get("WrapIndent", Editor.DefaultWrapIndent);
		Editor.DefaultWrapIndentExtra = Config.Get("WrapIndentExtra", Editor.DefaultWrapIndentExtra);
		Editor.DefaultGuides = Config.Get("Guides", Editor.DefaultGuides);
		Editor.DefaultBraceMatching = Config.Get("BraceMatching", Editor.DefaultBraceMatching);
		
		Face.DefaultShowToolbar = Config.Get("ShowToolbar", Face.DefaultShowToolbar);
		Face.DefaultShowStatusbar = Config.Get("ShowStatusbar", Face.DefaultShowStatusbar);
		
		Scheme.ImportAssocs(Config.Get("Associations", ""));
		
		if (args.Length == 0) Start(null);
		else foreach (string a in args) Start(a);
		
		new Thread(WaitConnection).Start();
		
		dummyForm.FormBorderStyle = FormBorderStyle.FixedToolWindow;
		dummyForm.StartPosition = FormStartPosition.Manual;
		dummyForm.Location = new Point(-65536, -65536);
		dummyForm.ShowInTaskbar = false;
		dummyForm.Size = new Size(1, 1);
		
		Application.Run(dummyForm);
		//Application.Run();
	}
}