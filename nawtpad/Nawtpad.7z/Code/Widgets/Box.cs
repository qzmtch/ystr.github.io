using System;
using System.Drawing;
using System.Windows.Forms;


class Box : Panel
{
	public Box ()
	{
		OS.ThemeChanged += SetBorder;
		SetBorder();
	}
	
	void SetBorder ()
	{
		if (Application.RenderWithVisualStyles) BorderStyle = BorderStyle.None;
		else BorderStyle = BorderStyle.Fixed3D;
	}
	
	protected override void Dispose (bool disposing)
	{
		OS.ThemeChanged -= SetBorder;
		base.Dispose(disposing);
	}
}