using System;
using System.Windows.Forms;
using Microsoft.Win32;


class Field : ToolStripTextBox
{
	bool selfChange = false;
	public event Action Submitted;
	
	public Field ()
	{
		TextBox.AutoSize = false;
		AutoSize = false;
		
		KeyPress += (o, e) =>
		{
			if (
				Control.ModifierKeys != Keys.None &&
				Control.ModifierKeys != Keys.Shift &&
				Control.ModifierKeys != (Keys.Alt | Keys.Control)
			) e.Handled = true;
		};
		
		KeyDown += (o, e) =>
		{
			bool ctrl = (e.Modifiers == Keys.Control);
			
			switch (e.KeyCode)
			{
				case Keys.A: if (ctrl) SelectAll(); break;
				case Keys.C: if (ctrl) Copy(); break;
				case Keys.V: if (ctrl) Paste(); break;
				case Keys.X: if (ctrl) TextBox.Cut(); break;
				
				case Keys.Enter:
					
					if (Submitted != null)
					{
						e.SuppressKeyPress = true;
						Submitted();
					}
					
				break;
			}
		};
	}
	
	public void Set (string text)
	{
		selfChange = true;
		this.Text = text;
		selfChange = false;
	}
	
	protected override void OnTextChanged (EventArgs e)
	{
		if (selfChange) return;
		base.OnTextChanged(e);
	}
	
	public class Destroyer
	{
		TextBox target;
		int viscount = 0;
		
		public Destroyer (Field tgt)
		{
			this.target = tgt.TextBox;
			
			target.VisibleChanged += (o, e) =>
			{
				if (target.Visible) viscount++;
				else viscount--;
			};
			
			target.Disposed += (o, e) =>
			{
				UserPreferenceChangedEventHandler eh = Delegate.CreateDelegate (
					typeof(UserPreferenceChangedEventHandler),
					target, "OnUserPreferenceChanged"
				) as UserPreferenceChangedEventHandler;
				
				for (int i = 0; i < viscount - 1; i++)
				{
					SystemEvents.UserPreferenceChanged -= eh;
				}
			};
		}
	}
}