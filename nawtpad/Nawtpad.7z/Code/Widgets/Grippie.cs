using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;


class Grippie : Panel
{
	Control target;
	bool resizing = false;
	Point prevMouse;
	Size prevSize;
	
	public Grippie (Control target)
	{
		this.target = target;
		
		Cursor = Cursors.SizeNWSE;
		Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
		
		MouseDown += (o, e) =>
		{
			resizing = true;
			prevMouse = Cursor.Position;
			prevSize = this.target.Size;
		};
		
		MouseUp += (o, e) => { resizing = false; };
		
		MouseMove += (o, e) =>
		{
			Application.DoEvents();
			
			if (resizing)
			{
				this.target.Width = prevSize.Width + (Cursor.Position.X - prevMouse.X);
				this.target.Height = prevSize.Height + (Cursor.Position.Y - prevMouse.Y);
			}
		};
		
		OS.ThemeChanged += SetRenderer;
		SetRenderer();
	}
	
	protected override void Dispose (bool disposing)
	{
		OS.ThemeChanged -= SetRenderer;
		base.Dispose(disposing);
	}
	
	VisualStyleRenderer vsr = null;
	VisualStyleElement meta = VisualStyleElement.Status.Gripper.Normal;
	
	void SetRenderer ()
	{
		if (
			Application.RenderWithVisualStyles &&
			VisualStyleRenderer.IsElementDefined(meta)
		) {
			if (vsr == null) vsr = new VisualStyleRenderer(meta);
		} else vsr = null;
	}
	
	protected override void OnPaint (PaintEventArgs e)
	{
		if (vsr != null) vsr.DrawBackground(e.Graphics, ClientRectangle);
		else ControlPaint.DrawSizeGrip(e.Graphics, BackColor, ClientRectangle);
	}
	
	public delegate void DeltaHandler (int x, int y);
}