using System;
using System.Drawing;
using System.Windows.Forms;


class Resizer : ToolStripControlHost
{
	public readonly Panel Self;
	public readonly ToolStripItem Target;
	
	public int minimum = 0;
	public int maximum = int.MaxValue;
	
	public int Minimum {
		get { return minimum; }
		set { minimum = value; FixSize(); }
	}
	
	public int Maximum {
		get { return maximum; }
		set { maximum = value; FixSize(); }
	}
	
	int oldWidth;
	int oldMouseX;
	
	bool resizing = false;
	
	public Resizer (ToolStripItem target) : base (new Panel())
	{
		Width = 8;
		AutoSize = false;
		
		Self = Control as Panel;
		Self.Cursor = Cursors.SizeWE;
		
		Target = target;
		
		MouseDown += (o, e) =>
		{
			oldWidth = Target.Width;
			oldMouseX = Cursor.Position.X;
			resizing = true;
		};
		
		MouseUp += (o, e) => ProcessMouseUp();
		MouseMove += (o, e) => ProcessMouseMove();
		LocationChanged += (o, e) => Self.Refresh();
	}
	
	void ProcessMouseUp ()
	{
		resizing = false;
	}
	
	void ProcessMouseMove ()
	{
		if (resizing)
		{
			int w = oldWidth + oldMouseX - Cursor.Position.X;
			if (w <= maximum && w >= minimum) Target.Width = w;
		}
	}
	
	void FixSize ()
	{
		if (Target.Width > maximum) Target.Width = maximum;
		else if (Target.Width < minimum) Target.Width = minimum;
	}
}