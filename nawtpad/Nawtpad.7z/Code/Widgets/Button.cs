using System;
using System.Drawing;
using System.Windows.Forms;


class Button : ToolStripButton
{
	public event Action Clicked = () => {};
	public event Action RightClicked = () => {};
	
	public Menu Menu = null;
	public Menu RightMenu = null;
	
	string abbr;
	string title;
	string keys;
	string tip;
	
	public string Title {
		get { return title; }
		set { title = value; Localize(); }
	}
	
	void Localize ()
	{
		if (abbr == null) Text = Own.Line(title);
		else { Text = Own.Line(abbr); if (tip == null) ToolTipText = Own.Line(title); }
		
		if (tip != null) ToolTipText = Own.Line(tip);
		if (keys != null) ToolTipText += " (" + keys + ")";
	}
	
	public Button (string title) : this (null, title, null) { }
	public Button (string abbr, string title) : this (abbr, title, null) { }
	public Button (string abbr, string title, string keys) : this (abbr, title, keys, null) { }
	public Button (string abbr, string title, string keys, string tip)
	{
		this.abbr = abbr;
		this.title = title;
		this.keys = keys;
		this.tip = tip;
		
		Own.LocaleChanged += Localize;
		
		Localize();
		
		MouseUp += (o, e) =>
		{
			if (e.Button == MouseButtons.Right) RightClicked();
		};
		
		Click += (o, e) =>
		{
			if (Control.ModifierKeys == Keys.Shift) RightClicked();
			else Clicked();
		};
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}