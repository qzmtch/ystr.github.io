using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


class Menu : ToolStripDropDownMenu
{
	bool closing = false;
	
	public Menu ()
	{
		Renderer = new ModernRenderer();
	}
	
	protected void Clear ()
	{
		for (int i = Items.Count; i > 0; i--) Items[0].Dispose();
	}
	
	protected override void Dispose (bool disposing)
	{
		Clear();
		base.Dispose(disposing);
	}
	
	protected override void OnKeyUp (KeyEventArgs e)
	{
		foreach (object i in Items)
		{
			if (i is Row)
			{
				Row r = (i as Row);
				if (r.Selected) r.OnKeyUp(e);
			}
		}
		
		base.OnKeyUp(e);
	}
	
	protected override void OnClosing (ToolStripDropDownClosingEventArgs e)
	{
		if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
		{
			if (!closing) e.Cancel = true;
		}
		
		closing = false;
		base.OnClosing(e);
	}
	
	public void ForceClose ()
	{
		closing = true;
		Close(ToolStripDropDownCloseReason.ItemClicked);
	}
	
	public delegate bool Checker (Row r);
	public void Check (Checker check)
	{
		foreach (object o in Items)
		{
			if (!(o is Row)) continue;
			Row r = o as Row;
			r.Checked = check(r);
		}
	}
	
	class ModernRenderer : ToolStripProfessionalRenderer
	{
		protected override void OnRenderToolStripBorder (ToolStripRenderEventArgs e)
		{
			using (Pen p = new Pen(SystemColors.ControlDark.Rip()))
			{
				e.Graphics.DrawRectangle (
					p, e.AffectedBounds.X, e.AffectedBounds.Y,
					e.AffectedBounds.Width - 1, e.AffectedBounds.Height - 1
				);
			}
		}
		
		protected override void OnRenderImageMargin (ToolStripRenderEventArgs e) { }
	}
}