using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;


delegate void TrackPaintHandler (IOverview to, Graphics g, Rectangle track);

abstract class Scroller : Control, IOverview, IDisposable
{
	int start = 0;
	int span = 10;
	int maximum = 100;
	
	public int Maximum {
		get { return maximum; }
		set { maximum = value; Invalidate(); }
	}
	
	public int Span {
		get { return span; }
		set { span = value; Invalidate(); }
	}
	
	public int Start {
		get { return start; }
		set { start = value; Refresh(); }
	}
	
	bool overview = true;
	public bool Overview {
		get { return overview; }
		set { overview = value; Invalidate(); }
	}
	
	int mouseThumbOffset;
	bool a0Hot, trackHot, thumbHot, a1Hot = false;
	bool a0Pressed, a1Pressed, thumbPressed, trackPressed;
	Rectangle arrow0, track0, thumb, track1, arrow1, track;
	int thumbStart, thumbEnd, thumbSize;
	int trackStart, trackSize, trackEnd;
	
	public event Action<int> ChangeRequested;
	public event TrackPaintHandler OnTrackPaint;
	
	Timer autoscroll = new Timer() { Interval = 100 };
	
	abstract protected Rectangle MakeRect (int pos, int size);
	abstract protected int Length { get; }
	abstract protected int ArrowSize { get; }
	abstract protected void Draw (Graphics g);
	
	public Scroller ()
	{
		DoubleBuffered = true;
		
		autoscroll.Tick += (o, e) => {
			if (a0Pressed) SetStart(start - 1);
			if (a1Pressed) SetStart(start + 1);
		};
	}
	
	protected override void Dispose (bool d)
	{
		autoscroll.Stop();
		autoscroll.Dispose();
		base.Dispose(d);
	}
	
	int RealToTrack (int real) { return real * trackSize / maximum; }
	int TrackToReal (int scroll) { return scroll * maximum / trackSize; }
	
	void SetStart (int val)
	{
		if (ChangeRequested != null) ChangeRequested(val);
	}
	
	public void DrawMark (Graphics g, int start, int size, Brush br)
	{
		start = trackStart + RealToTrack(start);
		size = RealToTrack(size);
		if (size == 0) size = 1;
		
		g.FillRectangle(br, MakeRect(start, size));
	}
	
	protected override void OnMouseMove (MouseEventArgs e)
	{
		thumbHot = thumb.Contains(e.Location);
		a0Hot = arrow0.Contains(e.Location);
		a1Hot = arrow1.Contains(e.Location);
		trackHot = track.Contains(e.Location);
		
		if (thumbPressed && e.Button == MouseButtons.Left) {
			SetStart(TrackToReal(e.Y - trackStart - mouseThumbOffset));
		}
		
		Invalidate();
	}
	
	protected override void OnMouseLeave (EventArgs e)
	{
		a0Hot = a1Hot = trackHot = thumbHot = false;
		Invalidate();
	}
	
	protected override void OnMouseDown (MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Left) return;
		
		a0Pressed = a0Hot;
		a1Pressed = a1Hot;
		thumbPressed = thumbHot;
		trackPressed = trackHot;
		
		bool shift = Control.ModifierKeys == Keys.Shift;
		
		if (a0Pressed || a1Pressed) autoscroll.Start();
		
		if (a0Pressed) SetStart(start - (shift ? span : 1));
		else if (a1Pressed) SetStart(start + (shift ? span : 1));
		else if (thumbPressed) mouseThumbOffset = e.Y - trackStart - thumbStart;
		else if (trackPressed) {
			SetStart(TrackToReal(e.Y - trackStart - thumbSize / 2));
			mouseThumbOffset = thumbSize / 2; thumbPressed = true;
		}
	}
	
	protected override void OnMouseUp (MouseEventArgs e)
	{
		a0Pressed = a1Pressed = trackPressed = thumbPressed = false;
		autoscroll.Stop();
		Invalidate();
	}
	
	protected override void OnPaint (PaintEventArgs e)
	{
		trackStart = ArrowSize;
		trackSize = Length - ArrowSize * 2;
		trackEnd = ArrowSize + trackSize;
		
		track = MakeRect(trackStart, trackSize);
		
		arrow0 = MakeRect(0, ArrowSize);
		arrow1 = MakeRect(trackEnd, ArrowSize);
		
		thumbSize = RealToTrack(span - 1) + 1;
		thumbStart = RealToTrack(start);
		thumbEnd = thumbStart + thumbSize;
		
		thumb = MakeRect(trackStart + thumbStart, thumbSize);
		track0 = MakeRect(trackStart, thumbStart);
		track1 = MakeRect(thumbEnd, trackEnd - thumbEnd);
		
		Draw(e.Graphics);
	}
	
	public class Vertical : Scroller
	{
		public Vertical ()
		{
			Width = SystemInformation.VerticalScrollBarWidth;
		}
		
		protected override Rectangle MakeRect (int pos, int size) {
			return new Rectangle(0, pos, SystemInformation.VerticalScrollBarWidth, size);
		}
		
		protected override int Length { get { return ClientSize.Height; } }
		protected override int ArrowSize { get { return SystemInformation.VerticalScrollBarArrowHeight; } }
		
		protected override void Draw (Graphics g)
		{
			if (Application.RenderWithVisualStyles)
			{
				ScrollBarRenderer.DrawUpperVerticalTrack(g, track0, ScrollBarState.Normal);
				ScrollBarRenderer.DrawLowerVerticalTrack(g, track1, ScrollBarState.Normal);
				
				if (overview && OnTrackPaint != null) OnTrackPaint(this, g, track);
				
				ScrollBarArrowButtonState upState = ScrollBarArrowButtonState.UpNormal;
				if (a0Pressed) upState = ScrollBarArrowButtonState.UpPressed;
				else if (a0Hot) upState = ScrollBarArrowButtonState.UpHot;
				ScrollBarRenderer.DrawArrowButton(g, arrow0, upState);
				
				ScrollBarArrowButtonState downState = ScrollBarArrowButtonState.DownNormal;
				if (a1Pressed) downState = ScrollBarArrowButtonState.DownPressed;
				else if (a1Hot) downState = ScrollBarArrowButtonState.DownHot;
				ScrollBarRenderer.DrawArrowButton(g, arrow1, downState);
				
				ScrollBarState thumbState = ScrollBarState.Normal;
				if (thumbPressed) thumbState = ScrollBarState.Pressed;
				else if (thumbHot) thumbState = ScrollBarState.Hot;
				ScrollBarRenderer.DrawVerticalThumb(g, thumb, thumbState);
				if (thumb.Height > thumb.Width) ScrollBarRenderer.DrawVerticalThumbGrip(g, thumb, thumbState);
			}
			else
			{
				HatchBrush pattern = new HatchBrush(HatchStyle.Percent50, SystemColors.ControlLight, SystemColors.ControlLightLight);
				g.FillRectangle(pattern, track);
				
				if (overview && OnTrackPaint != null) OnTrackPaint(this, g, track);
				
				ControlPaint.DrawButton(g, thumb, ButtonState.Normal);
				
				ButtonState upState = ButtonState.Normal;
				ButtonState downState = ButtonState.Normal;
				
				if (a0Pressed) upState = ButtonState.Pushed;
				if (a1Pressed) downState = ButtonState.Pushed;
				
				ControlPaint.DrawScrollButton(g, arrow0, ScrollButton.Up, upState);
				ControlPaint.DrawScrollButton(g, arrow1, ScrollButton.Down, downState);
			}
		}
	}
}