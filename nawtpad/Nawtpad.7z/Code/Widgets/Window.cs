using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;


class Window : Form
{
	Size normalSize;
	public event Action NormalSizeChanged = () => {};
	
	public Size NormalSize
	{
		get { return normalSize; }
		set { Size = value; }
	}
	
	public Window ()
	{
		Resize += (o, e) =>
		{
			if (
				Size != normalSize &&
				WindowState == FormWindowState.Normal
			) {
				normalSize = Size;
				NormalSizeChanged();
			}
		};
	}
	
	public bool Maximized
	{
		get { return WindowState == FormWindowState.Maximized; }
		set { if (value) WindowState = FormWindowState.Maximized; }
	}
	
	public bool Minimized
	{
		get { return WindowState == FormWindowState.Minimized; }
		set { if (value) WindowState = FormWindowState.Minimized; }
	}
	
	public bool Active {
		get { return ActiveForm == this; }
	}
	
	protected override void OnKeyDown (KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Menu && altHack)
		{
			e.Handled = true;
			return;
		}
		
		base.OnKeyDown(e);
	}
	
	protected override void OnKeyUp (KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Menu && altHack)
		{
			altHack = false;
			e.Handled = true;
			return;
		}
		
		base.OnKeyUp(e);
	}
	
	[DllImport("user32.dll")] static extern int ShowWindow (IntPtr hWnd, uint nCmdShow);
	[DllImport("user32.dll")] static extern bool FlashWindowEx (ref FLASHWINFO pwfi);
	[DllImport("user32.dll")] static extern bool BringWindowToTop (IntPtr hWnd);
	[DllImport("user32.dll")] static extern IntPtr GetForegroundWindow ();
	[DllImport("user32.dll")] static extern uint GetWindowThreadProcessId (IntPtr hWnd, IntPtr lpdwProcessId);
	[DllImport("user32.dll")] static extern bool AttachThreadInput (uint idAttach, uint idAttachTo, bool fAttach);
	[DllImport("user32.dll")] static extern void keybd_event (byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
	[DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx (int idHook, HOOKPROC callback, IntPtr hInstance, uint threadId);
	[DllImport("user32.dll")] static extern IntPtr CallNextHookEx (IntPtr idHook, int nCode, IntPtr wParam, IntPtr lParam);
	[DllImport("kernel32.dll")] static extern IntPtr LoadLibrary (string lpFileName);
	[DllImport("kernel32.dll")] static extern uint GetCurrentThreadId ();
	
	const int WH_KEYBOARD_LL = 13;
	const int WM_KEYDOWN = 0x100;
	const int WM_SYSKEYDOWN = 0x0104;
	const int VK_TAB = 0x09;
	const int SW_SHOW = 5;
	const int SW_RESTORE = 9;
	
	struct FLASHWINFO
	{
		public uint cbSize;
		public IntPtr hwnd;
		public uint dwFlags;
		public uint uCount;
		public uint dwTimeout;
	}
	
	protected void Unminimize ()
	{
		ShowWindow(Handle, SW_RESTORE);
	}
	
	public void Flash ()
	{
		FLASHWINFO i = new FLASHWINFO();
		
		i.cbSize = (uint) Marshal.SizeOf(i);
		i.hwnd = Handle;
		i.dwFlags = 3;
		i.uCount = 3;
		i.dwTimeout = 100;
		
		FlashWindowEx(ref i);
	}
	
	static bool altHack = false;
	
	public void Summon ()
	{
		if (Active) return;
		if (Minimized) Unminimize();
		
		Activate();
		
		uint ft = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero);
		uint tt = GetCurrentThreadId();
		
		AttachThreadInput(ft, tt, true);
		
		BringWindowToTop(Handle);
		ShowWindow(Handle, SW_SHOW);
		
		altHack = true;
		
		keybd_event(0xA4, 0x45, 1, 0);
		keybd_event(0xA4, 0x45, 3, 0);
		
		AttachThreadInput(ft, tt, false);
	}
	
	static IntPtr hook;
	delegate IntPtr HOOKPROC (int nCode, IntPtr wParam, IntPtr lParam);
	static HOOKPROC HookProc = (int nCode, IntPtr wParam, IntPtr lParam) =>
	{
		if (
			wParam == (IntPtr) WM_SYSKEYDOWN &&
			Marshal.ReadInt32(lParam) == VK_TAB
		) {
			altHack = true;
		}
		
		return CallNextHookEx(hook, nCode, wParam, lParam);
	};
	
	static Window ()
	{
		hook = SetWindowsHookEx(WH_KEYBOARD_LL, HookProc, LoadLibrary("User32"), 0);
	}
}