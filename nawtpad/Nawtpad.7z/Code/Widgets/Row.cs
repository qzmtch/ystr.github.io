using System;
using System.Drawing;
using System.Windows.Forms;


class Row : ToolStripMenuItem
{
	public event Action Clicked = () => {};
	public bool Option = false;
	
	readonly string text;
	readonly string strippedText;
	
	void Localize ()
	{
		Text = Own.TryLine(strippedText, text);
	}
	
	public Row (string text) : this (text, null) { }
	public Row (string text, string keys)
	{
		this.text = text;
		this.strippedText = text.Replace("&", "");
		
		if (keys != null) ShortcutKeyDisplayString = "(" + keys + ")";
		
		Own.LocaleChanged += Localize;
		
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		Own.LocaleChanged -= Localize;
		
		DropDown.Dispose();
		
		base.Dispose(disposing);
	}
	
	protected override void OnClick (EventArgs e)
	{
		DoClick(false);
	}
	
	public void OnKeyUp (KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Space) DoClick(true);
	}
	
	protected override void OnMouseUp (MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right) DoClick(true);
	}
	
	void DoClick (bool alt)
	{
		if (
			Parent is Menu &&
			DropDownItems.Count == 0 &&
			!alt && !Option
		) (Parent as Menu).ForceClose();
		
		if (Option) Checked = !Checked;
		Clicked();
	}
}