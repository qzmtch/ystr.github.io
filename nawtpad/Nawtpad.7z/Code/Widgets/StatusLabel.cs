using System;
using System.Drawing;
using System.Windows.Forms;


class StatusLabel : Label
{
	readonly string tip;
	public Menu Menu = null;
	
	void Localize ()
	{
		if (tip == null) ToolTipText = Text;
		else ToolTipText = Own.Line(tip);
	}
	
	public override string Text {
		get { return base.Text; }
		set {
			base.Text = value;
			if (tip == null) ToolTipText = value;
		}
	}
	
	public StatusLabel () : this (null) { }
	public StatusLabel (string tip) : base ("")
	{
		this.tip = this.Text = tip;
		TextAlign = ContentAlignment.MiddleLeft;
		
		MouseUp += (o, e) =>
		{
			if (Menu != null && e.Button == MouseButtons.Left)
			{
				Menu.Show(Parent, Bounds.X + e.X, Bounds.Y + e.Y);
			}
		};
		
		Own.LocaleChanged += Localize;
		Localize();
	}
	
	protected override void Dispose (bool disposing)
	{
		if (Menu != null) Menu.Dispose();
		Own.LocaleChanged -= Localize;
		base.Dispose(disposing);
	}
}