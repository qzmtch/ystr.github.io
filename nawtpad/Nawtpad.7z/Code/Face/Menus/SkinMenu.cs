using System;
using System.Collections.Generic;


class SkinMenu : Menu
{
	public SkinMenu ()
	{
		string[] skins = Own.ListSkins();
		
		foreach (string skin in skins)
		{
			Row sr = new Row(skin);
			sr.Name = skin;
			sr.Clicked += () => { Own.Skin = sr.Name; };
			Items.Add(sr);
		}
		
		Opening += (o, e) =>
		{
			Own.SkinChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			Own.SkinChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		this.Check(r => r.Name == Own.Skin);
	}
}