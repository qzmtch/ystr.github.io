using System;
using System.Collections.Generic;
using System.Windows.Forms;


class MarksMenu : Menu
{
	public readonly Editor E;
	public readonly Document D;
	
	public MarksMenu (Editor ed)
	{
		E = ed;
		D = E.D;
		
		D.MarksChanged += Reveal;
		D.MarksChangedInternally += Reveal;
		
		Reveal();
	}
	
	protected override void Dispose (bool disposing)
	{
		D.MarksChanged -= Reveal;
		D.MarksChangedInternally -= Reveal;
		
		base.Dispose(disposing);
	}
	
	void Go (int mi)
	{
		E.GoToMark(mi);
	}
	
	void Reveal ()
	{
		Clear();
		
		for (int i = 0; i < D.Marks.Count; i++)
		{
			Line l = D.Marks[i];
			string keys = i < 9 ? "Ctrl " + (i + 1).ToString() : null;
			Row mr = new Row(l.MarkName, keys);
			int mi = i; mr.Clicked += () => Go(mi);
			Items.Add(mr);
		}
		
		Items.Add(new ToolStripSeparator());
		
		Row dr = new Row("&Clear Marks", "Ctrl Shift Space");
		dr.Clicked += D.ClearMarks;
		Items.Add(dr);
	}
}