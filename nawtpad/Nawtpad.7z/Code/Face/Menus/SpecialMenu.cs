using System;
using System.Collections.Generic;
using System.Windows.Forms;


class SpecialMenu : Menu
{
	Row portableRow = new Row("Portable Mode (ini file)");
	Row remainRow = new Row("Remain in memory for faster opening");
	
	public SpecialMenu ()
	{
		Items.Add(portableRow);
		Items.Add(remainRow);
		
		portableRow.Clicked += () => Config.Portable = !Config.Portable;
		remainRow.Clicked += () => Nawtpad.Remain = !Nawtpad.Remain;
		
		Opening += (o, e) =>
		{
			Config.PortableChanged += Reveal;
			Nawtpad.RemainChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			Config.PortableChanged -= Reveal;
			Nawtpad.RemainChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		remainRow.Checked = Nawtpad.Remain;
		portableRow.Checked = Config.Portable;
	}
}