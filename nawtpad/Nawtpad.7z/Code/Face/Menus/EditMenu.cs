using System.Windows.Forms;


class EditMenu : Menu
{
	public readonly Editor E;
	public readonly Document D;
	
	Row undoRow = new Row("&Undo", "Ctrl Z");
	Row redoRow = new Row("&Redo", "Ctrl Y");
	Row cutRow = new Row("C&ut", "Ctrl X");
	Row copyRow = new Row("&Copy", "Ctrl C");
	Row pasteRow = new Row("&Paste", "Ctrl P");
	Row duplicateLineRow = new Row("&Duplicate Line", "Ctrl D");
	Row lineCommentRow = new Row("&Line Comment", "Ctrl Q");
	Row streamCommentRow = new Row("&Stream Comment", "Ctrl Shift Q");
	
	public EditMenu (Editor editor)
	{
		E = editor;
		D = E.D;
		
		undoRow.Clicked += D.Undo;
		redoRow.Clicked += D.Redo;
		cutRow.Clicked += E.CutSelected;
		copyRow.Clicked += E.CopySelected;
		pasteRow.Clicked += E.Paste;
		duplicateLineRow.Clicked += E.DuplicateLine;
		lineCommentRow.Clicked += E.LineComment;
		streamCommentRow.Clicked += E.StreamComment;
		
		Items.Add(undoRow);
		Items.Add(redoRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(cutRow);
		Items.Add(copyRow);
		Items.Add(pasteRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(duplicateLineRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(lineCommentRow);
		Items.Add(streamCommentRow);
		
		Opening += (o, e) =>
		{
			D.Updated += Reveal;
			D.SchemeChanged += Reveal;
			
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			D.Updated -= Reveal;
			D.SchemeChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		undoRow.Enabled = D.CanUndo;
		redoRow.Enabled = D.CanRedo;
		
		cutRow.Enabled = E.Selected;
		copyRow.Enabled = E.Selected;
		pasteRow.Enabled = Clipboard.ContainsText(TextDataFormat.Text);
		
		lineCommentRow.Enabled = D.Scheme.LineCommentSupported;
		streamCommentRow.Enabled = D.Scheme.StreamCommentSupported;
	}
}