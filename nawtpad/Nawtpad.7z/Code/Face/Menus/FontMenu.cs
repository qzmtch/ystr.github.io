using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;


class FontMenu : Menu
{
	public readonly Editor E;
	
	public FontMenu (Editor editor)
	{
		E = editor;
		
		SuspendLayout();
		
		foreach (FontFamily f in new InstalledFontCollection().Families)
		{
			Row fr = new Row(f.Name) { Name = f.Name };
			fr.Clicked += () => Editor.DefaultFontName = Editor.GlobalFontName = fr.Name;
			Items.Add(fr);
		}
		
		Opening += (o, e) =>
		{
			E.FontNameChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.FontNameChanged -= Reveal;
		};
		
		ResumeLayout();
	}
	
	void Reveal ()
	{
		this.Check(r => E.FontName == r.Name);
	}
}