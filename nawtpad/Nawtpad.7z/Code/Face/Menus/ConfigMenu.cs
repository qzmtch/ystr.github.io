using System.Windows.Forms;


class ConfigMenu : Menu
{
	public readonly Face F;
	public readonly Editor E;
	
	Row localeRow = new Row("&Language");
	Row skinRow = new Row("Theme");
	Row fontRow = new Row("&Font");
	Row interfaceRow = new Row("&Interface");
	Row wrapIndentRow = new Row("&Wrap Indent");
	Row tabKeyRow = new Row("&Tab Key");
	Row searchRow = new Row("&Search");
	Row saveConfigRow = new Row("&Save Config", "F7");
	Row specialRow = new Row("Special");
	
	public ConfigMenu (Face f)
	{
		F = f;
		E = f.E;
		
		bool locs = Own.ListLocales().Count > 0;
		bool skns = Own.ListSkins().Length > 0;
		
		if (locs) localeRow.DropDown = new LocaleMenu();
		skinRow.DropDown = new SkinMenu();
		tabKeyRow.DropDown = new TabKeyMenu(E);
		fontRow.DropDown = new FontMenu(E);
		interfaceRow.DropDown = new InterfaceMenu();
		searchRow.DropDown = new SearchMenu(E);
		specialRow.DropDown = new SpecialMenu();
		wrapIndentRow.DropDown = new WrapIndentMenu(E);
		
		saveConfigRow.Clicked += F.SaveConfig;
		
		if (locs) Items.Add(localeRow);
		if (skns) Items.Add(skinRow);
		Items.Add(fontRow);
		Items.Add(interfaceRow);
		Items.Add(wrapIndentRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(tabKeyRow);
		Items.Add(searchRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(specialRow);
		Items.Add(saveConfigRow);
	}
}