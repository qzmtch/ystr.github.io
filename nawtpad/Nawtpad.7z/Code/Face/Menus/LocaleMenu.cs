using System;
using System.Collections.Generic;


class LocaleMenu : Menu
{
	public LocaleMenu ()
	{
		Dictionary<string, string> locs = Own.ListLocales();
		
		if (locs.Count == 0)
		{
			Visible = false;
			return;
		}
		
		foreach (KeyValuePair<string, string> kv in Own.ListLocales())
		{
			Row lr = new Row(kv.Value);
			lr.Name = kv.Key;
			lr.Clicked += () => SelectLocale(lr);
			Items.Add(lr);
		}
		
		Opening += (o, e) =>
		{
			Own.LocaleChanged += Reveal;
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			Own.LocaleChanged -= Reveal;
		};
	}
	
	void Reveal ()
	{
		this.Check(r => r.Name == Own.Locale);
	}
	
	void SelectLocale (Row lr)
	{
		Own.Locale = lr.Name;
	}
}