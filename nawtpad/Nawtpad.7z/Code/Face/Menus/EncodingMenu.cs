using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;


class EncodingMenu : Menu
{
	public readonly Document D;
	
	Row saveInRow = new Row("Don’t &Reload") { Option = true };
	
	SortedDictionary<int, EncodingEntryRow> erows = new SortedDictionary<int, EncodingEntryRow>();
	SortedDictionary<string, EncodingGroupRow> grows = new SortedDictionary<string, EncodingGroupRow>();
	
	Row bomRow = new Row("Save with BOM");
	Row defaultRow = new Row("Set as &Default");
	
	public EncodingMenu (Document doc)
	{
		this.D = doc;
		
		SuspendLayout();
		
		Items.Add(saveInRow);
		Items.Add(new ToolStripSeparator());
		
		EncodingInfo[] eis = Encoding.GetEncodings();
		
		foreach (EncodingInfo ei in eis)
		{
			string grpName = ei.DisplayName.Split(new char[]{' ', ','})[0];
			string grpID = grpName.Substring(0, 3);
			
			if (!grows.ContainsKey(grpID)) grows[grpID] = new EncodingGroupRow(grpID, grpName);
			
			EncodingEntryRow er = new EncodingEntryRow(ei);
			
			er.Clicked += () =>
			{
				D.Encoding = Encoding.GetEncoding(er.CodePage);
				if (!saveInRow.Checked && !D.Unsaved) D.Reload();
			};
			
			grows[grpID].DropDownItems.Add(er);
			erows[er.CodePage] = er;
		}
		
		foreach (Row mr in grows.Values) Items.Add(mr);
		Items.Add(new ToolStripSeparator());
		Items.Add(bomRow);
		Items.Add(defaultRow);
		
		bomRow.Clicked += () => D.SaveBom = !D.SaveBom;
		defaultRow.Clicked += () => Document.DefaultEncoding = D.Encoding;
		
		Opening += (o, e) =>
		{
			D.EncodingChanged += Reveal;
			D.SaveBomChanged += Reveal;
			Document.DefaultSaveBomChanged += Reveal;
			Document.DefaultEncodingChanged += Reveal;
			
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			D.EncodingChanged -= Reveal;
			D.SaveBomChanged -= Reveal;
			Document.DefaultSaveBomChanged -= Reveal;
			Document.DefaultEncodingChanged -= Reveal;
		};
		
		ResumeLayout();
	}
	
	void Reveal ()
	{
		if (D.Unsaved)
		{
			saveInRow.Enabled = false;
			saveInRow.Checked = true;
		}
		
		foreach (EncodingGroupRow gr in grows.Values)
		{
			gr.Checked = D.Encoding.EncodingName.StartsWith(gr.Group);
		}
		
		foreach (EncodingEntryRow er in erows.Values)
		{
			er.Checked = (er.CodePage == D.Encoding.CodePage);
		}
		
		bomRow.Checked = D.SaveBom;
		
		defaultRow.Checked = (
			D.Encoding == Document.DefaultEncoding &&
			D.SaveBom == Document.DefaultSaveBom
		);
	}
	
	class EncodingGroupRow : Row
	{
		public readonly string Group;
		public EncodingGroupRow (string grpID, string grpName) : base (grpName) { Group = grpID; }
	}
	
	class EncodingEntryRow : Row
	{
		public readonly int CodePage;
		public EncodingEntryRow (EncodingInfo i) : base (i.DisplayName) { CodePage = i.CodePage; }
	}
}