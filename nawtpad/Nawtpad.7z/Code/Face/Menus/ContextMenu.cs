using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;


class ContextMenu : Menu
{
	public readonly Face F;
	public readonly Editor E;
	public readonly Document D;
	
	Row searchRow = new Row("Search", "Ctrl F");
	Row replaceRow = new Row("Replace", "Ctrl H");
	
	Row markRow = new Row("Mark", "Ctrl Space");
	Row marksRow = new Row("Marks");
	ToolStripSeparator markSep = new ToolStripSeparator();
	
	Row cutRow = new Row("&Cut", "Ctrl X");
	Row copyRow = new Row("&Copy", "Ctrl C");
	Row pasteRow = new Row("&Paste", "Ctrl V");
	Row selectLineRow = new Row("Select &Line", "Ctrl Shift A");
	Row selectAllRow = new Row("Select &All", "Ctrl A");
	
	ToolStripSeparator mainSep = new ToolStripSeparator();
	Row fileRow = new Row("&File");
	Row editRow = new Row("&Edit");
	Row viewRow = new Row("&View");
	Row configRow = new Row("&Options");
	
	ToolStripSeparator goSep = new ToolStripSeparator();
	Row goRow = new Row("Go", "Ctrl G");
	
	public ContextMenu (Face f)
	{
		F = f;
		E = f.E;
		D = E.D;
		
		Items.Add(cutRow);
		Items.Add(copyRow);
		Items.Add(pasteRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(markRow);
		Items.Add(marksRow);
		Items.Add(markSep);
		Items.Add(searchRow);
		Items.Add(replaceRow);
		Items.Add(new ToolStripSeparator());
		Items.Add(selectLineRow);
		Items.Add(selectAllRow);
		Items.Add(mainSep);
		Items.Add(fileRow);
		Items.Add(editRow);
		Items.Add(viewRow);
		Items.Add(configRow);
		Items.Add(goSep);
		Items.Add(goRow);
		
		markRow.Clicked += E.ToggleMark;
		cutRow.Clicked += E.CutSelected;
		copyRow.Clicked += E.CopySelected;
		pasteRow.Clicked += E.Paste;
		searchRow.Clicked += F.SearchSelected;
		replaceRow.Clicked += F.ReplaceSelected;
		selectLineRow.Clicked += E.SelectLine;
		selectAllRow.Clicked += E.SelectAll;
		goRow.Clicked += F.ShowGo;
		
		marksRow.DropDown = new MarksMenu(E);
		fileRow.DropDown = new FileMenu(F);
		editRow.DropDown = new EditMenu(E);
		viewRow.DropDown = new ViewMenu(F);
		configRow.DropDown = new ConfigMenu(F);
		
		Opening += (o, e) =>
		{
			E.SelectionChanged += Reveal;
			
			D.MarksChanged += Reveal;
			D.MarksChangedInternally += Reveal;
			
			bool multiline = E.SelectionStart.Line != E.SelectionEnd.Line;
			searchRow.Enabled = replaceRow.Enabled = !F.ShowToolbar.Value || (E.Selected && !multiline);
			
			if (goSep.Visible = goRow.Visible = !F.ShowStatusbar.Value)
			{
				string go = "";
				
				if (multiline) {
					go += (E.SelectionStart.Line + 1).ToString() + "-";
					go += (E.SelectionEnd.Line + 1).ToString();
				} else go += (E.Caret.Line + 1).ToString();
				
				go += "/" + D.Count.ToString() + " ";
				
				if (!multiline)
				{
					bool one = E.SelectionEnd.Char - E.SelectionStart.Char == 1;
					
					if (E.Selected && !one) {
						go += (E.SelectionStart.Char + 1).ToString() + "-";
						go += (E.SelectionEnd.Char + 1).ToString();
					} else go += (E.Caret.Char + 1).ToString();
					
					go += "/" + D[E.Caret.Line].Length.ToString();
					
					if (one) go += " [" + Abc.GetCodeOrAbbr(
						D[E.SelectionStart.Line].Text[E.SelectionStart.Char]
					)+ "]";
				}
				
				goRow.Text = go;
			}
			
			marksRow.Visible = !F.ShowToolbar.Value;
			mainSep.Visible = !F.ShowToolbar.Value;
			fileRow.Visible = !F.ShowToolbar.Value;
			editRow.Visible = !F.ShowToolbar.Value;
			viewRow.Visible = !F.ShowToolbar.Value;
			configRow.Visible = !F.ShowToolbar.Value;
			
			Reveal();
		};
		
		Closing += (o, e) =>
		{
			E.SelectionChanged -= Reveal;
			D.MarksChanged -= Reveal;
			D.MarksChangedInternally -= Reveal;
		};
	}
	
	void Reveal ()
	{
		cutRow.Enabled = E.Selected;
		copyRow.Enabled = E.Selected;
		pasteRow.Enabled = Clipboard.ContainsText(TextDataFormat.Text);
		
		markRow.Checked = D[E.Caret.Line].Marked;
		marksRow.Enabled = D.Marks.Count > 0;
	}
}