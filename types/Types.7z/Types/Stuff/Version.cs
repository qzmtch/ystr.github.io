using System.Reflection;

#if !DEBUG
	[assembly: AssemblyVersion("2.6.5.*")]
	[assembly: AssemblyInformationalVersion("2.6.5")]
#endif

[assembly: AssemblyProduct("Types")]
[assembly: AssemblyCompany("Evgeny Strunnikov")]
[assembly: AssemblyCopyright("ES <izt@ya.ru> GPL3")]