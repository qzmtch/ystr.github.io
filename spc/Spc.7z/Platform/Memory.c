#define malloc(N) malloc(N)
#define realloc(P, N) realloc(P, N)


#define new_1(T) malloc(sizeof(T))
#define new_2(T,N) malloc(sizeof(T) * (N))
#define new_3(T,AT,AN) malloc(sizeof(T) + sizeof(AT) * (AN))
#define new_(T,N,A,X,...) X
#define new(...) new_(__VA_ARGS__,new_3,new_2,new_1,)(__VA_ARGS__)


#define nuw_1(T) calloc(1, sizeof(T))
#define nuw_2(T,N) calloc(N, sizeof(T))
#define nuw_3(T,AT,AN) calloc(sizeof(T) + sizeof(AT) * (AN), 1)
#define nuw_(T,N,A,X,...) X
#define nuw(...) nuw_(__VA_ARGS__,nuw_3,nuw_2,nuw_1,)(__VA_ARGS__)


#define renew_3(P,T,N) realloc(P, sizeof(T) * (N))
#define renew_4(P,T,AT,AN) realloc(P, sizeof(T) + sizeof(AT) * (AN))
#define renew_(P,T,N,A,X,...) X
#define renew(...) renew_(__VA_ARGS__,renew_4,renew_3,)(__VA_ARGS__)


#define zap(P) free(P)
