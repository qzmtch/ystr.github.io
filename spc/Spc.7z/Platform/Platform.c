#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef DEBUG
	#include <stdio.h>
#endif

#if defined X11
	#include <pthread.h>
	#include <sys/time.h>
#elif defined WIN32
	#define WINVER 0x0501
	#include <windows.h>
	#undef RGB
#endif

#include "Types.c"
#include "Memory.c"
#include "Clock.c"
#include "Async.c"
