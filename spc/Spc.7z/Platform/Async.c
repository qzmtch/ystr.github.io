void spawn_2 (void (*fun)(void*), void* arg)
{
	#ifdef SINGLETHREADED
		fun(arg);
	#elif WIN32
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)fun, arg, 0, 0);
	#else
		static pthread_t t;
		pthread_create(&t, 0, (void*(*)(void*))fun, arg);
	#endif
}

#define spawn_1(f) spawn_2(f,0)
#define spawn_(F,P,X,...) X
#define Spawn(...) spawn_(__VA_ARGS__,spawn_2,spawn_1,)(__VA_ARGS__)
