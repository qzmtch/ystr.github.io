typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

#define S8MIN INT8_MIN
#define S16MIN INT16_MIN
#define S32MIN INT32_MIN
#define S8MAX INT8_MAX
#define S16MAX INT16_MAX
#define S32MAX INT32_MAX
#define U8MAX UINT8_MAX
#define U16MAX UINT16_MAX
#define U32MAX UINT32_MAX

typedef float flawt;
typedef double real;

#define FMAX FLT_MAX
#define RMAX DBL_MAX

typedef struct { u8 B, G, R; } Rgb;
#define RGB(r,g,b) (Rgb){ .R = r, .G = g, .B = b }

typedef u8 bool;
