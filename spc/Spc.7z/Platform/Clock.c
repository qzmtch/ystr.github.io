struct {
	
	real Rate;
	
	real Factor;
	real Increment;
	real Epoch;
	
	real SysTickValue;
	
} Clock = { .Rate = 1 };

void PrepareClock ()
{
	#if defined WIN32
		LARGE_INTEGER tps;
		QueryPerformanceFrequency(&tps);
		Clock.SysTickValue = 1.0 / tps.u.LowPart;
	#elif defined X11
		Clock.SysTickValue = 0.000001;
	#endif
}

u32 Tick ()
{
	static u32 previous = 0;
	static u32 current = 0;
	
	#if defined WIN32
		LARGE_INTEGER ticks;
		QueryPerformanceCounter(&ticks);
		current = ticks.u.LowPart;
	#elif defined X11
		struct timeval time;
		gettimeofday(&time, 0);
		current = time.tv_usec + time.tv_sec * 1000000;
	#endif
	
	if (previous)
	{
		u32 elapsed = current - previous;
		Clock.Factor = elapsed * Clock.SysTickValue;
		Clock.Increment = Clock.Factor * Clock.Rate;
		Clock.Epoch += Clock.Increment;
	}
	
	return previous = current;
}