using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;

static class Skin
{
	static string Pack (string path)
	{
		string name = Path.GetFileNameWithoutExtension(path);
		
		Bitmap pic = new Bitmap(path);
		List<string> vls = new List<string>();
		
		vls.Add((pic.Width / 2).ToString());
		vls.Add((pic.Height / 2).ToString());
		
		for (int y = pic.Height - 1; y >= 0; y--)
		{
			for (int x = 0; x < pic.Width; x++)
			{
				Color c = pic.GetPixel(x, y);
				vls.Add(c.R > 127 ? "1" : "0");
			}
		}
		
		return "u8 SKIN_" + name.ToUpper() +
			" [] = { " + String.Join(",", vls.ToArray()) + " };";
	}
	
	static void Main ()
	{
		using (StreamWriter w = new StreamWriter("Skin.c", false))
		{
			foreach (string dir in Directory.GetDirectories("."))
			{
				foreach (string file in Directory.GetFiles(dir, "*.png"))
				{
					w.Write(Pack(file) + "\n");
				}
			}
		}
	}
}