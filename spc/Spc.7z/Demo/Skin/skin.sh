mcs Skin.cs -out:Skin.exe -r:System.Drawing
if [ $? = 0 ]; then ./Skin.exe; fi
