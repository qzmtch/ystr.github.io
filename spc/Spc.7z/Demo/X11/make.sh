cc ../Demo.c -o spc.o -s -Os -std=c99 -lm -lX11 -lXext -lpthread -Wall -Werror -pedantic -DX11 -D_XOPEN_SOURCE -D_DEFAULT_SOURCE
