#include <unistd.h>
#include <sys/shm.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/extensions/XShm.h>




char CurrentKeys[32];
Display* DisplayHandle;
Window WindowHandle;
Rgb* Flat;
struct Link { Rgb *From, *To; }* Bridge;
XImage* Image;




void SetTitle (const char* title)
{
	XStoreName(DisplayHandle, WindowHandle, title);
}

void AttachBitmap ()
{
	static XShmSegmentInfo shi;
	
	if (Image)
	{
		XDestroyImage(Image);
		XShmDetach(DisplayHandle, &shi);
		shmdt(shi.shmaddr);
	}
	
	Screen* s =  XDefaultScreenOfDisplay(DisplayHandle);
	
	Image = XShmCreateImage (
		DisplayHandle, DefaultVisualOfScreen(s), DefaultDepthOfScreen(s),
		ZPixmap, 0, &shi, Gui.Xs, Gui.Ys
	);
	
	shi.shmid = shmget(IPC_PRIVATE, Image->bytes_per_line * Image->height, IPC_CREAT | 0777);
	shi.shmaddr = Image->data = (char*) shmat(shi.shmid, 0, 0);
	shi.readOnly = 0;
	
	XShmAttach(DisplayHandle, &shi);
	
	if (Flat) zap(Flat);
	Flat = new(Rgb, Eye.Total);
	
	for (int t = 0, y = Eye.YP; y >= Eye.Y0; --y)
	{
		for (int x = Eye.X0; x <= Eye.XP; ++x)
		{
			Eye.YX[y][x].Color = &Flat[t++];
		}
	}
	
	if (Bridge) zap(Bridge);
	Bridge = new(struct Link, Image->width * Image->height);
	
	float xp = (float) Eye.Xs / Gui.Xs;
	float yp = (float) Eye.Ys / Gui.Ys;
	
	float yy = Eye.Y0;
	
	for (int y = Image->height - 1; y >= 0; --y)
	{
		float xx = Eye.X0;
		
		for (int x = 0; x < Image->width; ++x)
		{
			struct Link* l = &Bridge[y * Image->width + x];
			
			l->From = Eye.YX[(int)yy][(int)xx].Color;
			l->To = (Rgb*)&Image->data[y * Image->width * 4 + x * 4];
			
			xx += xp;
		}
		
		yy += yp;
	}
}




void ToggleFullScreen ()
{
	static bool full = 0;
	full = !full;
	
	static XWindowAttributes old;
	static u32 x, y, xs, ys;
	
	struct {
		unsigned long flags, functions, decorations;
		long inputMode; unsigned long status;
	} hints = {
		.flags = 2, .decorations = !full
	};
	
	if (full) {
		
		XGetWindowAttributes(DisplayHandle, WindowHandle, &old);
		
		x = 0, y = 0;
		
		xs = XDisplayWidth(DisplayHandle, DefaultScreen(DisplayHandle));
		ys = XDisplayHeight(DisplayHandle, DefaultScreen(DisplayHandle));
		
	} else {
		x = old.x, y = old.y;
		xs = old.width, ys = old.height;
	}
	
	XUnmapWindow(DisplayHandle, WindowHandle);
	Atom pp = XInternAtom(DisplayHandle, "_MOTIF_WM_HINTS", 1);
	XChangeProperty(DisplayHandle, WindowHandle, pp, pp, 32, PropModeReplace, (unsigned char*) &hints, 5);
	XMapRaised(DisplayHandle, WindowHandle);
	XMoveResizeWindow(DisplayHandle, WindowHandle, x, y, xs, ys);
}




struct {
	int W, S, A, D, E, Q, Z, C;
	int Up, Down, Left, Right, Control_L;
} KeyCodes;

typedef KeySym Key;

bool KeyDown (int key)
{
	return CurrentKeys[key / 8] & (1 << (key % 8));
}

#define KEYDOWN_W KeyCodes.W
#define KEYDOWN_S KeyCodes.S
#define KEYDOWN_A KeyCodes.A
#define KEYDOWN_D KeyCodes.D
#define KEYDOWN_E KeyCodes.E
#define KEYDOWN_Q KeyCodes.Q
#define KEYDOWN_Z KeyCodes.Z
#define KEYDOWN_C KeyCodes.C
#define KEYDOWN_UP KeyCodes.Up
#define KEYDOWN_DOWN KeyCodes.Down
#define KEYDOWN_LEFT KeyCodes.Left
#define KEYDOWN_RIGHT KeyCodes.Right
#define KEYDOWN_CTRL KeyCodes.Control_L

#define KEYPRESS_ESC XK_Escape
#define KEYPRESS_F11 XK_F11
#define KEYPRESS_P XK_p
#define KEYPRESS_0 XK_0
#define KEYPRESS_1 XK_1
#define KEYPRESS_2 XK_2
#define KEYPRESS_3 XK_3
#define KEYPRESS_4 XK_4
#define KEYPRESS_5 XK_5
#define KEYPRESS_6 XK_6
#define KEYPRESS_7 XK_7
#define KEYPRESS_8 XK_8
#define KEYPRESS_9 XK_9
#define KEYPRESS_PGUP XK_Page_Up
#define KEYPRESS_PGDN XK_Page_Down
#define KEYPRESS_ENTER XK_Return
#define KEYPRESS_TAB XK_Tab




int main ()
{
	Main();
	
	XInitThreads();
	
	DisplayHandle = XOpenDisplay(0);
	int scr = DefaultScreen(DisplayHandle);
	Window rtw = RootWindow(DisplayHandle, scr);
	
	Gui.Xs = Eye.Xs, Gui.Ys = Eye.Ys;
	WindowHandle = XCreateSimpleWindow(DisplayHandle, rtw, 0, 0, Gui.Xs, Gui.Ys, 0, 0, 0);
	XSelectInput(DisplayHandle, WindowHandle, KeyPressMask | StructureNotifyMask);
	SetTitle(Titles[0]);
	
	Atom wmDeleteMessage = XInternAtom(DisplayHandle, "WM_DELETE_WINDOW", 0);
	XSetWMProtocols(DisplayHandle, WindowHandle, &wmDeleteMessage, 1);
	
	XMapWindow(DisplayHandle, WindowHandle);
	GC wgc = XCreateGC(DisplayHandle, WindowHandle, 0, 0);
	
	UpEye();
	
	#define KC(C) KeyCodes.C = XKeysymToKeycode(DisplayHandle, XK_##C);
	KC(W) KC(S) KC(A) KC(D) KC(E) KC(Q) KC(Z) KC(C)
	KC(Up) KC(Down) KC(Left) KC(Right) KC(Control_L)
	
	while (!Gui.Quit)
	{
		while (XPending(DisplayHandle))
		{
			XEvent e;
			XNextEvent(DisplayHandle, &e);
			
			switch (e.type)
			{
				case ConfigureNotify: {
					
					static u16 oxs = 0, oys = 0;
					Window root; s32 x, y; u32 border, depth;
					XGetGeometry(DisplayHandle, WindowHandle, &root, &x, &y, &Gui.Xs, &Gui.Ys, &border, &depth);
					
					if (Gui.Xs != oxs || Gui.Ys != oys)
					{
						oxs = Gui.Xs, oys = Gui.Ys;
						Eye.Ratio = (float) Gui.Xs / Gui.Ys;
						if (!Eye.Photo) UpEye();
					}
				
				} break;
			
				case KeyPress: KeyPressed(XLookupKeysym(&e.xkey, 0)); break;
				case ClientMessage: if (e.xclient.data.l[0] == wmDeleteMessage) Gui.Quit = 1; break;
			}
		}
		
		if (Eye.Photo) usleep(100000);
		else
		{
			Tick();
			XQueryKeymap(DisplayHandle, CurrentKeys);
			CheckDown();
			Render();
		}
		
		u32 total = Image->width * Image->height;
		for each (struct Link, l, Bridge, total) *l->To = *l->From;
		
		XShmPutImage (
			DisplayHandle, WindowHandle, wgc, Image,
			0, 0, 0, 0, Image->width, Image->height, 0
		);
	}
	
	return 0;
}
