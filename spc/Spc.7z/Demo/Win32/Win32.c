u8* Image;
HWND WindowHandle;




void SetTitle (const char* title)
{
	SendMessage(WindowHandle, WM_SETTEXT, 0, (LPARAM)title);
}

void AttachBitmap ()
{
	if (Image) zap(Image);
	Image = new(u8, Eye.Xs * Eye.Ys * 4);
	
	for (int t = 0, y = Eye.Y0; y <= Eye.YP; ++y)
	{
		for (int x = Eye.X0; x <= Eye.XP; ++x)
		{
			Eye.YX[y][x].Color = (Rgb*) &Image[t];
			t += 4;
		}
	}
}




void ToggleFullScreen ()
{
	Gui.Full = !Gui.Full;
	
	static struct {
		int Left, Top;
		int Xs, Ys;
		long Style;
	} Old;
	
	if (Gui.Full)
	{
		RECT orr;
		
		ShowCursor(0);
		
		Old.Style = GetWindowLong(WindowHandle, GWL_STYLE);
		
		GetWindowRect(WindowHandle, &orr);
		
		Old.Left = orr.left;
		Old.Top = orr.top;
		Old.Xs = orr.right - orr.left;
		Old.Ys = orr.bottom - orr.top;
		
		SetWindowLong(WindowHandle, GWL_STYLE, Old.Style & ~(WS_CAPTION | WS_THICKFRAME));
		
		SetWindowPos (
			WindowHandle, HWND_TOPMOST, 0, 0,
			GetSystemMetrics(SM_CXSCREEN),
			GetSystemMetrics(SM_CYSCREEN),
			SWP_FRAMECHANGED
		);
	}
	
	else
	{
		ShowCursor(1);
		
		SetWindowLong(WindowHandle, GWL_STYLE, Old.Style);
		
		SetWindowPos (
			WindowHandle, HWND_NOTOPMOST,
			Old.Left, Old.Top,
			Old.Xs, Old.Ys,
			SWP_FRAMECHANGED
		);
	}
}




typedef WPARAM Key;

bool KeyDown (int key)
{
	return GetKeyState(key) < 0;
}

#define KEYPRESS_ESC VK_ESCAPE
#define KEYPRESS_F11 VK_F11
#define KEYPRESS_P 'P'
#define KEYPRESS_0 '0'
#define KEYPRESS_1 '1'
#define KEYPRESS_2 '2'
#define KEYPRESS_3 '3'
#define KEYPRESS_4 '4'
#define KEYPRESS_5 '5'
#define KEYPRESS_6 '6'
#define KEYPRESS_7 '7'
#define KEYPRESS_8 '8'
#define KEYPRESS_9 '9'
#define KEYPRESS_PGUP VK_PRIOR
#define KEYPRESS_PGDN VK_NEXT
#define KEYPRESS_TAB VK_TAB
#define KEYPRESS_ENTER VK_RETURN

#define KEYDOWN_LEFT VK_LEFT
#define KEYDOWN_RIGHT VK_RIGHT
#define KEYDOWN_UP VK_UP
#define KEYDOWN_DOWN VK_DOWN
#define KEYDOWN_W 'W'
#define KEYDOWN_S 'S'
#define KEYDOWN_A 'A'
#define KEYDOWN_D 'D'
#define KEYDOWN_E 'E'
#define KEYDOWN_Q 'Q'
#define KEYDOWN_Z 'Z'
#define KEYDOWN_C 'C'
#define KEYDOWN_CTRL VK_CONTROL




LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_INPUT: {
			
			UINT dwSize = 40;
			static BYTE lpb[40];
			GetRawInputData((HRAWINPUT)lParam, RID_INPUT, lpb, &dwSize, sizeof(RAWINPUTHEADER));
			RAWINPUT* raw = (RAWINPUT*)lpb;
			
			if (raw->header.dwType == RIM_TYPEMOUSE) 
			{
				float xPosRelative = raw->data.mouse.lLastX;
				float yPosRelative = raw->data.mouse.lLastY;
				
				MouseMoved(xPosRelative, -yPosRelative);
			}
			
		} break;
		
		case WM_MOUSEWHEEL: {
			
			if (GET_WHEEL_DELTA_WPARAM(wParam) / 120 > 0) WheelScrolled(+1);
			else WheelScrolled(-1);
			
		} break;
		
		case WM_PAINT: {
			
			PAINTSTRUCT ps;
			HDC dc = BeginPaint(WindowHandle, &ps);
			
			BITMAPINFOHEADER bi = {
				.biSize = sizeof(BITMAPINFOHEADER),
				.biWidth = Eye.Xs,
				.biHeight = Eye.Ys,
				.biPlanes = 1,
				.biBitCount = 32,
				.biCompression = BI_RGB
			};
			
			StretchDIBits (
				dc, 0, 0, Gui.Xs, Gui.Ys,
				0, 0, Eye.Xs, Eye.Ys,
				Image, (LPBITMAPINFO)&bi,
				DIB_RGB_COLORS, SRCCOPY
			);
			
			EndPaint(WindowHandle, &ps);
			DeleteDC(dc);
			
		} break;
		
		case WM_SIZE: {
			
			RECT cr; GetClientRect(WindowHandle, &cr);
			Gui.Xs = cr.right; Gui.Ys = cr.bottom;
			Eye.Ratio = (float) Gui.Xs / Gui.Ys;
			
			if (!Eye.Photo) UpEye();
			
		} break;
		
		case WM_KEYDOWN: KeyPressed(wParam); break;
		case WM_LBUTTONDBLCLK: DoubleClicked(); break;
		case WM_ERASEBKGND: return 1; break;
		case WM_CLOSE: Gui.Quit = 1; break;
		default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE p, LPSTR c, int s)
{
	#ifdef DEBUG
		AttachConsole(ATTACH_PARENT_PROCESS);
		freopen("CONOUT$", "wb", stdout);
	#endif
	
	Main();
	
	if (!Gui.Xs && !Gui.Ys) { Gui.Xs = Eye.Xs; Gui.Ys = Eye.Ys; }
	int iw = Gui.Xs + 2 * GetSystemMetrics(SM_CXSIZEFRAME);
	int ih = Gui.Ys + GetSystemMetrics(SM_CYCAPTION) + 2 * GetSystemMetrics(SM_CYSIZEFRAME);
	
	WNDCLASSEX winClass = {
		.cbSize = sizeof(winClass),
		.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
		.lpfnWndProc = WndProc,
		.hInstance = hInstance,
		.lpszClassName = TITLE,
		.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(1)),
		.hCursor = LoadCursor(0, IDC_ARROW),
	}; RegisterClassEx(&winClass);
	
	WindowHandle = CreateWindow (
		TITLE, Titles[0], WS_OVERLAPPEDWINDOW,
		(GetSystemMetrics(SM_CXSCREEN) - iw) / 2,
		(GetSystemMetrics(SM_CYSCREEN) - ih) / 2,
		iw, ih, HWND_DESKTOP, 0, hInstance, 0
	);
	
	RAWINPUTDEVICE rid = {
		.usUsagePage = 0x01,
		.usUsage = 0x02,
		.dwFlags = RIDEV_INPUTSINK,
		.hwndTarget = WindowHandle
	}; RegisterRawInputDevices(&rid, 1, sizeof(rid));
	
	ShowWindow(WindowHandle, SW_SHOWNORMAL);
	
	MSG m; while (!Gui.Quit)
	{
		if (PeekMessage(&m, 0, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&m);
			DispatchMessage(&m);
		}
		else
		{
			if (Eye.Photo) Sleep(100);
			else
			{
				Tick();
				if (GetFocus() == WindowHandle) CheckDown();
				Render();
			}
			
			InvalidateRect(WindowHandle, 0, 1);
		}
	}
	
	return 0;
}
