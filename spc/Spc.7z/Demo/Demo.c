#include "../Platform/Platform.c"


#define OnObjectCreation(O) MakeTrail(O)
#define OnObjectDestruction(O) ZapTrail(O)

void MakeTrail();
void ZapTrail();

#define ObjectExtra Loc* Trail;


#include "../Sp.c"
#include "Skin/Skin.c"
#include "Hud.c"


#ifdef DEBUG
	#define PICKOBJECT
#else
	#define PICKOBJECT
#endif

#ifdef PICKOBJECT
	#define PICKSYSTEM
#endif

#ifdef PICKSYSTEM
	#define PICKGALAXY
#endif




struct {
	
	enum { SPACE, SYSTEM, OBJECT, BODY } Mode;
	real Speed;
	
	Loc* Point;
	Rot* Turn;
	
} Control;




void MoveSelf (flawt x, flawt y, flawt z)
{
	real gs = Control.Speed * Clock.Factor;
	Loc gm = { x * gs, y * gs, z * gs };
	Rotate(&gm, Control.Turn);
	Translate(Control.Point, &gm);
}

void TurnSelf (flawt x, flawt y, flawt z, flawt na)
{
	x /= Eye.Zoom; y /= Eye.Zoom; flawt sa = sin(na);
	Rot q = { x * sa, y * sa, z * sa, cos(na) };
	Turn(Control.Turn, &q);
	NizeRot(Control.Turn);
}

void TurnAsync (flawt x, flawt y, flawt z)
{
	TurnSelf(x, y, z, Clock.Factor * 0.5);
}

void ChangeZoom (flawt z)
{
	Eye.Zoom += z * Eye.Zoom * Clock.Factor;
	if (Eye.Zoom < 1) Eye.Zoom = 1;
	UpFov();
}

void TuneExpo (flawt dir)
{
	Eye.Opti += Eye.Opti * dir * Clock.Factor;
}

void TuneSpeed (flawt mul)
{
	Control.Speed *= mul;
}




void Main ()
{
	Prepare();
	
	Control.Mode = SPACE;
	Control.Point = &Space.Pov.Local;
	Control.Turn = &Space.Pov.Turn;
	Control.Speed = HALFCUBE;
	
	UnsafeSeq = Tick();
	
	NewSpace((s16)R16(&UnsafeSeq), (s16)R16(&UnsafeSeq), (s16)R16(&UnsafeSeq));
	
	#ifdef PICKGALAXY
		Galaxy* rg = &Space.Pov.Home[CENTRAL]->Galaxy[0];
		*Control.Point = rg->Center; Control.Point->Z += rg->Bounds;
		Control.Speed = rg->Radius;
	#endif
	
	#ifdef PICKSYSTEM
		ResolveGalaxy(rg);
		Place* rp = &rg->Base[0].Place;
		Space.Pov.Local = rp->Center;
	#endif
}




void Render ()
{
	static bool postPhoto = 0;
	
	Control.Point = &Space.Pov.Local;
	Control.Turn = &Space.Pov.Turn;
	
	if (Galaxies.Current && Galaxies.Current->Close.System)
	{
		if (Control.Mode == SPACE) Control.Speed *= 1 PC;
		
		Control.Mode = SYSTEM;
		System* s = Galaxies.Current->Pov.Capture = Galaxies.Current->Close.System;
		Control.Point = &s->Pov.Point;
		
		#ifdef PICKOBJECT
			static bool pikd = 0; if (!pikd) {
				Object* ro = s->Object->Next->Next->Value;
				*Control.Point = ro->Center;
				Control.Point->Z += ro->Radius * 1.5;
				Control.Speed = ro->Radius * 0.5;
			pikd = 1; }
		#endif
		
		Galaxies.Current->Pov.FollowLocation = 0;
		Galaxies.Current->Pov.FollowRotation = 0;
		
		if (s->Order.Object)
		{
			Object* close = s->Order.First;
			
			bool rotate = close->Body && close->Body->Ready && close->Pov.Qis < pow(close->Radius * 1.1, 2);
			bool follow = rotate;
			
			if (close->Primary && !rotate) close = close->Primary;
			if (!close->Primary) follow = close->Pov.Qis < close->SubQis;
			
			if (follow)
			{
				Control.Mode = OBJECT;
				Control.Point = &close->Pov.Point;
				Galaxies.Current->Pov.FollowLocation = close;
				
				if (rotate)
				{
					Control.Mode = BODY;
					Galaxies.Current->Pov.FollowRotation = close;
					Control.Point = &close->Body->Pov.Point;
					Control.Turn = &close->Body->Pov.Turn;
					
					if (!postPhoto && close->Body->Close.Face)
					{
						real cam = Len(&close->Body->Pov.Point);
						real gnd = Len(&close->Body->Close.Face->Center);
						real fix = gnd + Control.Speed * Clock.Factor;
						if (cam < fix) Norm(&close->Body->Pov.Point, fix);
					}
				}
			}
		}
	}
	else
	{
		if (Control.Mode != SPACE) Control.Speed /= 1 PC;
		if (Galaxies.Current) Galaxies.Current->Pov.Capture = 0;
		Control.Mode = SPACE;
	}
	
	ClearEye();
	RenderSpace();
	PostEye();
	
	if (!Eye.Photo) DrawHud();
	postPhoto = Eye.Photo;
}




typedef enum {
	INTERACTIVE = 0,
	RENDERING, DONE
} State;

struct {
	bool Full;
	u32 Xs, Ys;
	bool Quit;
	State State;
} Gui;

#define TITLE "Spc"
const char* Titles[] = {
	[INTERACTIVE] = TITLE,
	[RENDERING] = TITLE "...",
	[DONE] = TITLE "."
};

void CheckDown ();
void KeyPressed ();
void MouseMoved (flawt x, flawt y);
void WheelScrolled (s8 delta);
void DoubleClicked ();

#if defined WIN32
	#include "Win32/Win32.c"
#elif defined X11
	#include "X11/X11.c"
#endif

void SetState (State s)
{
	Gui.State = s;
	SetTitle(Titles[s]);
}

void Photo ()
{
	Render();
	SetState(DONE);
}

void TogglePhoto ()
{
	if (Gui.State == INTERACTIVE)
	{
		SetState(RENDERING);
		Eye.FullSize = Gui.Xs > Gui.Ys ? Gui.Xs : Gui.Ys;
		Eye.Photo = 1; UpEye();
		Spawn(Photo);
	}
	else if (Gui.State == DONE)
	{
		SetState(INTERACTIVE);
		Eye.Photo = 0; UpEye();
	}
}

void CheckDown ()
{
	if (KeyDown(KEYDOWN_CTRL))
	{
		if (KeyDown(KEYDOWN_LEFT)) TuneExpo(-1);
		if (KeyDown(KEYDOWN_RIGHT)) TuneExpo(+1);
		if (KeyDown(KEYDOWN_UP)) ChangeZoom(+1);
		if (KeyDown(KEYDOWN_DOWN)) ChangeZoom(-1);
	}
	else
	{
		if (KeyDown(KEYDOWN_W)) MoveSelf(0, 0, -1);
		if (KeyDown(KEYDOWN_S)) MoveSelf(0, 0, 1);
		if (KeyDown(KEYDOWN_A)) MoveSelf(-1, 0, 0);
		if (KeyDown(KEYDOWN_D)) MoveSelf(1, 0, 0);
		if (KeyDown(KEYDOWN_E)) MoveSelf(0, 1, 0);
		if (KeyDown(KEYDOWN_Q)) MoveSelf(0, -1, 0);
		if (KeyDown(KEYDOWN_UP)) TurnAsync(1, 0, 0);
		if (KeyDown(KEYDOWN_DOWN)) TurnAsync(-1, 0, 0);
		if (KeyDown(KEYDOWN_LEFT)) TurnAsync(0, 1, 0);
		if (KeyDown(KEYDOWN_RIGHT)) TurnAsync(0, -1, 0);
		if (KeyDown(KEYDOWN_Z)) TurnAsync(0, 0, 1);
		if (KeyDown(KEYDOWN_C)) TurnAsync(0, 0, -1);
	}
}

void KeyPressed (Key k)
{
	if (KeyDown(KEYDOWN_CTRL))
	{
		switch (k)
		{
			case KEYPRESS_0: Clock.Rate = 0E0; break;
			case KEYPRESS_1: Clock.Rate = 1E0; break;
			case KEYPRESS_2: Clock.Rate = 1E1; break;
			case KEYPRESS_3: Clock.Rate = 1E3; break;
			case KEYPRESS_4: Clock.Rate = 1E4; break;
			case KEYPRESS_5: Clock.Rate = 1E5; break;
			case KEYPRESS_6: Clock.Rate = 1E6; break;
			case KEYPRESS_7: Clock.Rate = 1E7; break;
			case KEYPRESS_8: Clock.Rate = 1E8; break;
			case KEYPRESS_9: Clock.Rate = 1E9; break;
		}
	}
	else
	{
		switch (k)
		{
			case KEYPRESS_0: Eye.Boost = 000; break;
			case KEYPRESS_1: Eye.Boost = 001; break;
			case KEYPRESS_2: Eye.Boost = 002; break;
			case KEYPRESS_3: Eye.Boost = 003; break;
			case KEYPRESS_4: Eye.Boost = 007; break;
			case KEYPRESS_5: Eye.Boost = 015; break;
			case KEYPRESS_6: Eye.Boost = 031; break;
			case KEYPRESS_7: Eye.Boost = 063; break;
			case KEYPRESS_8: Eye.Boost = 127; break;
			case KEYPRESS_9: Eye.Boost = 255; break;
			
			case KEYPRESS_PGUP: TuneSpeed(5.0); break;
			case KEYPRESS_PGDN: TuneSpeed(0.2); break;
			
			case KEYPRESS_P: TogglePhoto(); break;
			case KEYPRESS_TAB: SwitchHud(); break;
			case KEYPRESS_F11: ToggleFullScreen(); break;
			case KEYPRESS_ESC: Gui.Quit = 1; break;
		}
	}
}

void MouseMoved (flawt x, flawt y)
{
	if (Gui.Full)
	{
		TurnSelf(y, -x, 0, 0.001);
	}
}

void WheelScrolled (s8 delta)
{
	if (delta > 0) TuneSpeed(2);
	else TuneSpeed(0.5);
}

void DoubleClicked ()
{
	ToggleFullScreen();
}
