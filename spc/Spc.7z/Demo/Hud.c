#define TRAILSTEPS 128

const Rgb BLUE = { .R = 0, .G = 127, .B = 255 };
const Rgb BROWN = { .R = 255, .G = 127, .B = 0 };
const Rgb GREEN = { .R = 0, .G = 255, .B = 0 };
const Rgb PURPLE = { .R = 200, .G = 0, .B = 255 };
const Rgb RED = { .R = 255, .G = 0, .B = 0 };




typedef struct { s16 X, Y; } Co2;
typedef struct { u8 Xs, Ys; bool Data[]; } Glyph;

#define SKIN(G) ((Glyph*)SKIN_##G)

enum { OFF = 0, ALL = 1, AUTO = 2 } Hud = AUTO;




bool IsEmpty (const Co2* co)
{
	return Eye.YX[co->Y][co->X].Z == -FMAX;
}

bool ProHud (Loc* v, const Loc* point, const Rot* turn, Co2* pro)
{
	Loc p = Project(v, point, turn);
	if (p.Z >= 0) return 0;
	flawt z = Eye.Pixoom / p.Z;
	
	flawt fx = p.X * z; pro->X = ROUND(fx); if (pro->X <= Eye.X0 || pro->X >= Eye.XP) return 0;
	flawt fy = p.Y * z; pro->Y = ROUND(fy); if (pro->Y <= Eye.Y0 || pro->Y >= Eye.YP) return 0;
	
	return 1;
}




void DrawGlyph (Glyph* g, const Co2* loc, const Rgb* color)
{
	s16 tx0 = loc->X - g->Xs, tx1 = loc->X + g->Xs;
	s16 ty0 = loc->Y - g->Ys, ty1 = loc->Y + g->Ys;
	
	if (tx0 < Eye.X0) tx0 = Eye.X0; else if (tx1 > Eye.XP) tx1 = Eye.XP;
	if (ty0 < Eye.Y0) ty0 = Eye.Y0; else if (ty1 > Eye.YP) ty1 = Eye.YP;
	
	u8* px = g->Data;
	
	for (s16 yy = ty0; yy <= ty1; yy++)
	{
		for (s16 xx = tx0; xx <= tx1; xx++, px++)
		{
			if (*px) *Eye.YX[yy][xx].Color = *color;
		}
	}
}

void DrawDot (const Co2* pro, const Rgb* color)
{
	*Eye.YX[pro->Y][pro->X].Color = *color;
}




void ProjectGlyph (Loc* p, const Loc* pov, const Rot* turn, Glyph* g, const Rgb* color)
{
	Co2 pro; if (!ProHud(p, pov, turn, &pro)) return;
	DrawGlyph(g, &pro, color);
}

void ProjectDot (Loc* p, const Loc* pov, const Rot* turn, const Rgb* color)
{
	Co2 pro; if (!ProHud(p, pov, turn, &pro)) return;
	DrawDot(&pro, color);
}



void HudObject (Object* o)
{
	if (o->Sub) for chain (o->Sub, oi) HudObject(oi->Value);
	
	if (
		Hud != ALL && (
			o->System->Place->Root->Galaxy->Pov.FollowRotation == o ||
			o->Tag == SUN
		)
	) return;
	
	Rgb hue;
	Glyph* g = 0;
	Co2 oc;
	
	switch (o->Tag)
	{
		case SUN: hue = RED; break;
		case ROCK: hue = GREEN; break;
		case GAS: hue = BLUE; break;
		case SMALL: hue = BROWN; break;
		case MOON: hue = PURPLE; break;
	}
	
	if (o->Trail && (o->Tag == MOON ? Hud == ALL : 1))
	{
		for (int i = 0; i < TRAILSTEPS; ++i)
		{
			Loc trail = Add(o->Orbit->Focus, &o->Trail[i]);
			if (!ProHud(&trail, &o->System->Pov.Point, &Space.Pov.Turn, &oc)) continue;
			if (Hud != ALL && !IsEmpty(&oc)) continue;
			DrawDot(&oc, &hue);
		}
	}
	
	if (ProHud(&o->Center, &o->System->Pov.Point, &Space.Pov.Turn, &oc))
	{
		switch (o->Tag)
		{
			case SUN: g = SKIN(SUN); break;
			case ROCK: g = SKIN(ROCK); break;
			case GAS: g = SKIN(GAS); break;
			case SMALL: g = SKIN(SMALL); break;
			case MOON: g = SKIN(MOON); break;
		}
		
		if (Hud == ALL || IsEmpty(&oc)) DrawGlyph(g, &oc, &hue);
	}
}

void HudGalaxy (Galaxy* g)
{
	if (g->Close.System)
	{
		if (Hud == ALL || (Hud && !g->Pov.FollowRotation))
		{
			for chain (g->Close.System->Object, oi)
			{
				HudObject(oi->Value);
			}
		}
	}
}

void DrawHud ()
{
	if (!Hud) return;
	
	for list (Cube, c, Space.Pov.Home, CUBES)
	{
		for each (Galaxy, g, c->Galaxy, c->Galaxies)
		{
			HudGalaxy(g);
		}
	}
}




void SwitchHud ()
{
	if (Hud) --Hud;
	else Hud = AUTO;
}




void MakeTrail (Object* o)
{
	if (o->Orbit && o->Tag != SMALL)
	{
		o->Trail = new(Loc, TRAILSTEPS);
		
		flawt step = 0;
		
		for (u32 i = 0; i < TRAILSTEPS; ++i)
		{
			o->Trail[i] = Where(o->Orbit, Mea2Tru(o->Orbit, step));
			step += TAU / TRAILSTEPS;
		}
	}
}

void ZapTrail (Object* o)
{
	if (o->Trail) zap(o->Trail);
}
