#include "Core/Core.c"
#include "Eye/Eye.c"
#include "Space/Space.c"

void Prepare ()
{
	PrepareClock();
	PrepareSpot();
	PrepareOrb();
	PrepareLimb();
}
