typedef struct Place {
	
	u32 Seed;
	struct Base* Root;
	u8 Level;
	
	Loc Center;
	
	u8 Age;
	u8 Lumi;
	
	Rgb Color;
	
	flawt VisQis;
	flawt MapQis;
	flawt SysQis;
	
	flawt Spread, SprZ;
	struct Place* Nei; u16 Neis;
	struct System* System;
	
} Place;

typedef struct {
	Loc Center;
	Rgb Color;
	bool Tight;
} Sparkle;

typedef struct Base {
	
	struct Galaxy* Galaxy;
	Place Place;
	
	u8 Age;
	u8 Depth;
	
	bool Tight;
	
	flawt Emit;
	
} Base;




Rgb TempToRgb (s8 t)
{
	if (t < 0) return RGB(255, 255 + t, 255 + t * 6 / 4);
	else return RGB(255 - t, 255 - t, 255);
}

Rgb AgeLumToRgb (u8 age, u8 lum)
{
	return TempToRgb(lum * age / 255 - 128);
}




#include "System.c"




void NewPlace (Seed* seq, Place* p)
{
	p->SysQis = p->VisQis > P2(SYSDIS) ? P2(SYSDIS) : p->VisQis;
	
	p->Age = p->Root->Age;
	if (R1(seq)) p->Age -= P2(R0F(seq)) * p->Age * 0.5;
	else p->Age += P2(R0F(seq)) * (255 - p->Age) * 0.5;
	
	p->Color = AgeLumToRgb(p->Age, p->Lumi);
	p->Seed = RS(seq);
	p->Nei = 0;
	p->System = 0;
}

void MapPlace (Place* s)
{
	#define MINSPREAD 0.003
	
	u8 level = s->Level - 1;
	flawt spread = s->Spread * 0.38;
	flawt sqread = P2(spread);
	
	flawt vis, map;
	
	if (s->Root->Tight) {
		vis = s->MapQis * 0.5;
		map = vis * 0.33;
	} else {
		vis = s->Spread > 3000 ? P2(3000) : P2(s->Spread);
		map = sqread * P2(2);
	}
	
	Seed seq = s->Seed;
	s->Nei = new(Place, s->Neis);
	
	bool zz = (s->SprZ != 1);
	flawt sprz = zz ? s->SprZ + (1 - s->SprZ) * s->SprZ : 1;
	
	for each (Place, ns, s->Nei, s->Neis)
	{
		ns->Root = s->Root;
		
		ns->Center = Sphrout(R0F(&seq) * s->Spread, &seq);
		
		if (zz)
		{
			ns->Center.Z *= sprz;
			Rotate(&ns->Center, &s->Root->Galaxy->Orientation);
		}
		
		Translate(&ns->Center, &s->Center);
		
		ns->Level = level;
		ns->Neis = (level && spread > MINSPREAD) ? 9 : 0;
		ns->Spread = spread; ns->SprZ = sprz;
		ns->VisQis = vis; ns->MapQis = map;
		ns->Lumi = s->Lumi / 2 + RFF(&seq) * (s->Lumi / 3);
		NewPlace(&seq, ns);
	}
}

void UnmapPlace (Place* p)
{
	if (p->Nei)
	{
		for each (Place, n, p->Nei, p->Neis)
		{
			UnmapPlace(n);
			if (n->System) ZapSystem(n->System);
		}
		
		zap(p->Nei);
		p->Nei = 0;
	}
}




void RenderPlace (Place* p)
{
	real qis = Qis(&p->Center, p->Root->Galaxy->Pov.Point);
	
	if (qis < p->MapQis) {
		if (p->Nei) {
			for each (Place, n, p->Nei, p->Neis) RenderPlace(n);
		} else if (p->Neis) MapPlace(p);
	} else UnmapPlace(p);
	
	if (qis < p->SysQis)
	{
		if (!p->System) p->System = NewSystem(p);
		p->Root->Galaxy->System[p->Root->Galaxy->Systems++] = p->System;
		
		if (qis < p->Root->Galaxy->Close.Qis)
		{
			p->Root->Galaxy->Close.System = p->System;
			p->Root->Galaxy->Close.Qis = qis;
		}
		
		return;
	}
	else if (p->System)
	{
		ZapSystem(p->System);
		p->System = 0;
	}
	
	s16 x, y;
	
	if (&p->Root->Place == p && p->Root->Tight)
	{
		if (qis > P2(3000.0)) return;
		
		Loc v = Project(&p->Center, p->Root->Galaxy->Pov.Point, &Space.Pov.Turn);
		if (v.Z >= 0) return;
		v.Z = Eye.Pixoom / v.Z;
		
		flawt r = p->Spread * v.Z;
		if (r > Eye.Short) return;
		
		const flawt min = 1, cli = 10, max = 100;
		flawt a = ((r < cli) ? (r - min) / cli : (max - r) / (max - cli)) * Galaxies.RealExpo;
		if (a < 0) return;
		
		u8 ia = MIN(a, 1) * Galaxies.BrightestSpot;
		if (!ia) return;
		
		x = v.X * v.Z, y = v.Y * v.Z;
		Sprect rect; if (TrySprect(x, y, r, &rect)) LightSpot(&rect, &p->Color, ia);
		
		if (
			x <= Eye.X0 || x >= Eye.XP ||
			y <= Eye.Y0 || y >= Eye.YP
		) return;
	}
	else
	{
		if (qis > p->VisQis) return;
		
		Loc v = Project(&p->Center, p->Root->Galaxy->Pov.Point, &Space.Pov.Turn);
		if (v.Z >= 0) return;
		v.Z = Eye.Pixoom / v.Z;
		
		flawt fx = v.X * v.Z; x = ROUND(fx); if (x <= Eye.X0 || x >= Eye.XP) return;
		flawt fy = v.Y * v.Z; y = ROUND(fy); if (y <= Eye.Y0 || y >= Eye.YP) return;
	}
	
	flawt fa = 1 - qis / p->VisQis * 1;
	if (fa > 0) DrawStar(x, y, &p->Color, P2(fa) * Galaxies.FastExpo);
	
	++Galaxies.VisibleStars;
}

void PhotoPlace (Place* p, u8 depth)
{
	real qis = Qis(&p->Center, p->Root->Galaxy->Pov.Point);
	real rqi = qis / Galaxies.RealExpo;
	
	if (p->Neis && (rqi < p->MapQis || qis < p->MapQis || depth))
	{
		if (!p->Nei) MapPlace(p);
		u8 nd = depth ? depth - 1 : 0;
		for each (Place, n, p->Nei, p->Neis) PhotoPlace(n, nd);
		if (qis > p->MapQis) UnmapPlace(p);
	}
	
	if (
		(!depth && rqi > p->VisQis)
		|| qis < p->SysQis
	) return;
	
	Loc v = Project(&p->Center, p->Root->Galaxy->Pov.Point, &Space.Pov.Turn);
	if (v.Z >= 0) return;
	v.Z = Eye.Pixoom / v.Z;
	
	v.X *= v.Z; s16 x = ROUND(v.X);
	v.Y *= v.Z; s16 y = ROUND(v.Y);
	
	if (depth)
	{
		flawt r = v.Z * p->Spread;
		flawt a = 1 - r / Eye.Long;
		
		if (a > 0)
		{
			a *= Galaxies.RealExpo * p->Root->Emit; if (a > 1) a = 1; u8 ia = a * 255;
			Sprect re; if (ia && TrySprect(x, y, r, &re)) LightSpot(&re, &p->Color, ia);
		}
	}
	
	if (
		x <= Eye.X0 || x >= Eye.XP ||
		y <= Eye.Y0 || y >= Eye.YP
	) return;
	
	flawt fa = 1 - rqi / p->VisQis; if (fa < 0) return;
	DrawStar(x, y, &p->Color, fa * 255);
	
	u16 r = 2; for (flawt sub = 0.1; fa > (1.0 - sub); sub *= 0.5)
	{
		Sprect re; if (TrySprect(x, y, r, &re))
			LightSpot(&re, &p->Color, (fa - (1.0 - sub)) * 10 * 255);
		r *= 2;
	}
}




void SavePlace (Seed* seq, Place* p, u8 level)
{
	NewPlace(seq, p);
	
	if (!level) return;
	else if (level > 1)
	{
		u8 nl = level - 1; MapPlace(p);
		for each (Place, pp, p->Nei, p->Neis) SavePlace(seq, pp, nl);
		UnmapPlace(p);
	}
	
	Sparkle* to = Append(&p->Root->Galaxy->Sparkle, new(Sparkle));
	
	to->Center = p->Center;
	to->Color = p->Root->Place.Color;
	to->Tight = p->Root->Tight;
}

void SaveBase (Seed* seq, Galaxy* g, struct Base* b, u8 level)
{
	b->Galaxy = g;
	b->Place.Root = b;
	b->Place.Lumi = 255;
	SavePlace(seq, &b->Place, level);
}
