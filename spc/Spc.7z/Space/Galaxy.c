#define GALRESRAR 0.01
#define GALSPOTCLIRAR 0.1
#define GALSPOTMAXRAR 0.2

#define MAXVIS 300.0
#define SYSDIS 0.03




struct {
	
	flawt FarQlip;
	
	u8 BrightestSpot;
	u8 BrightestSparkle;
	
	u8 FastExpo;
	flawt RealExpo;
	flawt Modifier;
	u32 VisibleStars;
	
	struct Galaxy* Current;
	
} Galaxies;

typedef struct Galaxy {
	
	Seed Seed;
	
	enum { IRREGULAR, ELLIPTICAL, SPIRAL } Type;
	flawt RelativeSize;
	
	flawt Radius, Raqius;
	flawt Bounds, Bounqs;
	
	Loc Center;
	Rot Orientation;
	Rgb AverageColor;
	
	struct {
		
		Loc* Point;
		
		flawt Alpha;
		flawt RelArea;
		flawt PixArea;
		flawt QisToCen;
		
		bool InSight;
		
		struct System* Capture;
		
		struct Object* FollowLocation;
		struct Object* FollowRotation;
		
	} Pov;
	
	struct { flawt Qis; struct System* System; } Close;
	struct System* System[1024]; u16 Systems;
	
	struct Base* Base; u32 Bases;
	Chain (Sparkle) Sparkle;
	
	bool Resolved;
	
} Galaxy;




#include "Place.c"




void ResolveGalaxy (Galaxy* g)
{
	Seed seq = g->Seed;
	
	u16 none = 0, core = 0, halo = 0;
	u16 disc = 0, glob = 0, arms = 0;
	
	u8 haloLevels = 0;
	u8 coreLevels = 0;
	
	flawt coreRadius = 0;
	flawt haloRadius = 0;
	
	flawt coreZ = 1;
	flawt discZ = 0;
	
	switch (g->Type)
	{
		case IRREGULAR: {
			
			none = 5 + g->RelativeSize * 10;
			
		} break;
		
		case ELLIPTICAL: {
			
			core = 1000; halo = 1000;
			glob = P2(R0F(&seq)) * g->RelativeSize * 1000;
			
			coreLevels = 4 + 5 * g->RelativeSize;
			haloLevels = 2 + 2 * g->RelativeSize;
			
			coreRadius = g->Radius;
			coreZ = 0.3 + R0F(&seq) * 0.7;
			
			haloRadius = g->Radius;
			
		} break;
		
		case SPIRAL: {
			
			core = 500; halo = 1000;
			disc = 1000; arms = 1000;
			glob = 100 + 900 * P2(R0F(&seq));
			
			coreLevels = 8;
			haloLevels = 2;
			
			coreRadius = (0.1 + R0F(&seq) * 0.2) * g->Radius;
			discZ = 0.01 + 0.09 * R0F(&seq);
			
		} break;
	}
	
	g->Bases = none + core + halo + disc + arms + glob;
	struct Base* b = g->Base = new(struct Base, g->Bases);
	
	if (none)
	{
		for (u32 i = 0; i < none; ++i)
		{
			b->Place.Center = Sphrout(R0F(&seq) * g->Radius / 2, &seq);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 0; b->Age = 255;
			b->Emit = 0.001; b->Depth = 4;
			
			b->Place.Spread = g->Radius / 2; b->Place.SprZ = 1;
			b->Place.MapQis = pow(b->Place.Spread * 2, 2);
			b->Place.Neis = 100; b->Place.Level = 5;
			b->Place.VisQis = P2(MAXVIS);
			
			SaveBase(&seq, g, b++, 3);
		}
	}
	
	if (core)
	{
		flawt sprMin = coreRadius * 0.08;
		flawt sprAdd = coreRadius * 0.3;
		
		for (u32 i = 0; i < core; ++i)
		{
			flawt dist = R0F(&seq);
			
			b->Place.Center = Sphrout(dist * coreRadius, &seq);
			b->Place.Center.Z *= coreZ;
			Rotate(&b->Place.Center, &g->Orientation);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 0; b->Age = 0;
			b->Emit = 0.0005; b->Depth = 1;
			
			b->Place.Spread = sprMin + sprAdd * dist; b->Place.SprZ = 1;
			b->Place.MapQis = pow(b->Place.Spread * 2, 2);
			b->Place.Neis = 9; b->Place.Level = coreLevels;
			b->Place.VisQis = P2(MAXVIS);
			
			SaveBase(&seq, g, b++, g->Type == ELLIPTICAL ? 2 : 1);
		}
	}
	
	if (halo)
	{
		haloRadius = g->Radius * 1.5;
		
		for (u32 i = 0; i < halo; ++i)
		{
			b->Place.Center = Sphrout(P2(R0F(&seq)) * haloRadius, &seq);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 0; b->Age = 0;
			b->Emit = 0.0008; b->Depth = 1;
			
			b->Place.Spread = haloRadius * 0.5; b->Place.SprZ = 1;
			b->Place.MapQis = pow(b->Place.Spread * 2, 2);
			b->Place.Neis = 9; b->Place.Level = haloLevels;
			b->Place.VisQis = P2(MAXVIS);
			
			SaveBase(&seq, g, b++, 0);
		}
	}
	
	if (glob)
	{
		flawt globRadius = g->Radius * 1.5;
		
		for (u32 i = 0; i < glob; ++i)
		{
			b->Place.Center = Sphrout((0.5 + 0.5 * P2(RFF(&seq))) * globRadius, &seq);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 1; b->Age = 0;
			b->Emit = 0.5; b->Depth = 1;
			
			b->Place.Spread = 10 + R0F(&seq) * 20; b->Place.SprZ = 1;
			b->Place.MapQis = pow(b->Place.Spread * 10, 2);
			b->Place.Neis = 100 + R0F(&seq) * 1000; b->Place.Level = 3;
			b->Place.VisQis = P2(3.0);
			
			SaveBase(&seq, g, b++, 1);
		}
	}
	
	if (disc)
	{
		flawt sprMin = g->Radius * 0.1;
		flawt sprAdd = g->Radius * 0.2;
		
		for (u32 i = 0; i < disc; ++i)
		{
			flawt dis = R0F(&seq), cen = 1 - dis;
			
			b->Place.Center = Sphrout(dis * g->Radius, &seq); b->Place.Center.Z = 0;
			Rotate(&b->Place.Center, &g->Orientation);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 0; b->Age = 200;
			b->Emit = 0.0005; b->Depth = 3;
			
			b->Place.Spread = sprMin + sprAdd * dis; b->Place.SprZ = cen;
			b->Place.MapQis = pow(b->Place.Spread * 2, 2);
			b->Place.Neis = 9; b->Place.Level = 8;
			b->Place.VisQis = P2(MAXVIS);
			
			SaveBase(&seq, g, b++, 1);
		}
	}
	
	if (arms)
	{
		flawt lon = R0F(&seq) * TAU;
		Kepler ke = { .Eccentricity = 0.2 + 0.2 * R0F(&seq) };
		
		flawt sprMin = g->Radius * 0.1;
		flawt sprAdd = g->Radius * 0.2;
		
		flawt ara = g->Radius * (1 - ke.Eccentricity);
		flawt arg = (0.5 + 0.5 * R0F(&seq)) * TAU;
		
		for (u32 i = 0; i < arms; ++i)
		{
			flawt dis = R0F(&seq);
			flawt cen = 1 - dis;
			flawt rar = R0F(&seq);
			
			ke.Argument = dis * arg;
			ke.SemiMajor = dis * ara;
			ke.Longitude = R1(&seq) ? lon + PIE : lon;
			
			b->Place.Center = Where(&ke, rar * TAU);
			Rotate(&b->Place.Center, &g->Orientation);
			Translate(&b->Place.Center, &g->Center);
			
			b->Tight = 0; b->Age = 255;
			b->Emit = 0.001; b->Depth = 4;
			
			b->Place.Spread = sprMin + sprAdd * rar; b->Place.SprZ = discZ + cen;
			b->Place.MapQis = pow(b->Place.Spread * 2, 2);
			b->Place.Neis = 9 * cen; b->Place.Level = 8 * dis;
			b->Place.VisQis = P2(MAXVIS);
			
			SaveBase(&seq, g, b++, 2);
		}
	}
	
	g->Resolved = 1;
}

void MakeGalaxy (Galaxy* g)
{
	Seed seq = g->Seed;
	
	g->Type = RR(&seq) % 3;
	g->RelativeSize = R0F(&seq);
	
	switch (g->Type)
	{
		case IRREGULAR: {
			g->Radius = 30 + g->RelativeSize * 3000;
			g->AverageColor = TempToRgb(127);
		} break;
		
		case ELLIPTICAL: {
			g->Radius = 150 + g->RelativeSize * 100000;
			g->AverageColor = TempToRgb(-128);
		} break;
		
		case SPIRAL: {
			g->Radius = 15000 + g->RelativeSize * 15000;
			g->AverageColor = TempToRgb(0);
		} break;
	}
	
	g->Raqius = P2(g->Radius);
	g->Bounds = g->Radius * 2;
	g->Bounqs = P2(g->Bounds);
	
	g->Orientation = RRot(&seq);
	
	g->Sparkle = 0;
	g->Bases = 0; g->Base = 0;
	g->Pov.Capture = 0;
	g->Close.System = 0;
	g->Resolved = 0;
}




void ClearGalaxy (Galaxy* g)
{
	if (g->Sparkle) ForChain(g->Sparkle, ZAP, ZAP);
	if (g->Base) {
		for each (Base, b, g->Base, g->Bases) UnmapPlace(&b->Place);
		zap(g->Base);
	}
	
	g->Resolved = 0;
	g->Sparkle = 0;
	g->Bases = 0;
	g->Base = 0;
}




void RenderGalaxy (Galaxy* g)
{
	g->Pov.QisToCen = Qis(g->Pov.Point, &g->Center);
	
	g->Pov.Alpha = 1 - g->Pov.QisToCen / Galaxies.FarQlip;
	g->Pov.Alpha = g->Pov.Alpha < 0 ? 0 : P2(g->Pov.Alpha);
	
	flawt qz = g->Raqius / g->Pov.QisToCen;
	
	g->Pov.RelArea = Eye.Qoom * qz;
	g->Pov.PixArea = Eye.Qixoom * qz;
	
	bool close = g->Pov.RelArea > GALRESRAR;
	bool onepi = g->Pov.PixArea < 1;
	
	if (g->Pov.QisToCen < g->Bounqs)
	{
		g->Pov.InSight = 1;
		Galaxies.Current = g;
	}
	else
	{
		Loc p = Project(&g->Center, g->Pov.Point, &Space.Pov.Turn);
		
		if (p.Z >= 0) g->Pov.InSight = 0;
		else
		{
			p.Z = Eye.Pixoom / p.Z;
			p.X *= p.Z, p.Y *= p.Z;
			
			flawt r = g->Radius * p.Z;
			
			Sprect rect;
			g->Pov.InSight = TrySprect(ROUND(p.X), ROUND(p.Y), MAX(2, r), &rect);
			
			if (g->Pov.InSight)
			{
				if (Eye.Photo)
				{
					if (onepi)
					{
						flawt emit = Galaxies.RealExpo * g->Pov.Alpha * r;
						LightSpot(&rect, &g->AverageColor, emit * 255);
					}
				}
				else
				{
					u8 Emit = Galaxies.BrightestSpot * g->Pov.Alpha;
					
					if (close)
					{
						flawt a = 0;
						
						if (g->Pov.RelArea < GALRESRAR) a = g->Pov.RelArea / GALRESRAR;
						else if (g->Pov.RelArea < GALSPOTCLIRAR) a = (GALSPOTCLIRAR - g->Pov.RelArea) / (GALSPOTCLIRAR - GALRESRAR);
						
						Emit *= P2(a);
					}
					
					LightSpot(&rect, &g->AverageColor, Emit);
				}
			}
		}
	}
	
	if (g->Pov.InSight)
	{
		if (!g->Resolved && !onepi && (close || Eye.Photo)) ResolveGalaxy(g);
		
		if (g->Resolved)
		{
			if (Eye.Photo)
			{
				for each (Base, b, g->Base, g->Bases)
				{
					PhotoPlace(&b->Place, b->Depth);
				}
			}
			else
			{
				g->Close.System = 0;
				g->Close.Qis = P2(SYSDIS);
				g->Systems = 0;
				
				flawt a = 1 - (GALSPOTMAXRAR - g->Pov.RelArea) / (GALSPOTMAXRAR - GALRESRAR);
				if (a > 1) a = 1;
				
				u8 fa = a * Galaxies.BrightestSparkle;
				
				if (fa)
				{
					u8 ba = fa / 4;
					
					for chain (g->Sparkle, si)
					{
						Sparkle* s = si->Value;
						
						Loc p = Project(&s->Center, g->Pov.Point, &Space.Pov.Turn);
						if (p.Z >= 0) continue;
						p.Z = Eye.Pixoom / p.Z;
						
						p.X *= p.Z; s16 x = ROUND(p.X); if (x <= Eye.X0 || x >= Eye.XP) continue;
						p.Y *= p.Z; s16 y = ROUND(p.Y); if (y <= Eye.Y0 || y >= Eye.YP) continue;
						
						if (s->Tight) DrawStar(x, y, &s->Color, fa);
						else {
							Light(Eye.YX[y][x].Color, &s->Color, fa);
							Light(Eye.YX[y][x].Back, &s->Color, ba);
						}
					}
				}
			}
		}
	}
	
	if (g->Resolved && !close) ClearGalaxy(g);
}

void RenderCloseGalaxy (Galaxy* g)
{
	if (!Eye.Photo)
	{
		for each (Base, b, g->Base, g->Bases)
		{
			RenderPlace(&b->Place);
		}
	}
	
	for (u16 i = 0; i < g->Systems; ++i)
	{
		System* s = g->System[i];
		
		if (s == g->Pov.Capture)
		{
			Space.Pov.Local = (Loc) {
				g->Pov.Capture->Origin->Center.X + g->Pov.Capture->Pov.Point.X / (1 PC),
				g->Pov.Capture->Origin->Center.Y + g->Pov.Capture->Pov.Point.Y / (1 PC),
				g->Pov.Capture->Origin->Center.Z + g->Pov.Capture->Pov.Point.Z / (1 PC)
			};
		}
		else
		{
			s->Pov.Point = (Loc)
			{
				(g->Pov.Point->X - s->Origin->Center.X) PC,
				(g->Pov.Point->Y - s->Origin->Center.Y) PC,
				(g->Pov.Point->Z - s->Origin->Center.Z) PC
			};
		}
		
		if (s != g->Close.System) RenderSystem(s);
	}
	
	if (g->Close.System)
	{
		RenderSystem(g->Close.System);
		
		if (
			g->Close.System->Order.First &&
			g->Close.System->Order.First->Body &&
			g->Close.System->Order.First->Body->Ready &&
			g->Close.System->Order.First->Body->Air &&
			g->Close.System->Order.First->Body->Air->Pov.Inside
		) {
			Galaxies.Modifier = (1 - g->Close.System->Order.First->Body->Air->Pov.Density);
			if (Galaxies.Modifier < 0) Galaxies.Modifier = 0;
		} else Galaxies.Modifier = 1;
	}
}
