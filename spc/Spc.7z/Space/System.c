typedef struct System {
	
	Place* Place;
	
	u32 Seed;
	Place* Origin;
	Loc Center;
	
	Chain (Object) Object;
	struct Object** Sun; u8 Suns;
	
	struct {
		Tree (Object) Object;
		struct Object* First;
	} Order;
	
	struct {
		Loc Point;
	} Pov;
	
	flawt Raqius;
	
} System;




void Screw (Seed* seq, Kepler* k, u8 sta)
{
	flawt f = RR(seq) % sta ? 0.05 : 1;
	
	k->Eccentricity += pow(RFF(seq), 2) * f;
	k->Inclination += pow(RFF(seq), 2) * TAU * f;
	k->Longitude += pow(RFF(seq), 2) * TAU * f;
	k->Argument += pow(RFF(seq), 2) * TAU * f;
	
	if (k->Eccentricity > 0.9) k->Eccentricity = 0.9;
	else if (k->Eccentricity < 0) k->Eccentricity = 0;
}




#include "Object.c"




Object* NewSun (Seed* seq, System* s, u8 lumi)
{
	Object* sun = NewObject(seq, s);
	
	sun->Tag = SUN;
	
	sun->Color = AgeLumToRgb(s->Place->Age, lumi);
	sun->Center = (Loc) { 0, 0, 0 };
	
	flawt lum = lumi / 255.0 + R0F(seq) / 255.0;
	sun->Lumi = (0.000001 + lum * 10000) SL;
	sun->Mass = (0.1 + lum * 40) SM;
	
	sun->Dif = (Hdrgb) { 0 };
	
	sun->Emi.R = sun->Color.R / 255.0; sun->Emi.R += (1 - sun->Emi.R) / 2;
	sun->Emi.G = sun->Color.G / 255.0; sun->Emi.G += (1 - sun->Emi.G) / 2;
	sun->Emi.B = sun->Color.B / 255.0; sun->Emi.B += (1 - sun->Emi.B) / 2;
	
	flawt age = s->Place->Age / 255.0 + R0F(seq) / 255.0;
	sun->Radius = (0.1 + lum * 8 + lum * age * 100) SR;
	
	sun->VisQis = s->Place->VisQis PC PC;
	sun->Hot = 1;
	
	return sun;
}

System* NewSystem (Place* place)
{
	System* s = new(System);
	
	s->Place = place;
	
	s->Origin = place;
	Seed seq = s->Seed = place->Seed;
	s->Center = (Loc){0};
	s->Raqius = place->SysQis PC PC;
	real limit = sqrt(place->SysQis) * 0.1 PC;
	
	Kepler proto =
	{
		.Focus = &s->Center,
		.Inclination = RFF(&seq) * TAU,
		.Longitude = RFF(&seq) * TAU,
		.Argument = RFF(&seq) * TAU
	};
	
	u8 stages = 1 + RR(&seq) % 6;
	
	s->Object = 0;
	
	s->Suns = 1 + (RR(&seq) % 8 ? 0 : 1);
	s->Sun = new(Object*, s->Suns);
	
	flawt mass;
	flawt outer;
	u8 lumi = place->Lumi;
	
	if (s->Suns == 1)
	{
		s->Sun[0] = Append(&s->Object, NewSun(&seq, s, lumi));
		FinishObject(s->Sun[0]);
		outer = 1000 ER + s->Sun[0]->Radius * (10 + R0F(&seq) * 100);
		mass = s->Sun[0]->Mass;
	}
	else
	{
		u8 l0 = RR(&seq) % (lumi + 1);
		
		Object* s0 = s->Sun[0] = Append(&s->Object, NewSun(&seq, s, lumi - l0));
		Object* s1 = s->Sun[1] = Append(&s->Object, NewSun(&seq, s, l0));
		
		s0->Orbit = new(Kepler);
		s1->Orbit = new(Kepler);
		
		*s0->Orbit = proto;
		*s1->Orbit = proto;
		
		s1->Orbit->Argument -= PIE;
		
		mass = s0->Mass + s1->Mass;
		flawt major = (s0->Radius + s1->Radius) * (2.5 + R0F(&seq) * 64);
		outer = 1000 ER + major * (2.5 + R0F(&seq) * 10);;
		
		s0->Orbit->SemiMajor = major * s1->Mass / mass;
		s1->Orbit->SemiMajor = major * s0->Mass / mass;
		
		s0->Orbit->Eccentricity = s1->Orbit->Eccentricity = R0F(&seq) * 0.5;
		s0->Orbit->Period = s1->Orbit->Period = GetPeriod(major, mass);
		
		FinishObject(s0);
		FinishObject(s1);
	}
	
	bool dust = R1(&seq);
	
	for (u8 cs = 0; cs < stages; ++cs)
	{
		if (dust)
		{
			flawt inner = outer;
			outer *= 1.1 + R0F(&seq) * 0.1;
			if (outer > limit) continue;
			
			for (u8 i = 0, it = 1 + R8(&seq) % 128; i < it; ++i)
			{
				Object* o = Append(&s->Object, NewObject(&seq, s));
				
				o->Tag = SMALL;
				
				o->Orbit = new(Kepler); *o->Orbit = proto;
				o->Orbit->SemiMajor = inner + R0F(&seq) * (outer - inner);
				
				o->Radius = 100 + 1000 KM * P2(R0F(&seq));
				o->Density = 1500 + 1500 * R0F(&seq);
				
				o->Subs = 0;
				
				FinishPlanet(&seq, o);
			}
		}
		else
		{
			for (u8 i = 0, it = 1 + R8(&seq) % 8; i < it; ++i)
			{
				Object* o = Append(&s->Object, NewObject(&seq, s));
				
				o->Orbit = new(Kepler);
				*o->Orbit = proto;
				
				outer = outer * (1.05 + R0F(&seq) * 0.1) + 0.1 AU;
				o->Orbit->SemiMajor = outer;
				outer = outer * (1.05 + R0F(&seq) * 0.1) + 0.1 AU;
				
				if (R1(&seq)) {
					o->Tag = ROCK;
					o->Density = 4000 + 2000 * R0F(&seq);
					o->Radius = (0.5 + 1.5 * R0F(&seq)) ER;
					o->Subs = RR(&seq) % 4;
				} else {
					o->Tag = GAS;
					o->Density = 500 + 1000 * R0F(&seq);
					o->Radius = (3 + 10 * R0F(&seq)) ER;
					o->Subs = RR(&seq) % 8;
				}
				
				FinishPlanet(&seq, o);
				
				if (outer > limit) continue;
			}
		}
		
		dust = !dust;
	}
	
	return s;
}

void ZapSystem (System* s)
{
	zap(s->Sun);
	ForChain(s->Object, (Handler) ZapObject, ZAP);
	zap(s->Order.Object);
	zap(s);
}




void RenderSystem (System* s)
{
	s->Order.First = 0;
	s->Order.Object = 0;
	
	for chain (s->Object, oi) RenderObject(oi->Value);
	
	if (s->Order.Object)
	{
		ForTree(s->Order.Object, (Handler)DrawObject, ZAP);
	}
}
