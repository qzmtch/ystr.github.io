typedef struct Object {
	
	System* System;
	struct Object* Primary;
	
	Seed Seed;
	enum { SUN, GAS, ROCK, SMALL, MOON } Tag;
	
	flawt Mass;
	flawt Density;
	real Radius;
	
	bool Hot;
	flawt Lumi;
	Hdrgb Dif, Emi;
	Rgb Color;
	
	Loc Center;
	Kepler* Orbit;
	
	real VisQis;
	real SubQis;
	real Raqius;
	
	struct Body* Body;
	Chain (Object) Sub; u16 Subs;
	
	struct SpaceLight {
		struct Object* Source;
		Loc Point;
		Loc Direction;
		Hdrgb Color;
	}* Light; u8 Lights;
	
	struct {
		Loc Point;
		real Qis;
	} Pov;
	
	#ifdef ObjectExtra
		ObjectExtra
	#endif
	
} Object;




flawt R2Mass (flawt radius, flawt density)
{
	return PIE * 4 / 3 * P3(radius) * density;
}

flawt Attenuate (flawt lumi, const Loc* p0, const Loc* p1)
{
	return lumi / Qis(p0, p1);
}




#include "Body.c"




Object* NewObject (Seed* seq, System* s)
{
	Object* o = nuw(Object);
	
	o->System = s;
	o->Seed = RS(seq);
	
	return o;
}

void FinishObject (Object* o)
{
	o->Raqius = P2(o->Radius);
	
	#ifdef OnObjectCreation
		OnObjectCreation(o);
	#endif
}

void FinishSolid (Seed* seq, Object* o)
{
	o->Orbit->Initial = RFF(seq) * TAU;
	o->Mass = R2Mass(o->Radius, o->Density);
	
	o->Dif = (Hdrgb) { 0.5, 0.5, 0.5 };
	o->Color = RGB(o->Dif.R * 255, o->Dif.G * 255, o->Dif.B * 255);
	o->Emi = (Hdrgb) { 0 };
	
	o->VisQis = pow(o->Radius * 10000, 2);
	o->SubQis = pow(o->Radius * 1000, 2);
	
	o->Light = new(struct SpaceLight, o->System->Suns); o->Lights = o->System->Suns;
	for (s32 i = 0; i < o->System->Suns; ++i) o->Light[i].Source = o->System->Sun[i];
	
	FinishObject(o);
}

void FinishPlanet (Seed* seq, Object* o)
{
	o->Primary = 0;
	Screw(seq, o->Orbit, 10);
	o->Orbit->Period = GetPeriod(o->Orbit->SemiMajor, o->System->Sun[0]->Mass);
	FinishSolid(seq, o);
}

void AddSubs (Object* o)
{
	Seed seq = o->Seed;
	
	real last = o->Radius * (2.5 + 20 * R0F(&seq));
	
	for (u16 i = 0; i < o->Subs; ++i)
	{
		Object* so = Append(&o->Sub, NewObject(&seq, o->System));
		
		so->Tag = MOON;
		so->Primary = o;
		
		so->Orbit = new(Kepler);
		*so->Orbit = *o->Orbit;
		so->Orbit->SemiMajor = last;
		so->Orbit->Focus = &o->Center;
		so->Orbit->Period = GetPeriod(so->Orbit->SemiMajor, o->Mass);
		Screw(&seq, so->Orbit, 10);
		
		so->Radius = 1000 + o->Radius * 0.25 * P2(R0F(&seq));
		so->Density = o->Density;
		
		FinishSolid(&seq, so);
		
		last += last * R0F(&seq) + so->Radius * 100;
	}
}

void ZapObject (Object* o)
{
	#ifdef OnObjectDestruction
		OnObjectDestruction(o);
	#endif
	
	if (o->Body) zap(o->Body);
	if (o->Orbit) zap(o->Orbit);
	
	if (o->Sub) ForChain(o->Sub, (Handler) ZapObject, ZAP);
	
	zap(o);
}




bool ObjectCloser (Object* o0, Object* o1)
{
	return o0->Pov.Qis < o1->Pov.Qis;
}

void RenderObject (Object* o)
{
	o->Pov.Qis = Qis(&o->System->Pov.Point, &o->Center);
	if (o->Orbit) o->Center = Revolve(o->Orbit);
	
	if (o->Pov.Qis > o->VisQis || o->Pov.Qis < 1) return;
	Insert(&o->System->Order.Object, o, (Comparer)ObjectCloser);
	if (!o->System->Order.First || o->Pov.Qis < o->System->Order.First->Pov.Qis) o->System->Order.First = o;
	
	if (o->System->Place->Root->Galaxy->Pov.FollowLocation == o) o->System->Pov.Point = Add(&o->Center, &o->Pov.Point);
	else o->Pov.Point = Sub(&o->System->Pov.Point, &o->Center);
	
	if (o->Pov.Qis < Eye.Qixoom * o->Raqius)
	{
		if (!o->Hot)
		{
			if (!o->Body) NewBody(o);
			
			if (o->Body->Ready)
			{
				if (o->System->Place->Root->Galaxy->Pov.FollowRotation == o)
				{
					Space.Pov.Turn = o->Body->CurRotation;
					Turn(&Space.Pov.Turn, &o->Body->Pov.Turn);
					o->Pov.Point = o->Body->Pov.Point;
					Rotate(&o->Pov.Point, &o->Body->CurRotation);
				}
				else
				{
					o->Body->Pov.Point = o->Pov.Point;
					Rotate(&o->Body->Pov.Point, &o->Body->InvCurRotation);
					o->Body->Pov.Turn = o->Body->InvCurRotation;
					Turn(&o->Body->Pov.Turn, &Space.Pov.Turn);
				}
			}
		}
	}
	else
	{
		if (o->Body && o->Body->Ready) ZapBody(o);
	}
	
	if (o->Subs)
	{
		if (o->Pov.Qis < o->SubQis) {
			if (!o->Sub) AddSubs(o);
			for chain (o->Sub, soi) RenderObject(soi->Value);
		} else if (o->Sub) {
			ForChain(o->Sub, (Handler) ZapObject, ZAP);
			o->Sub = 0;
		}
	}
}




void DrawObject (Object* o)
{
	flawt cla = 1;
	Hdrgb hue = { 1, 1, 1 };
	
	if (
		o->System->Order.First &&
		o->System->Order.First->Body &&
		o->System->Order.First->Body->Ready &&
		o->System->Order.First->Body->Air &&
		o->System->Order.First->Body->Air->Pov.Inside &&
		o->System->Order.First != o
	) {
		Air* a = o->System->Order.First->Body->Air;
		
		Loc n = Sub(&o->Center, &o->System->Order.First->Center); Norm(&n, 1);
		Rotate(&n, &o->System->Order.First->Body->InvCurRotation);
		
		flawt ze = Dot(&n, &o->System->Order.First->Body->Pov.Normal); if (ze < 0) ze = 0;
		flawt tangent = 1 - ze;
		
		flawt zo = a->Pov.Density;
		flawt to = zo * 32; if (to > 1) to = 1;
		
		flawt opa = zo + (to - zo) * tangent;
		cla = 1 - opa;
		
		hue.R = 1 - P2(opa * a->Color.R);
		hue.G = 1 - P2(opa * a->Color.G);
		hue.B = 1 - P2(opa * a->Color.B);
	}
	
	if (o->Light)
	{
		for each (struct SpaceLight, l, o->Light, o->Lights)
		{
			flawt lu = Attenuate(l->Source->Lumi, &l->Source->Center, &o->Center) * Eye.Expo * cla;
			
			l->Color.R = l->Source->Emi.R * lu * hue.R;
			l->Color.G = l->Source->Emi.G * lu * hue.G;
			l->Color.B = l->Source->Emi.B * lu * hue.B;
			
			l->Direction = l->Point = Sub(&l->Source->Center, &o->Center);
			Norm(&l->Direction, 1);
		}
	}
	
	if (o->Body && o->Body->Ready)
	{
		RenderBody(o->Body);
		return;
	}
	
	Loc p = Project(&o->Center, &o->System->Pov.Point, &Space.Pov.Turn);
	if (p.Z >= 0) return;
	p.Z = Eye.Pixoom / p.Z;
	
	p.X *= p.Z; s16 x = ROUND(p.X);
	p.Y *= p.Z; s16 y = ROUND(p.Y);
	
	bool outside = (
		x >= Eye.XP || x <= Eye.X0 ||
		y >= Eye.YP || y <= Eye.Y0
	);
	
	flawt radius = o->Radius * p.Z;
	if (outside && radius < 1) return;
	
	flawt bri = 0;
	Hdrgb light = {0};
	
	if (o->Hot)
	{
		flawt a = o->Lumi * Eye.Expo * cla;
		
		light.B = o->Emi.B * a * hue.B;
		light.G = o->Emi.G * a * hue.G;
		light.R = o->Emi.R * a * hue.R;
		
		bri = cla;
	}
	else
	{
		for each (struct SpaceLight, l, o->Light, o->Lights)
		{
			Loc vv = o->Pov.Point; Norm(&vv, 1);
			flawt angle = Dot(&l->Direction, &vv) + 0.5;
			if (angle > 0) bri += angle;
			
			light.B += o->Dif.B * l->Color.B;
			light.G += o->Dif.G * l->Color.G;
			light.R += o->Dif.R * l->Color.R;
		}
	}
	
	if (bri > 1) bri = 1;
	flawt opa = 1 - o->Pov.Qis / o->VisQis;
	if (opa < 0) bri = opa = 0;
	else { opa *= opa; bri *= opa; }
	
	Rgb color = RGB
	(
		(light.R < 1 ? light.R * 255 : 255) * bri,
		(light.G < 1 ? light.G * 255 : 255) * bri,
		(light.B < 1 ? light.B * 255 : 255) * bri
	);
	
	if (radius > 1) DrawOrb(x, y, radius, p.Z, &color);
	else {
		if (o->Hot) DrawStar(x, y, &o->Color, opa * 255);
		Blend(Eye.YX[y][x].Color, 255 - 255 * opa, &color);
	}
	
	if (o->Hot && !outside)
	{
		Glare* g = Append(&Eye.Glare, new(Glare));
		g->Color = RGB(o->Color.R * hue.R, o->Color.G * hue.G, o->Color.B * hue.B);
		g->Z = p.Z;
		g->Radius = radius;
		g->X = x, g->Y = y;
		g->Lumi = cla * Attenuate(o->Lumi, &o->Center, &o->System->Pov.Point);
		g->Alpha = 1 - Qis(&o->Center, &o->System->Pov.Point) / o->System->Raqius;
	}
}
