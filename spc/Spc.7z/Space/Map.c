typedef struct {
	
	Loc Center;
	
	real Outer;
	real Radius;
	
	real Depth;
	real Height;
	
} Crater;




typedef struct {
	
	Chain (Crater) Crater;
	
} Cell;

typedef struct Map {
	
	Crater* Crater; u32 Craters;
	
	s32 N, P, S;
	real CellSize;
	Cell*** XYZ, ***XYZ0;
	
} Map;




void CacheMap (Map* m, s32 p, flawt cellSize)
{
	m->S = p * 2 + 1;
	
	m->N = -p; m->P = p;
	m->CellSize = cellSize;
	
	m->XYZ = new(Cell***, m->S);
	m->XYZ0 = new(Cell***, m->S);
	
	for (s32 x = 0; x < m->S; ++x)
	{
		m->XYZ[x] = new(Cell*, m->S);
		m->XYZ0[x] = new(Cell*, m->S);
		
		for (s32 y = 0; y < m->S; ++y)
		{
			m->XYZ[x][y] = m->XYZ0[x][y] = new(Cell, m->S);
			
			for (s32 z = 0; z < m->S; ++z)
			{
				Cell* c = &m->XYZ[x][y][z];
				
				c->Crater = 0;
				
			}; m->XYZ[x][y] += p;
		}; m->XYZ[x] += p;
	}; m->XYZ += p;
	
	for each (Crater, c, m->Crater, m->Craters)
	{
		real fx = c->Center.X / m->CellSize; s32 xx = ROUND(fx);
		real fy = c->Center.Y / m->CellSize; s32 yy = ROUND(fy);
		real fz = c->Center.Z / m->CellSize; s32 zz = ROUND(fz);
		
		s32 rr = c->Radius / m->CellSize;
		if (rr < 1) rr = 1;
		
		s32 xn = xx - rr, xp = xx + rr;
		s32 yn = yy - rr, yp = yy + rr;
		s32 zn = zz - rr, zp = zz + rr;
		
		for (s32 x = xn; x <= xp; ++x)
		{
			for (s32 y = yn; y <= yp; ++y)
			{
				for (s32 z = zn; z <= zp; ++z)
				{
					Cell* ce = &m->XYZ[x][y][z];
					Append(&ce->Crater, c);
				}
			}
		}
	}
}

void ClearMap (Map* m)
{
	for (s32 x = 0; x < m->S; ++x) {
		for (s32 y = 0; y < m->S; ++y) {
			for (s32 z = 0; z < m->S; ++z) {
				
				Cell* c = &m->XYZ0[x][y][z];
				
				ForChain(c->Crater, NOP, ZAP);
				
			}; zap(m->XYZ0[x][y]);
		}; zap(m->XYZ0[x]);
	} zap(m->XYZ0);
}




Cell* FindCell (Map* m, Loc* v)
{
	flawt xf = v->X / m->CellSize; s16 x = ROUND(xf);
	flawt yf = v->Y / m->CellSize; s16 y = ROUND(yf);
	flawt zf = v->Z / m->CellSize; s16 z = ROUND(zf);
	
	return &m->XYZ[x][y][z];
}

void Displace (Vertex* v, Map* m)
{
	Cell* cell = FindCell(m, &v->Point);
	
	for chain (cell->Crater, crai)
	{
		Crater* cra = crai->Value;
		
		real dis = Dis(&cra->Center, &v->Point);
		real all = cra->Depth + cra->Height;
		
		if (dis < cra->Outer)
		{
			if (dis < cra->Radius)
			{
				real edg = dis / cra->Radius; edg *= P4(edg);
				real nor = v->UnmapdNorm - cra->Depth + edg * all;
				Renorm(&v->Point, v->UnmapdNorm, nor);
			}
			else
			{
				real edg = 1 - (dis - cra->Radius) / (cra->Outer - cra->Radius); edg *= edg;
				real nor = v->UnmapdNorm + cra->Height * edg;
				Renorm(&v->Point, v->UnmapdNorm, nor);
			}
		}
	}
}
