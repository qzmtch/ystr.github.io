typedef struct Air {
	
	Hdrgb Color;
	
	Hdrgb Diffuse;
	Hdrgb Tangent;
	
	flawt Clarity, Density;
	flawt Lucidity, Opacity;
	flawt Overglow;
	
	flawt Thickness;
	flawt BottomLimit;
	flawt RcGround;
	flawt Top;
	
	flawt InvQisi;
	
	struct {
		bool Inside;
		flawt Clarity, Density;
		struct { flawt Ground, Air; } Balance;
		flawt Altitude, RelAltitude, DisToCenter;
		flawt InvQisi;
		Hdrgb SkyFill;
	} Pov;
	
} Air;



void PutAirPixel (Pixel* p, flawt r, flawt g, flawt b, flawt c, void* args)
{
	Blend(p->Color, c, &RGB(r,g,b));
}



#define LIMBRES 64
Loc* LimbCircle;

void PrepareLimb ()
{
	LimbCircle = new(Loc, LIMBRES);
	
	flawt a = 0; for (u32 i = 0; i < LIMBRES; i++)
	{
		LimbCircle[i] = (Loc) { cos(a), sin(a), 0 };
		a += TAU / LIMBRES;
	}
}



void FindTangent (real dis, real rad, real fix, real* mul, real* zee)
{
	fix += rad; if (dis < fix) dis = fix;
	*mul = sqrt(P2(dis) - P2(rad)) * rad / dis;
	*zee = sqrt(P2(rad) - P2(*mul));
}

Loc Orient (u32 ci, real mul, real zee, Rot* look)
{
	Loc p = LimbCircle[ci];
	p.X *= mul, p.Y *= mul, p.Z = zee;
	Rotate(&p, look); return p;
}

Rot LookAt (Loc* dir)
{
	float ha = acos(dir->Z) * 0.5, sha = sin(ha);
	Loc axs = { -dir->Y, dir->X, 0 }; Norm(&axs, 1);
	return (Rot) { axs.X * sha, axs.Y * sha, 0, cos(ha) };
}



void DrawLimb (Body* b)
{
	flawt lval = b->Air->Pov.RelAltitude;
	if (lval <= 0) return; else if (lval > 1) lval = 1;
	
	Rot look = LookAt(&b->Pov.Normal);
	
	flawt bot = b->Object->Radius - b->Air->Pov.Altitude;
	if (bot < b->Air->BottomLimit) bot = b->Air->BottomLimit;
	
	real gndmul, gndzee;
	FindTangent(b->Air->Pov.DisToCenter, b->Object->Radius, b->Air->Thickness, &gndmul, &gndzee);
	
	for (u32 i0 = 0, i1 = 1; i0 < LIMBRES; i0++, i1++)
	{
		if (i1 >= LIMBRES) i1 = 0;
		
		Loc vgnd0 = Orient(i0, gndmul, gndzee, &look);
		Loc vgnd1 = Orient(i1, gndmul, gndzee, &look);
		Loc norm0 = vgnd0; Rcnorm(&norm0, b->Air->RcGround, 1);
		Loc norm1 = vgnd1; Rcnorm(&norm1, b->Air->RcGround, 1);
		Loc vtop0 = Mul(&norm0, b->Air->Top);
		Loc vtop1 = Mul(&norm1, b->Air->Top);
		Loc vbot0 = Mul(&norm0, bot);
		Loc vbot1 = Mul(&norm1, bot);
		
		Loc pgnd0 = Project(&vgnd0, &b->Pov.Point, &b->Pov.Turn); if (pgnd0.Z >= 0) continue; pgnd0.Z = Eye.Pixoom / pgnd0.Z;
		Loc ptop0 = Project(&vtop0, &b->Pov.Point, &b->Pov.Turn); if (ptop0.Z >= 0) continue; ptop0.Z = Eye.Pixoom / ptop0.Z;
		Loc pbot0 = Project(&vbot0, &b->Pov.Point, &b->Pov.Turn); if (pbot0.Z >= 0) continue; pbot0.Z = Eye.Pixoom / pbot0.Z;
		Loc pgnd1 = Project(&vgnd1, &b->Pov.Point, &b->Pov.Turn); if (pgnd1.Z >= 0) continue; pgnd1.Z = Eye.Pixoom / pgnd1.Z;
		Loc ptop1 = Project(&vtop1, &b->Pov.Point, &b->Pov.Turn); if (ptop1.Z >= 0) continue; ptop1.Z = Eye.Pixoom / ptop1.Z;
		Loc pbot1 = Project(&vbot1, &b->Pov.Point, &b->Pov.Turn); if (pbot1.Z >= 0) continue; pbot1.Z = Eye.Pixoom / pbot1.Z;
		
		Apex agnd0 = { .X = pgnd0.X * pgnd0.Z, .Y = pgnd0.Y * pgnd0.Z };
		Apex atop0 = { .X = ptop0.X * ptop0.Z, .Y = ptop0.Y * ptop0.Z };
		Apex abot0 = { .X = pbot0.X * pbot0.Z, .Y = pbot0.Y * pbot0.Z };
		Apex agnd1 = { .X = pgnd1.X * pgnd1.Z, .Y = pgnd1.Y * pgnd1.Z };
		Apex atop1 = { .X = ptop1.X * ptop1.Z, .Y = ptop1.Y * ptop1.Z };
		Apex abot1 = { .X = pbot1.X * pbot1.Z, .Y = pbot1.Y * pbot1.Z };
		
		Hdrgb abs0 = {0};
		Hdrgb abs1 = {0};
		
		for each (struct SkyLight, l, b->Light, b->Lights)
		{
			Hdrgb glow = {
				l->Outer->Color.R * b->Air->Diffuse.R * lval,
				l->Outer->Color.G * b->Air->Diffuse.G * lval,
				l->Outer->Color.B * b->Air->Diffuse.B * lval
			};
			
			flawt ze0 = Dot(&l->Direction, &norm0);
			flawt ze1 = Dot(&l->Direction, &norm1);
			
			if (ze0 > 0) { abs0.R += glow.R * ze0; abs0.G += glow.G * ze0; abs0.B += glow.B * ze0; }
			if (ze1 > 0) { abs1.R += glow.R * ze1; abs1.G += glow.G * ze1; abs1.B += glow.B * ze1; }
		}
		
		atop0.Color = atop1.Color = (Hdrgb){0};
		atop0.Z = atop1.Z = 255;
		
		agnd0.Color = ClampHd255(&abs0), agnd1.Color = ClampHd255(&abs1);
		agnd0.Z = agnd1.Z = b->Air->Clarity * 255;
		
		abot0.Color = agnd0.Color, abot1.Color = agnd1.Color;
		abot0.Z = abot1.Z = 0;
		
		DrawTri(&agnd0, &atop0, &atop1, PutAirPixel, b->Air);
		DrawTri(&agnd0, &atop1, &agnd1, PutAirPixel, b->Air);
		DrawTri(&abot0, &agnd0, &agnd1, PutAirPixel, b->Air);
		DrawTri(&abot0, &agnd1, &abot1, PutAirPixel, b->Air);
	}
}

void RenderAir (Body* b)
{
	b->Air->Pov.DisToCenter = Len(&b->Pov.Point);
	b->Air->Pov.Altitude = b->Air->Pov.DisToCenter - b->Object->Radius;
	b->Air->Pov.RelAltitude = b->Air->Pov.Altitude / b->Air->Thickness;
	b->Air->Pov.Inside = b->Air->Pov.RelAltitude < 1;
	
	flawt dep = 1 - b->Air->Pov.RelAltitude;
	flawt den = dep > 0 ? P3(dep) : 0;
	
	b->Air->Pov.Density = den * b->Air->Density;
	if (b->Air->Pov.Density > 1) b->Air->Pov.Density = 1;
	b->Air->Pov.Clarity = 1 - b->Air->Pov.Density;
	
	if (b->Air->Pov.Inside) b->Air->Pov.Balance.Ground = b->Air->Clarity + b->Air->Density * (den > 1 ? 1 : den);
	else b->Air->Pov.Balance.Ground = b->Air->Clarity;
	b->Air->Pov.Balance.Air = 1 - b->Air->Pov.Balance.Ground;
	
	flawt ld = den - 0.5;
	if (ld > 0) b->Air->Pov.InvQisi = b->Air->InvQisi * pow(ld * 2, 6);
	else b->Air->Pov.InvQisi = 0;
	
	flawt after = b->Air->Overglow * dep;
	flawt tlu = b->Air->Lucidity + b->Air->Opacity * b->Air->Pov.RelAltitude;
	
	if (tlu < 0) tlu = 0;
	flawt td = tlu * dep;
	if (td > 1) td = 1;
	
	Hdrgb sca = (Hdrgb) { b->Air->Diffuse.R * td, b->Air->Diffuse.G * td, b->Air->Diffuse.B * td };
	
	b->Air->Pov.SkyFill = (Hdrgb){0};
	
	for each (struct SkyLight, l, b->Light, b->Lights)
	{
		flawt ze = Dot(&l->Direction, &b->Pov.Normal) + after;
		if (ze < 0) ze = 0; else if (ze > 1) ze = 1;
		
		b->Air->Pov.SkyFill.R += l->Outer->Color.R * sca.R * ze;
		b->Air->Pov.SkyFill.G += l->Outer->Color.G * sca.G * ze;
		b->Air->Pov.SkyFill.B += l->Outer->Color.B * sca.B * ze;
	}
	
	DrawLimb(b);
	
	if (b->Air->Pov.Inside)
	{
		Rgb fcol = Clamp(&b->Air->Pov.SkyFill);
		u8 fclar = b->Air->Pov.Clarity * 255;
		
		for each (Pixel, p, Eye.Data, Eye.Total) Blend(p->Color, fclar, &fcol);
	}
}
