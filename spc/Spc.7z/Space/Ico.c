#define ICOX 0.525731112
#define ICOZ 0.850650808

void NewIcoVex (Seed* seq, Mesh* h, Vertex* v, Loc* p, real ra, Rot* rot)
{
	v->Seed = RS(seq);
	
	v->Point = *p;
	v->UnmapdNorm = ra;
	
	Rotate(&v->Point, rot);
	Translate(&v->Point, &h->Center);
	
	v->Cache.Done = 0;
	v->Color = h->Color;
	
	if (h->Map) Displace(v, h->Map);
}

void Ico (Seed* seq, Mesh* h, real radius)
{
	h->Bounqs = P2(radius) * 2;
	
	Rot ro = RRot(seq);
	
	Vertex* v = h->Vx = new(Vertex, h->Vs = 14);
	Edge* e = h->Ex = new(Edge, h->Es = 30);
	Face* f = h->Fx = new(Face, h->Fs = 20);
	
	real x = ICOX * radius;
	real z = ICOZ * radius;
	
	#define VER(X,Y,Z) NewIcoVex(seq, h, v++, &(Loc){X,Y,Z}, radius, &ro);
	VER(-x, 0, +z) VER(+x, 0, +z) VER(-x, 0, -z) VER(+x, 0, -z)
	VER(0, +z, +x) VER(0, +z, -x) VER(0, -z, +x) VER(0, -z, -x)
	VER(+z, +x, 0) VER(-z, +x, 0) VER(+z, -x, 0) VER(-z, -x, 0)
	
	#define EDG(E0,E1) NewEdge(h, e++, &h->Vx[E0], &h->Vx[E1]);
	EDG(0, 1) EDG(0, 4) EDG(0, 6) EDG(0, 9) EDG(0,11) EDG(1, 4)
	EDG(1, 6) EDG(1, 8) EDG(1,10) EDG(2, 3) EDG(2, 5) EDG(2, 7)
	EDG(2, 9) EDG(2,11) EDG(3, 5) EDG(3, 7) EDG(3, 8) EDG(3,10)
	EDG(4, 5) EDG(4, 8) EDG(4, 9) EDG(5, 8) EDG(5, 9) EDG(6, 7)
	EDG(6,10) EDG(6,11) EDG(7,10) EDG(7,11) EDG(8,10) EDG(9,11)
	
	#define FCE(V0,V1,V2,E0,E1,E2) NewFace(seq, h, f++, &h->Vx[V0], &h->Vx[V1], &h->Vx[V2], &h->Ex[E0], &h->Ex[E1], &h->Ex[E2]);
	FCE( 0, 4, 1, 5, 0, 1) FCE( 0, 9, 4,20, 1, 3) FCE( 9, 5, 4,18,20,22) FCE( 4, 5, 8,21,19,18)
	FCE( 4, 8, 1, 7, 5,19) FCE( 8,10, 1, 8, 7,28) FCE( 8, 3,10,17,28,16) FCE( 5, 3, 8,16,21,14)
	FCE( 5, 2, 3, 9,14,10) FCE( 2, 7, 3,15, 9,11) FCE( 7,10, 3,17,15,26) FCE( 7, 6,10,24,26,23)
	FCE( 7,11, 6,25,23,27) FCE(11, 0, 6, 2,25, 4) FCE( 0, 1, 6, 6, 2, 0) FCE( 6, 1,10, 8,24, 6)
	FCE( 9, 0,11, 4,29, 3) FCE( 9,11, 2,13,12,29) FCE( 9, 2, 5,10,22,12) FCE( 7, 2,11,13,27,11)
}
