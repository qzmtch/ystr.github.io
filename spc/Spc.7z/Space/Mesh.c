typedef struct { Apex Apex; u16 Summands; } CachedApex;
typedef struct { CachedApex *A0, *A1, *A2; } CachedFace;

typedef struct Occlusor {
	
	Loc Center;
	flawt Bounqs;
	
	struct Occlusor* Sub; u8 Subs;
	struct OccTri { Loc V0, V1, V2; }* Tri; u8 Tris;
	
} Occlusor;

typedef struct {
	
	Seed Seed;
	
	Loc Point;
	real UnmapdNorm;
	Hdrgb Color;
	
	struct {
		bool Done;
		CachedApex Apex;
	} Cache;
	
} Vertex;

typedef struct Edge {
	
	Vertex *V0, M, *V1;
	struct Edge* Sub;
	
} Edge;

typedef struct {
	
	Seed Seed;
	
	Loc Center;
	flawt Bounqs;
	Hdrgb Color;
	
	Vertex* Vx; u32 Vs;
	Edge* Ex; u32 Es;
	struct Face* Fx; u32 Fs;
	
	flawt Roughness;
	u8 StuffProb;
	real StuffMax;
	
	struct Map* Map;
	
} Mesh;

typedef struct Face {
	
	Seed Seed;
	
	Hdrgb Color;
	Loc Normal;
	
	Loc Center;
	Loc NorCen;
	
	flawt Bounds;
	flawt Bounqs;
	
	flawt Ambient;
	
	Vertex *V0, *V1, *V2;
	Edge *E0, *E1, *E2;
	
	Edge* Mid;
	struct Face* Sub;
	
	Mesh* Stuff;
	bool Stuffed;
	
} Face;




#include "Map.c"




void NewFace (
	Seed* seq, Mesh* h, Face* t,
	Vertex* v0, Vertex* v1, Vertex* v2,
	Edge* e0, Edge* e1, Edge* e2
) {
	t->V0 = v0; t->V1 = v1; t->V2 = v2;
	t->E0 = e0; t->E1 = e1; t->E2 = e2;
	
	t->Center.X = (v0->Point.X + v1->Point.X + v2->Point.X) / 3;
	t->Center.Y = (v0->Point.Y + v1->Point.Y + v2->Point.Y) / 3;
	t->Center.Z = (v0->Point.Z + v1->Point.Z + v2->Point.Z) / 3;
	
	t->NorCen = t->Center;
	Norm(&t->NorCen, 1);
	
	t->Bounqs = Max3 (
		Qis(&t->Center, &v0->Point),
		Qis(&t->Center, &v1->Point),
		Qis(&t->Center, &v2->Point)
	) * 2;
	
	t->Bounds = sqrt(t->Bounqs);
	
	t->Normal = TriNormal(&v0->Point, &v1->Point, &v2->Point);
	
	flawt ve = Dot(&t->Normal, &t->NorCen);
	t->Ambient = 0.5 + ve * 0.5;
	
	t->Color.R = (v0->Color.R + v1->Color.R + v2->Color.R) / 3;
	t->Color.G = (v0->Color.G + v1->Color.G + v2->Color.G) / 3;
	t->Color.B = (v0->Color.B + v1->Color.B + v2->Color.B) / 3;
	
	t->Stuff = 0;
	t->Sub = 0;
	t->Mid = 0;
	
	ve -= 0.8; if (ve < 0) ve = 0;
	
	t->Stuffed = (
		t->Bounds < h->StuffMax &&
		t->Bounds > 1 MM &&
		R8(seq) < h->StuffProb * ve * 5
	);
	
	t->Seed = RS(seq);
}

void NewEdge (Mesh* h, Edge* e, Vertex* v0, Vertex* v1)
{
	Seed seq = v0->Seed ^ v1->Seed;
	
	e->V0 = v0, e->V1 = v1;
	e->M.UnmapdNorm = (v0->UnmapdNorm + v1->UnmapdNorm) / 2;
	
	Loc old = MeanLoc(&v0->Point, &v1->Point);
	Loc own = Sub(&old, &h->Center); Norm(&own, e->M.UnmapdNorm);
	e->M.Point = Add(&h->Center, &own);
	
	real elen = Dis(&v0->Point, &v1->Point);
	flawt sf = 1000.0 / elen; if (sf > 1) sf = 1;
	real s = h->Roughness * elen * sf;
	
	e->M.Seed = RS(&seq);
	
	e->M.Point.X += s * RFF(&seq);
	e->M.Point.Y += s * RFF(&seq);
	e->M.Point.Z += s * RFF(&seq);
	
	e->M.Color.R = (v0->Color.R + v1->Color.R) / 2 + RFF(&seq) * 0.025;
	e->M.Color.G = (v0->Color.G + v1->Color.G) / 2 + RFF(&seq) * 0.025;
	e->M.Color.B = (v0->Color.B + v1->Color.B) / 2 + RFF(&seq) * 0.025;
	
	e->M.UnmapdNorm = Dis(&h->Center, &e->M.Point);
	if (h->Map) Displace(&e->M, h->Map);
	
	e->M.Cache.Done = 0;
	e->Sub = 0;
}

void SplitEdge (Mesh* h, Edge* e)
{
	e->Sub = new(Edge, 2);
	
	NewEdge(h, &e->Sub[0], &e->M, e->V0);
	NewEdge(h, &e->Sub[1], &e->M, e->V1);
}




#include "Ico.c"




void ClearEdge (Edge* e)
{
	if (!e->Sub) return;
	
	ClearEdge(&e->Sub[0]);
	ClearEdge(&e->Sub[1]);
	
	zap(e->Sub);
	e->Sub = 0;
}

void ZapMesh (Mesh* h);
void ClearFace (Face* f)
{
	if (f->Stuff)
	{
		ZapMesh(f->Stuff);
		f->Stuff = 0;
	}
	
	if (f->Sub)
	{
		ClearFace(&f->Sub[0]);
		ClearFace(&f->Sub[1]);
		ClearFace(&f->Sub[2]);
		ClearFace(&f->Sub[3]);
		
		zap(f->Sub);
		f->Sub = 0;
	}
	
	if (f->Mid)
	{
		ClearEdge(&f->Mid[0]);
		ClearEdge(&f->Mid[1]);
		ClearEdge(&f->Mid[2]);
		
		zap(f->Mid);
		f->Mid = 0;
	}
}

void ZapMesh (Mesh* h)
{
	for each (Face, t, h->Fx, h->Fs) ClearFace(t);
	for each (Edge, e, h->Ex, h->Es) ClearEdge(e);
	
	zap(h->Fx);
	zap(h->Ex);
	zap(h->Vx);
	
	if (h->Map)
	{
		ClearMap(h->Map);
		zap(h->Map);
	}
	
	zap(h);
}
