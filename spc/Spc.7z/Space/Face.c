void SumApex (CachedApex* ca, const Hdrgb* color)
{
	ca->Apex.Color.R += color->R;
	ca->Apex.Color.G += color->G;
	ca->Apex.Color.B += color->B;
	
	ca->Summands++;
}

void ShadeApex (Body* b, CachedApex* a)
{
	flawt rs = 1.0 / a->Summands;
	
	a->Apex.Color.R *= rs;
	a->Apex.Color.G *= rs;
	a->Apex.Color.B *= rs;
	
	a->Apex.Color.R = a->Apex.Color.R < 1 ? a->Apex.Color.R * 255.0 : 255.0;
	a->Apex.Color.G = a->Apex.Color.G < 1 ? a->Apex.Color.G * 255.0 : 255.0;
	a->Apex.Color.B = a->Apex.Color.B < 1 ? a->Apex.Color.B * 255.0 : 255.0;
}



Chain(CachedApex)* FindIndex (Vertex* v)
{
	s32 x = (s32) v->Cache.Apex.Apex.X % (Eye.XP - 1);
	s32 y = (s32) v->Cache.Apex.Apex.Y % (Eye.YP - 1);
	
	return (Chain(CachedApex)*) &Eye.YX[y][x].Special;
}

CachedApex* FindApex (Chain(CachedApex)* index, Vertex* v)
{
	for chain (*index, cai)
	{
		CachedApex* ca = cai->Value;
		if (ca->Apex.Z == v->Cache.Apex.Apex.Z) return ca;
	}
	
	return 0;
}



void PushVertex (Body* b, Vertex* v)
{
	if (v->Cache.Done) return;
	
	Loc p = Project(&v->Point, &b->Pov.Point, &b->Pov.Turn);
	
	v->Cache.Apex.Apex.Z = Eye.Pixoom / p.Z;
	v->Cache.Apex.Apex.X = p.X * v->Cache.Apex.Apex.Z;
	v->Cache.Apex.Apex.Y = p.Y * v->Cache.Apex.Apex.Z;
	
	v->Cache.Apex.Summands = 0;
	v->Cache.Apex.Apex.Color = (Hdrgb){0};
	
	if (Eye.Photo)
	{
		Chain(CachedApex)* cai = FindIndex(v);
		if (FindApex(cai, v)) return;
		
		CachedApex* na = Append(cai, new(CachedApex));
		*na = v->Cache.Apex;
		
		return;
	}
	
	Bufferize(b->VertexCache, Vertex*);
	b->VertexCache.Buffer[b->VertexCache.Count++] = v;
	
	v->Cache.Done = 1;
}



void SubFace (Mesh* h, Face* f)
{
	if (!f->Sub)
	{
		Seed seq = f->Seed;
		
		if (!f->E0->Sub) SplitEdge(h, f->E0);
		if (!f->E1->Sub) SplitEdge(h, f->E1);
		if (!f->E2->Sub) SplitEdge(h, f->E2);
		
		f->Mid = new(Edge, 3);
		f->Sub = new(Face, 4);
		
		NewEdge(h, &f->Mid[0], &f->E1->M, &f->E2->M);
		NewEdge(h, &f->Mid[1], &f->E2->M, &f->E0->M);
		NewEdge(h, &f->Mid[2], &f->E0->M, &f->E1->M);
		
		Edge *s0m, *sm1, *s1m, *sm2, *s2m, *sm0;
		
		if (f->E0->Sub[0].V1 == f->V1) { s1m = &f->E0->Sub[0]; sm2 = &f->E0->Sub[1]; }
		else { s1m = &f->E0->Sub[1]; sm2 = &f->E0->Sub[0]; }
		if (f->E1->Sub[0].V1 == f->V2) { s2m = &f->E1->Sub[0]; sm0 = &f->E1->Sub[1]; }
		else { s2m = &f->E1->Sub[1]; sm0 = &f->E1->Sub[0]; }
		if (f->E2->Sub[0].V1 == f->V0) { s0m = &f->E2->Sub[0]; sm1 = &f->E2->Sub[1]; }
		else { s0m = &f->E2->Sub[1]; sm1 = &f->E2->Sub[0]; }
		
		NewFace(&seq, h, &f->Sub[0], f->V0, &f->E2->M, &f->E1->M, &f->Mid[0], sm0, s0m);
		NewFace(&seq, h, &f->Sub[1], f->V1, &f->E0->M, &f->E2->M, &f->Mid[1], sm1, s1m);
		NewFace(&seq, h, &f->Sub[2], f->V2, &f->E1->M, &f->E0->M, &f->Mid[2], sm2, s2m);
		NewFace(&seq, h, &f->Sub[3], &f->E0->M, &f->E1->M, &f->E2->M, &f->Mid[0], &f->Mid[1], &f->Mid[2]);
	}
}

void MakeStuff (Face* f)
{
	if (!f->Stuff)
	{
		f->Stuff = new(Mesh);
		
		f->Stuff->Color = f->Color;
		f->Stuff->Center = f->Center;
		
		f->Stuff->StuffProb = 0;
		f->Stuff->Map = 0;
		
		Seed seq = f->Stuff->Seed = f->Seed;
		
		f->Stuff->Roughness = 0.05 + R0F(&seq) * 0.05;
		real r = f->Bounds * 0.1;
		
		Ico(&seq, f->Stuff, r);
	}
}




void PutFacePixel (Pixel* p, flawt r, flawt g, flawt b, flawt z, void* args)
{
	if (z >= p->Z)
	{
		p->Color->R = r;
		p->Color->G = g;
		p->Color->B = b;
		
		p->Z = z;
	}
}



void PushFace (Body* b, Face* f, Vertex* v0, Vertex* v1, Vertex* v2, real qis)
{
	if (
		(v2->Cache.Apex.Apex.X - v1->Cache.Apex.Apex.X) * (v1->Cache.Apex.Apex.Y - v0->Cache.Apex.Apex.Y) <=
		(v1->Cache.Apex.Apex.X - v0->Cache.Apex.Apex.X) * (v2->Cache.Apex.Apex.Y - v1->Cache.Apex.Apex.Y)
	) return;
	
	Hdrgb color = {0};
	
	if (b->Air)
	{
		Hdrgb gnd = {0};
		Hdrgb air = {0};
		
		for each (struct SkyLight, l, b->Light, b->Lights)
		{
			flawt dir = Dot(&l->Direction, &f->Normal); if (dir < 0) dir = 0;
			flawt zen = Dot(&l->Direction, &f->NorCen); if (zen < 0) zen = 0;
			flawt amb = f->Ambient * zen;
			flawt tan = 1 - zen;
			
			gnd.R += l->Direct.R * dir * (1 - b->Air->Tangent.R * tan) + l->Ambient.R * amb;
			gnd.G += l->Direct.G * dir * (1 - b->Air->Tangent.G * tan) + l->Ambient.G * amb;
			gnd.B += l->Direct.B * dir * (1 - b->Air->Tangent.B * tan) + l->Ambient.B * amb;
			
			air.R += l->Outer->Color.R * b->Air->Diffuse.R * zen;
			air.G += l->Outer->Color.G * b->Air->Diffuse.G * zen;
			air.B += l->Outer->Color.B * b->Air->Diffuse.B * zen;
		}
		
		color.R = gnd.R * b->Air->Pov.Balance.Ground * f->Color.R + air.R * b->Air->Pov.Balance.Air;
		color.G = gnd.G * b->Air->Pov.Balance.Ground * f->Color.G + air.G * b->Air->Pov.Balance.Air;
		color.B = gnd.B * b->Air->Pov.Balance.Ground * f->Color.B + air.B * b->Air->Pov.Balance.Air;
		
		if (b->Air->Pov.Inside)
		{
			flawt si = qis * b->Air->Pov.InvQisi;
			if (si > 1) si = 1; else if (si < 0) si = 0;
			flawt gi = 1 - si; gi *= gi * gi; si = 1 - gi;
			
			color.R = color.R * gi + b->Air->Pov.SkyFill.R * si;
			color.G = color.G * gi + b->Air->Pov.SkyFill.G * si;
			color.B = color.B * gi + b->Air->Pov.SkyFill.B * si;
		}
	}
	else
	{
		for each (struct SkyLight, l, b->Light, b->Lights)
		{
			flawt dir = Dot(&l->Direction, &f->Normal); if (dir < 0) continue;
			if (Dot(&l->Direction, &f->NorCen) < 0) continue;
			
			color.R += l->Direct.R * dir;
			color.G += l->Direct.G * dir;
			color.B += l->Direct.B * dir;
		}
		
		color.R *= f->Color.R;
		color.G *= f->Color.G;
		color.B *= f->Color.B;
	}
	
	Bufferize(b->FaceCache, CachedFace);
	CachedFace* cf = &b->FaceCache.Buffer[b->FaceCache.Count++];
	
	if (Eye.Photo)
	{
		Hdrgb dco = ClampHd255(&color);
		
		Apex a0 = v0->Cache.Apex.Apex; a0.Color = dco;
		Apex a1 = v1->Cache.Apex.Apex; a1.Color = dco;
		Apex a2 = v2->Cache.Apex.Apex; a2.Color = dco;
		
		DrawTri(&a0, &a1, &a2, PutFacePixel, 0);
		
		cf->A0 = FindApex(FindIndex(v0), v0);
		cf->A1 = FindApex(FindIndex(v1), v1);
		cf->A2 = FindApex(FindIndex(v2), v2);
	}
	else
	{
		cf->A0 = &v0->Cache.Apex;
		cf->A1 = &v1->Cache.Apex;
		cf->A2 = &v2->Cache.Apex;
	}
	
	SumApex(cf->A0, &color);
	SumApex(cf->A1, &color);
	SumApex(cf->A2, &color);
}

void RenderFace (Body* b, Mesh* h, Face* f, real qlose)
{
	real qc = Qis(&b->Pov.Point, &f->Center);
	
	if (qc < b->Close.Qis)
	{
		b->Close.Qis = qc;
		b->Close.Face = f;
	}
	
	if (qc > f->Bounqs)
	{
		Loc aa = Project(&f->Center, &b->Pov.Point, &b->Pov.Turn);
		if (aa.Z >= 0) return;
		aa.Z = Eye.Pixoom / aa.Z;
		s16 aax = aa.X * aa.Z, aay = aa.Y * aa.Z;
		s16 aas = f->Bounds * aa.Z;
		
		if (
			aax - aas > Eye.XP || aax + aas < Eye.X0 ||
			aay - aas > Eye.YP || aay + aas < Eye.Y0
		) return;
	}
	
	bool mc0 = Qis(&b->Pov.Point, &f->E0->M.Point) < qlose;
	bool mc1 = Qis(&b->Pov.Point, &f->E1->M.Point) < qlose;
	bool mc2 = Qis(&b->Pov.Point, &f->E2->M.Point) < qlose;
	
	switch (mc0 + mc1 + mc2)
	{
		case 0: {
			
			PushVertex(b, f->V0);
			PushVertex(b, f->V1);
			PushVertex(b, f->V2);
			
			PushFace(b, f, f->V0, f->V1, f->V2, qc);
			
		} break;
		
		case 1: {
			
			Vertex *tt, *a0, *a1, *mm;
			
			if (mc0) tt = f->V0, mm = &f->E0->M, a0 = f->V2, a1 = f->V1;
			else if (mc1) tt = f->V1, mm = &f->E1->M, a0 = f->V0, a1 = f->V2;
			else tt = f->V2, mm = &f->E2->M, a0 = f->V1, a1 = f->V0;
			
			PushVertex(b, tt);
			PushVertex(b, a0);
			PushVertex(b, a1);
			PushVertex(b, mm);
			
			PushFace(b, f, mm, a0, tt, qc);
			PushFace(b, f, tt, a1, mm, qc);
			
		} break;
		
		case 2: {
			
			Vertex *tt, *a0, *a1, *m0, *m1;
			
			if (mc1 && mc2) tt = f->V0, m0 = &f->E1->M, m1 = &f->E2->M, a0 = f->V2, a1 = f->V1;
			else if (mc2 && mc0) tt = f->V1, m0 = &f->E2->M, m1 = &f->E0->M, a0 = f->V0, a1 = f->V2;
			else tt = f->V2, m0 = &f->E0->M, m1 = &f->E1->M, a0 = f->V1, a1 = f->V0;
			
			PushVertex(b, tt);
			PushVertex(b, a0);
			PushVertex(b, a1);
			PushVertex(b, m0);
			PushVertex(b, m1);
			
			PushFace(b, f, tt, m1, m0, qc);
			PushFace(b, f, a0, m0, m1, qc);
			PushFace(b, f, a1, a0, m1, qc);
			
		} break;
		
		case 3: {
			
			SubFace(h, f);
			
			if (f->Stuffed && Eye.Qixoom * f->Bounqs / qc > P2(16))
			{
				MakeStuff(f);
				
				for each (Face, t, f->Stuff->Fx, f->Stuff->Fs)
				{
					RenderFace(b, f->Stuff, t, qlose * 0.01);
				}
			}
			
			qlose *= 0.25;
			
			RenderFace(b, h, &f->Sub[0], qlose);
			RenderFace(b, h, &f->Sub[1], qlose);
			RenderFace(b, h, &f->Sub[2], qlose);
			RenderFace(b, h, &f->Sub[3], qlose);
			
			if (Eye.Photo) ClearFace(f);
			
		} break;
	}
}
