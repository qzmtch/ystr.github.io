#define LINGALDENSITY 0.0000023
#define GALSPERCUBE 100
#define CUBESIZE GALSPERCUBE / LINGALDENSITY
#define HALFCUBE CUBESIZE / 2

#define EXTENT 1
#define SIDE (EXTENT * 2 + 1)
#define CUBES P3(SIDE)
#define CENTRAL ((CUBES - 1) / 2)




typedef struct { s32 X, Y, Z; } Co3;
typedef struct { s32 X0, X1, Y0, Y1, Z0, Z1; } Box;




typedef struct {
	
	Co3 Location;
	
	struct Galaxy* Galaxy;
	u32 Galaxies;
	
	Loc Pov;
	
} Cube;

struct {
	
	struct {
		
		Box Bounds;
		Cube** Home, **Swap;
		
		Co3 Global;
		Loc Local;
		Rot Turn;
		
	} Pov;
	
} Space;



#include "Galaxy.c"



Cube* NewCube (s32 x, s32 y, s32 z)
{
	Cube* c = new(Cube);
	c->Location = (Co3) { x, y, z };
	
	Seed s = SEED (u32) ((c->Location.X << 20) + (c->Location.Y << 10) + c->Location.Z);
	
	c->Galaxies = 1 + R8(&s) % (GALSPERCUBE - 1);
	c->Galaxy = new(Galaxy, c->Galaxies);
	
	for each (Galaxy, g, c->Galaxy, c->Galaxies)
	{
		g->Seed = RS(&s);
		g->Center = (Loc) { RFF(&s) * HALFCUBE, RFF(&s) * HALFCUBE, RFF(&s) * HALFCUBE };
		g->Pov.Point = &c->Pov;
		MakeGalaxy(g);
	}
	
	return c;
}

void ZapCube (Cube* c)
{
	if (c->Galaxy)
	{
		for each (Galaxy, g, c->Galaxy, c->Galaxies) ClearGalaxy(g);
		zap(c->Galaxy);
	}
	
	zap(c);
}


Box Extend (Co3* origin, u32 ext)
{
	return (Box)
	{
		origin->X - ext, origin->X + ext,
		origin->Y - ext, origin->Y + ext,
		origin->Z - ext, origin->Z + ext
	};
}

void Position (s32 x, s32 y, s32 z)
{
	Space.Pov.Global.X = x;
	Space.Pov.Global.Y = y;
	Space.Pov.Global.Z = z;
	
	Space.Pov.Bounds = Extend(&Space.Pov.Global, EXTENT);
}

bool IsInside (const Co3* co, const Box* bounds)
{
	return (
		co->X >= bounds->X0 && co->X <= bounds->X1 &&
		co->Y >= bounds->Y0 && co->Y <= bounds->Y1 &&
		co->Z >= bounds->Z0 && co->Z <= bounds->Z1
	);
}


void NewSpace (s32 ox, s32 oy, s32 oz)
{
	Position(ox, oy, oz);
	
	Space.Pov.Home = new(Cube*, CUBES);
	Space.Pov.Swap = new(Cube*, CUBES);
	
	Space.Pov.Local = (Loc) { 0, 0, 0 };
	Space.Pov.Turn = (Rot) { 0, 0, 0, 1 };
	
	u32 i = 0;
	
	for (s32 x = -EXTENT; x <= EXTENT; ++x) {
		for (s32 y = -EXTENT; y <= EXTENT; ++y) {
			for (s32 z = -EXTENT; z <= EXTENT; ++z) {
				Space.Pov.Home[i++] = NewCube(ox + x, oy + y, oz + z);
			}
		}
	}
}


void Transition (s32 dx, s32 dy, s32 dz)
{
	Position (
		Space.Pov.Global.X + dx,
		Space.Pov.Global.Y + dy,
		Space.Pov.Global.Z + dz
	);
	
	Space.Pov.Local.X -= dx * CUBESIZE;
	Space.Pov.Local.Y -= dy * CUBESIZE;
	Space.Pov.Local.Z -= dz * CUBESIZE;
	
	SWAP (Cube**, Space.Pov.Home, Space.Pov.Swap);
	
	u32 i = 0;
	
	for list (Cube, c, Space.Pov.Swap, CUBES)
	{
		if (IsInside(&c->Location, &Space.Pov.Bounds)) Space.Pov.Home[i++] = c;
		else ZapCube(c);
	}
	
	Box make = Space.Pov.Bounds;
	
	if (dx < 0) make.X1 = make.X0 - dx - 1;
	else if (dx > 0) make.X0 = make.X1 - dx + 1;
	if (dy < 0) make.Y1 = make.Y0 - dy - 1;
	else if (dy > 0) make.Y0 = make.Y1 - dy + 1;
	if (dz < 0) make.Z1 = make.Z0 - dz - 1;
	else if (dz > 0) make.Z0 = make.Z1 - dz + 1;
	
	for (s32 x = make.X0; x <= make.X1; ++x) {
		for (s32 y = make.Y0; y <= make.Y1; ++y) {
			for (s32 z = make.Z0; z <= make.Z1; ++z) {
				Space.Pov.Home[i++] = NewCube(x, y, z);
			}
		}
	}
}


void RenderCube (Cube* c)
{
	c->Pov.X = Space.Pov.Local.X - (c->Location.X - Space.Pov.Global.X) * CUBESIZE;
	c->Pov.Y = Space.Pov.Local.Y - (c->Location.Y - Space.Pov.Global.Y) * CUBESIZE;
	c->Pov.Z = Space.Pov.Local.Z - (c->Location.Z - Space.Pov.Global.Z) * CUBESIZE;
	
	for each (Galaxy, g, c->Galaxy, c->Galaxies) RenderGalaxy(g);
}

void RenderSpace ()
{
	if (Space.Pov.Local.X > +HALFCUBE) Transition(+1, 0, 0);
	if (Space.Pov.Local.X < -HALFCUBE) Transition(-1, 0, 0);
	if (Space.Pov.Local.Y > +HALFCUBE) Transition(0, +1, 0);
	if (Space.Pov.Local.Y < -HALFCUBE) Transition(0, -1, 0);
	if (Space.Pov.Local.Z > +HALFCUBE) Transition(0, 0, +1);
	if (Space.Pov.Local.Z < -HALFCUBE) Transition(0, 0, -1);
	
	Galaxies.FarQlip = P2(CUBESIZE);
	flawt expo = (Eye.Boost ? 1 : Eye.Expo / MAXEXP) * Galaxies.Modifier;
	flawt spa = Eye.Boost ? 1 : 1.0 / (1.0 + Galaxies.VisibleStars / 100.0);
	Galaxies.BrightestSpot = (63 | Eye.Boost) * expo * spa;
	Galaxies.BrightestSparkle = Galaxies.BrightestSpot / 4;
	Galaxies.RealExpo = (Eye.Boost ? (1 + sqrt(Eye.Boost - 1)) : 1) * expo;
	Galaxies.FastExpo = MIN(Galaxies.RealExpo, 1) * 255;
	Galaxies.Current = 0;
	
	if (Eye.Photo && Eye.Boost)
	{
		u32 expand = Galaxies.RealExpo / 4;
		if (expand) Galaxies.FarQlip *= P2(expand);
		Box extra = Extend(&Space.Pov.Global, expand);
		
		for (s32 x = extra.X0; x <= extra.X1; ++x)
		{
			for (s32 y = extra.Y0; y <= extra.Y1; ++y)
			{
				for (s32 z = extra.Z0; z <= extra.Z1; ++z)
				{
					if (!IsInside(&(Co3){x, y, z}, &Space.Pov.Bounds))
					{
						Cube* tc = NewCube(x, y, z);
						RenderCube(tc);
						ZapCube(tc);
					}
				}
			}
		}
	}
	
	for list (Cube, c, Space.Pov.Home, CUBES)
	{
		RenderCube(c);
	}
	
	if (!Eye.Photo && Galaxies.BrightestSparkle)
	{
		for each (Pixel, c, Eye.Data, Eye.Total)
		{
			Light(c->Color, c->Back, 255);
		}
	}
	
	Galaxies.Modifier = 1;
	Galaxies.VisibleStars = 0;
	
	if (Galaxies.Current) RenderCloseGalaxy(Galaxies.Current);
}
