#include "Mesh.c"


typedef struct Body {
	
	Object* Object;
	
	bool Ready;
	Seed Seed;
	
	Rot Tilt;
	real Period;
	real Anomaly;
	
	Rot CurRotation;
	Rot InvCurRotation;
	
	Mesh* Surface;
	struct Air* Air;
	
	Buffer (Vertex*) VertexCache;
	Buffer (CachedFace) FaceCache;
	Occlusor Occlusor;
	
	struct SkyLight {
		struct SpaceLight* Outer;
		Loc Point;
		Loc Direction;
		Hdrgb Direct;
		Hdrgb Ambient;
	}* Light; u8 Lights;
	
	struct {
		Loc Normal;
		Loc Point;
		Rot Turn;
	} Pov;
	
	struct {
		real Qis;
		Face* Face;
	} Close;
	
} Body;


#include "Air.c"
#include "Face.c"


void RenderBody (Body* b)
{
	b->CurRotation = b->Tilt;
	b->Anomaly = fmod(Clock.Epoch, b->Period) / b->Period * TAU;
	Turn(&b->CurRotation, &(Rot){ 0, 0, sin(b->Anomaly), cos(b->Anomaly) });
	b->InvCurRotation = InvRot(&b->CurRotation);
	
	if (Qen(&b->Pov.Point) < 1) return;
	
	b->Pov.Normal = b->Pov.Point;
	Norm(&b->Pov.Normal, 1);
	
	for each (struct SkyLight, l, b->Light, b->Lights)
	{
		if (b->Air)
		{
			l->Direct.R = l->Outer->Color.R * b->Air->Clarity;
			l->Direct.G = l->Outer->Color.G * b->Air->Clarity;
			l->Direct.B = l->Outer->Color.B * b->Air->Clarity;
			
			l->Ambient.R = l->Outer->Color.R * b->Air->Diffuse.R * b->Air->Lucidity * 0.25;
			l->Ambient.G = l->Outer->Color.G * b->Air->Diffuse.G * b->Air->Lucidity * 0.25;
			l->Ambient.B = l->Outer->Color.B * b->Air->Diffuse.B * b->Air->Lucidity * 0.25;
		}
		else
		{
			l->Direct = l->Outer->Color;
			l->Ambient = (Hdrgb) { 0 };
		}
		
		l->Point = l->Outer->Point; Rotate(&l->Point, &b->InvCurRotation);
		l->Direction = l->Outer->Direction; Rotate(&l->Direction, &b->InvCurRotation);
	}
	
	if (b->Air) RenderAir(b);
	
	b->Close.Qis = RMAX;
	b->Close.Face = 0;
	
	#define FASTLOD Eye.Long * P2(Eye.Zoom)
	#define NICELOD P2(Eye.Long * 2 / 3 * Eye.Zoom)
	
	real qlose = b->Object->Raqius * (Eye.Photo ? NICELOD : FASTLOD);
	for each (Face, f, b->Surface->Fx, b->Surface->Fs) RenderFace(b, b->Surface, f, qlose);
	
	if (Eye.Photo) for each (Pixel, p, Eye.Data, Eye.Total) for chain (p->Special, cai) ShadeApex(b, cai->Value);
	else for list (Vertex, v, b->VertexCache.Buffer, b->VertexCache.Count) ShadeApex(b, &v->Cache.Apex);
	for each (CachedFace, f, b->FaceCache.Buffer, b->FaceCache.Count) DrawTri(&f->A0->Apex, &f->A1->Apex, &f->A2->Apex, PutFacePixel, 0);
	for list (Vertex, v, b->VertexCache.Buffer, b->VertexCache.Count) v->Cache.Done = 0;
	
	if (Eye.Photo)
	{
		ClearBuffer(b->VertexCache, Vertex*);
		ClearBuffer(b->FaceCache, CachedFace);
		
		for each (Pixel, p, Eye.Data, Eye.Total)
		{
			ForChain(p->Special, ZAP, ZAP);
			p->Special = 0;
		}
		
		for each (Face, f, b->Surface->Fx, b->Surface->Fs) ClearFace(f);
		for each (Edge, e, b->Surface->Ex, b->Surface->Es) ClearEdge(e);
	}
	
	b->VertexCache.Count = 0;
	b->FaceCache.Count = 0;
}


void CreateBody (Object* o)
{
	Body* b = o->Body;
	b->Object = o;
	Seed seq = b->Seed = o->Seed;
	
	b->Lights = o->Lights;
	b->Light = new(struct SkyLight, b->Lights);
	
	for (s32 i = 0; i < o->Lights; ++i)
	{
		b->Light[i].Outer = &o->Light[i];
	}
	
	if (o->Primary && R1(&seq)) {
		b->Period = o->Orbit->Period;
		b->Tilt = o->Primary->Body->Tilt;
	} else {
		b->Period = (0.5 + R0F(&seq) * 10) ED;
		b->Tilt = RRot(&seq);
	}
	
	b->Anomaly = Clock.Epoch / b->Period;
	
	b->Surface = new(Mesh);
	b->Surface->Seed = o->Seed;
	b->Surface->Center = (Loc){0};
	b->Surface->Color = o->Dif;
	
	switch (o->Tag)
	{
		case GAS: {
			b->Air = new(Air);
			b->Air->Density = 1;
			b->Air->Opacity = 1;
			b->Surface->StuffProb = 0;
			b->Surface->Roughness = 0;
		} break;
		
		default: {
			
			#define ATMIN (0.5 EM)
			#define ATMID (1 EM)
			#define ATMAX (10 EM)
			
			if (o->Mass > ATMIN) {
				b->Air = new(Air);
				if (o->Mass < ATMID) b->Air->Density = b->Air->Opacity = 0.2 * (o->Mass - ATMIN) / (ATMID - ATMIN);
				else if (o->Mass < ATMAX) b->Air->Density = b->Air->Opacity = 0.2 + 0.8 * (o->Mass - ATMID) / (ATMAX - ATMID);
				else b->Air->Density = b->Air->Opacity = 1;
			} else b->Air = 0;
			
			b->Surface->StuffProb = RR(&seq) % 50;
			b->Surface->StuffMax = 1 + 10 * R0F(&seq);
			b->Surface->Roughness = 0.025 + 0.05 * R0F(&seq);
			
		} break;
	}
	
	if (b->Air)
	{
		b->Air->Clarity = 1 - b->Air->Density;
		b->Air->Lucidity = 1 - b->Air->Opacity;
		
		b->Air->Color = (Hdrgb) { 0.1 + 0.9 * R0F(&seq), 0.1 + 0.9 * R0F(&seq), 1 };
		b->Air->Thickness = o->Radius * 0.01;
		
		if (b->Air->Density > 0) {
			flawt dis = b->Air->Thickness * b->Air->Clarity;
			b->Air->InvQisi = 1 / P2(dis);
		} else b->Air->InvQisi = 0;
		
		b->Air->Overglow = b->Air->Thickness / o->Radius * b->Air->Density;
		
		b->Air->RcGround = 1.0 / o->Radius;
		b->Air->Top = o->Radius + b->Air->Thickness;
		b->Air->BottomLimit = o->Radius / 2;
		
		b->Air->Diffuse.R = b->Air->Color.R * b->Air->Density;
		b->Air->Diffuse.G = b->Air->Color.G * b->Air->Density;
		b->Air->Diffuse.B = b->Air->Color.B * b->Air->Density;
		
		b->Air->Tangent.R = b->Air->Diffuse.R * 32; if (b->Air->Tangent.R > 1) b->Air->Tangent.R = 1;
		b->Air->Tangent.G = b->Air->Diffuse.G * 32; if (b->Air->Tangent.G > 1) b->Air->Tangent.G = 1;
		b->Air->Tangent.B = b->Air->Diffuse.B * 32; if (b->Air->Tangent.B > 1) b->Air->Tangent.B = 1;
	}
	
	if (o->Tag == GAS) b->Surface->Map = 0;
	else
	{
		b->Surface->Map = new(Map);
		b->Surface->Map->Craters = RR(&seq) % 9000;
		b->Surface->Map->Crater = new(Crater, b->Surface->Map->Craters);
		
		real maxr = o->Radius * 0.05;
		if (maxr > 888 KM) maxr = 888 KM;
		
		real minr = 10;
		if (minr > maxr) minr = maxr / 10;
		
		for each (Crater, c, b->Surface->Map->Crater, b->Surface->Map->Craters)
		{
			c->Center = Sphrout(o->Radius, &seq);
			Translate(&c->Center, &b->Surface->Center);
			
			c->Radius = minr + maxr * P3(R0F(&seq));
			c->Outer = c->Radius * (1.1 + 0.1 * R0F(&seq));
			
			c->Depth = c->Radius * 0.1 * R0F(&seq);
			c->Height = c->Depth * 0.5 * R0F(&seq);
		}
		
		CacheMap(b->Surface->Map, 16, o->Radius / 15);
	}
	
	Ico(&seq, b->Surface, o->Radius);
	
	NewBuffer(b->VertexCache, Vertex*);
	NewBuffer(b->FaceCache, CachedFace);
	
	b->Ready = 1;
}

void NewBody (Object* o)
{
	o->Body = new(Body);
	o->Body->Ready = 0;
	if (Eye.Photo) CreateBody(o);
	else Spawn((Handler)CreateBody, o);
}


void zapBody (Body* b)
{
	ZapMesh(b->Surface);
	zap(b->VertexCache.Buffer);
	zap(b->FaceCache.Buffer);
	zap(b);
}

void ZapBody (Object* o)
{
	Body* b = o->Body;
	o->Body = 0;
	Spawn((Handler)zapBody, b);
}
