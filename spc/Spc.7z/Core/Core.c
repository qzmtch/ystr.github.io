void NOP (void* p) { }
void ZAP (void* p) { zap(p); }

typedef void (*Handler) (void* o);

#define SWAP(T,V0,V1) { T swap_ = V0; V0 = V1; V1 = swap_; }

#include "Math.c"
#include "Random.c"
#include "Lists.c"
#include "Kepler.c"
#include "Units.c"
