#define PIE 3.141592653589793238462643
#define TAU 6.283185307179586476925287

#define P2(V) ((V)*(V))
#define P3(V) ((V)*(V)*(V))
#define P4(V) ((V)*(V)*(V)*(V))
#define P5(V) ((V)*(V)*(V)*(V)*(V))

#define ROUND(F) ((F)>=0 ? ((F)+.5) : ((F)-.5))
#define CEIL(F) ceil(F)

#define MAX(A,B) ((A) > (B) ? (A) : (B))
#define MIN(A,B) ((A) < (B) ? (A) : (B))

real Max2 (real a, real b) { return MAX(a,b); }
real Max3 (real a, real b, real c) { return Max2(MAX(a, b), MAX(b, c)); }

typedef struct { real X, Y, Z; } Loc;
typedef struct { real X, Y, Z, W; } Rot;

Loc InvLoc (Loc* l) { return (Loc) { -l->X, -l->Y, -l->Z }; }
Rot InvRot (Rot* r) { return (Rot) { -r->X, -r->Y, -r->Z, r->W };  }

real Len (const Loc* l) { return sqrt(l->X*l->X + l->Y*l->Y + l->Z*l->Z); }
real Dis (const Loc* l1, const Loc* l2) { real x=l1->X-l2->X, y=l1->Y-l2->Y, z=l1->Z-l2->Z; return sqrt(x*x+y*y+z*z); }
real Qen (const Loc* l) { return l->X*l->X + l->Y*l->Y + l->Z*l->Z; }
real Qis (const Loc* l1, const Loc* l2) { real x=l1->X-l2->X, y=l1->Y-l2->Y, z=l1->Z-l2->Z; return x*x+y*y+z*z; }

bool EqLoc (const Loc* l0, const Loc* l1) { return l0->X == l1->X && l0->Y == l1->Y && l0->Z == l1->Z; }
Loc MeanLoc (const Loc* l0, const Loc* l1) { return (Loc){(l0->X+l1->X)*.5,(l0->Y+l1->Y)*.5,(l0->Z+l1->Z)*.5}; }

real Dot (Loc* l0, Loc* l1) { return l0->X * l1->X + l0->Y * l1->Y + l0->Z * l1->Z; }
Loc Cross (Loc* l0, Loc* l1) { return (Loc) { l0->Y*l1->Z-l0->Z*l1->Y,l0->Z*l1->X-l0->X*l1->Z,l0->X*l1->Y-l0->Y*l1->X }; }

Loc Add (const Loc* l0, const Loc* l1) { return (Loc) { l0->X+l1->X, l0->Y+l1->Y, l0->Z+l1->Z }; }
Loc Sub (const Loc* l0, const Loc* l1) { return (Loc) { l0->X-l1->X, l0->Y-l1->Y, l0->Z-l1->Z }; }
Loc Mul (const Loc* l, real m) { return (Loc) { l->X * m, l->Y * m, l->Z * m }; }

void Renorm (Loc* l, real from, real to) { to /= from; l->X *= to; l->Y *= to; l->Z *= to; }
void Rcnorm (Loc* l, real from, real to) { to *= from; l->X *= to; l->Y *= to; l->Z *= to; }

void Norm (Loc* l, real to) { Renorm(l, Len(l), to); }

void NizeRot (Rot* r)
{
	real lr = 1.0 / sqrt(r->X*r->X + r->Y*r->Y + r->Z*r->Z + r->W*r->W);
	r->X *= lr; r->Y *= lr; r->Z *= lr; r->W *= lr;
}

Loc TriNormal (Loc* a0, Loc* a1, Loc* a2)
{
	Loc x10 = Sub(a1, a0), x20 = Sub(a2, a0);
	Loc n = Cross(&x20, &x10); Norm(&n, 1);
	return n;
}

void Translate (Loc* l, const Loc* by)
{
	l->X += by->X;
	l->Y += by->Y;
	l->Z += by->Z;
}

void Turn (Rot* r, const Rot* by)
{
	Rot o = *r;
	
	r->X = o.W * by->X + o.X * by->W + o.Y * by->Z - o.Z * by->Y;
	r->Y = o.W * by->Y + o.Y * by->W + o.Z * by->X - o.X * by->Z;
	r->Z = o.W * by->Z + o.Z * by->W + o.X * by->Y - o.Y * by->X;
	r->W = o.W * by->W - o.X * by->X - o.Y * by->Y - o.Z * by->Z;
}

void Rotate (Loc* l, const Rot* by)
{
	real x = l->X * by->W + l->Y * -by->Z - l->Z * -by->Y;
	real y = l->Y * by->W + l->Z * -by->X - l->X * -by->Z;
	real z = l->Z * by->W + l->X * -by->Y - l->Y * -by->X;
	real w = l->X * by->X - l->Y * -by->Y - l->Z * -by->Z;
	
	l->X = by->W * x + by->X * w + by->Y * z - by->Z * y;
	l->Y = by->W * y + by->Y * w + by->Z * x - by->X * z;
	l->Z = by->W * z + by->Z * w + by->X * y - by->Y * x;
}

Loc Project (const Loc* l, const Loc* p, const Rot* r)
{
	Loc o = { l->X - p->X, l->Y - p->Y, l->Z - p->Z };
	
	real x = o.X * +r->W + o.Y * r->Z - o.Z * r->Y;
	real y = o.Y * +r->W + o.Z * r->X - o.X * r->Z;
	real z = o.Z * +r->W + o.X * r->Y - o.Y * r->X;
	real w = o.X * -r->X - o.Y * r->Y - o.Z * r->Z;
	
	o.X = r->W * x - r->X * w - r->Y * z + r->Z * y;
	o.Y = r->W * y - r->Y * w - r->Z * x + r->X * z;
	o.Z = r->W * z - r->Z * w - r->X * y + r->Y * x;
	
	return o;
}
