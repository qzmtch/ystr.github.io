#define each(TYPE, VAR, HEAP, COUNT) ( \
	TYPE* VAR = (TYPE*) HEAP, *VAR##_ = (TYPE*) HEAP + (u32)(COUNT); \
	VAR < VAR##_; ++VAR \
)

#define list(TYPE, VAR, LIST, COUNT) ( \
	TYPE* VAR = *LIST, **VAR##_ = LIST, **VAR##__ = LIST + (u32)(COUNT); \
	VAR##_ < VAR##__; ++VAR##_, VAR = *VAR##_ \
)



#define Chain(T) ChainItem*
#define chain(L, I) (ChainItem* I = L; I; I = I->Next)

typedef struct ChainItem {
	void* Value;
	struct ChainItem* Next;
} ChainItem;

void* Append (Chain(T)* node, void* value)
{
	ChainItem* add = new(ChainItem);
	add->Next = *node; *node = add;
	return add->Value = value;
}

void ForChain (Chain(T) c, Handler valueHandler, Handler itemHandler)
{
	while (c)
	{
		ChainItem* next = c->Next;
		valueHandler(c->Value);
		itemHandler(c);
		c = next;
	}
}



#define Tree(T) TreeNode*

typedef struct TreeNode {
	void* Value;
	struct TreeNode* Prev, *Next;
} TreeNode;

typedef bool (*Comparer) (void* prev, void* next);
void Insert (Tree(T)* branch, void* add, Comparer com)
{
	if (*branch) {
		if (com(add, (*branch)->Value)) branch = &((*branch)->Next);
		else branch = &((*branch)->Prev);
		Insert(branch, add, com);
	} else {
		*branch = new(TreeNode);
		**branch = (TreeNode) { .Value = add };
	}
}

void ForTree (Tree(T) branch, Handler doValue, Handler doNode)
{
	if (!branch) return;
	ForTree(branch->Prev, doValue, doNode);
	doValue(branch->Value);
	ForTree(branch->Next, doValue, doNode);
	doNode(branch);
}



#define Buffer(T) struct { u32 Count; u32 Capacity; T* Buffer; }
#define NewBuffer(B, T) { B.Count = 0; B.Capacity = 1; B.Buffer = new(T); }
#define Bufferize(B, T) { if (B.Count == B.Capacity)B.Buffer = renew(B.Buffer, T, B.Capacity *= 2); }
#define ClearBuffer(B, T) { zap(B.Buffer); NewBuffer(B, T); }
