#define SL * 3.846E28 // Solar Luminosity (W)

#define ED * 86400.0 // Earth Day (s)

#define MM * 0.0001 // Millimeter (m)
#define KM * 1000.0 // Kilometer (m)
#define ER * 6353.0 KM // Earth Radius
#define SR * 695500.0 KM // Solar Radius
#define AU * 149597870.7 KM // Astronomical Unit
#define PC * 30841981340613.4 KM // Parsec

#define EM * 5.97219E24 // Earth Mass (kg)
#define SM * 1.98855E30 // Solar Mass (kg)
