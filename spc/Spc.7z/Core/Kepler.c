typedef struct Kepler {
	
	Loc* Focus;
	
	real SemiMajor;
	flawt Eccentricity;
	flawt Inclination;
	flawt Longitude;
	flawt Argument;
	
	flawt Initial;
	flawt Period;
	flawt Anomaly;
	
} Kepler;

Loc Where (Kepler* k, flawt tra)
{
	flawt cosl = cos(k->Longitude);
	flawt cosi = cos(k->Inclination);
	flawt sinl = sin(k->Longitude);
	flawt cosaa = cos(k->Argument + tra);
	flawt sinaa = sin(k->Argument + tra);
	
	real r = (
		(k->SemiMajor * (1 - P2(k->Eccentricity)))
		/ (1 + k->Eccentricity * cos(tra))
	);
	
	return (Loc)
	{
		r * (cosl * cosaa - sinl * sinaa * cosi),
		r * (sinl * cosaa + cosl * sinaa * cosi),
		r * (sin(k->Inclination) * sinaa)
	};
}

flawt Mea2Ecc (Kepler* k, flawt mea, flawt guess)
{
	flawt delta = guess - mea - k->Eccentricity * sin(guess);
	if (fabs(delta) > 0.01) return Mea2Ecc(k, mea, guess - delta / (1 - k->Eccentricity * cos(guess)));
	else return guess;
}

flawt Mea2Tru (Kepler* k, flawt mea)
{
	flawt eca = Mea2Ecc(k, mea, mea);
	return 2 * atan2(sqrt(1 + k->Eccentricity) * sin(eca / 2), sqrt(1 - k->Eccentricity) * cos(eca / 2));
}

Loc Revolve (Kepler* k)
{
	k->Anomaly = k->Initial + fmod(Clock.Epoch, k->Period) / k->Period * TAU;
	Loc w = Where(k, Mea2Tru(k, k->Anomaly));
	return Add(k->Focus, &w);
}

flawt GetPeriod (real semiMajor, flawt mass)
{
	#define GEE 0.0000000000667384
	return sqrt(P2(TAU) / (GEE * mass) * P3(semiMajor));
}
