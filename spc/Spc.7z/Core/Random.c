typedef u32 Seed;

Seed UnsafeSeq = 1;


u16  RR  (Seed* s) { return (*s = *s * 1103515245 + 12345) / U16MAX; }
bool R1  (Seed* s) { return RR(s) & 1; }
u8   R8  (Seed* s) { return RR(s) % (U8MAX  + 1); }
u16  R16 (Seed* s) { return RR(s) % (U16MAX + 1); }
u32  R32 (Seed* s) { return (R16(s) << 16) + R16(s); }

#define R0F(s) ((1.0 / U32MAX) * (u32)R32(s))
#define RFF(s) ((1.0 / S32MAX) * (s32)R32(s))

#define RS(s) R32(s)
#define SEED(T) SEED##T
#define SEEDu32(S) (u32)(S)


Loc Sphrout (real radius, Seed* seq)
{
	real z = RFF(seq) * radius, ph = RFF(seq) * TAU;
	real th = asin(z / radius), cth = cos(th);
	return (Loc) { cth * cos(ph) * radius, cth * sin(ph) * radius, z };
}

Rot RRot (Seed* seq)
{
	flawt rr = R0F(seq), sp = sqrt(rr), sn = sqrt(1 - rr);
	flawt r1 = R0F(seq) * TAU, r2 = R0F(seq) * TAU;
	return (Rot) { sn * sin(r1), sn * cos(r1), sp * sin(r2), sp * cos(r2) };
}
