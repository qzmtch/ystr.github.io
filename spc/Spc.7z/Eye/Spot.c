Sprite* Spot;

void PrepareSpot ()
{
	Spot = NewSprite(512);
	
	for (u16 y = 0; y < Spot->Size; ++y)
	{
		for (u16 x = 0; x < Spot->Size; ++x)
		{
			u8* pixel = &Spot->Data[y * Spot->Size + x];
			flawt dx = x - Spot->Radius, dy = y - Spot->Radius;
			if (dx < 0) dx += 0.5; else if (dx > 0) dx -= 0.5;
			if (dy < 0) dy += 0.5; else if (dy > 0) dy -= 0.5;
			flawt a = 1 - sqrt(dx * dx + dy * dy) / Spot->Radius;
			*pixel = a > 0 ? P2(a) * 255 : 0;
		}
	}
}

typedef struct { Rgb* Color; u8 Alpha; } SpotPixelArgs;
void LightSpotPixel (s16 x, s16 y, u8 spra, SpotPixelArgs* args)
{
	Light(Eye.YX[y][x].Color, args->Color, (spra * args->Alpha) >> 8);
}

void LightSpot (Sprect* scr, Rgb* color, u8 a)
{
	DrawSprite
	(
		Spot, scr, (SpritePixelDrawer) LightSpotPixel,
		&(SpotPixelArgs){ .Color = color, .Alpha = a }
	);
}
