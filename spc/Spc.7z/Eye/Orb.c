Sprite* Orb;
#define ORBBLUR 0.1

void PrepareOrb ()
{
	Orb = NewSprite(512);
	
	for (u16 y = 0; y < Orb->Size; ++y)
	{
		for (u16 x = 0; x < Orb->Size; ++x)
		{
			flawt ax = 1.0 / Orb->Size * x - 0.5, ay = 1.0 / Orb->Size * y - 0.5;
			flawt a = 1 - (sqrt(ax * ax + ay * ay) * 2 - (1 - ORBBLUR)) * (1 / ORBBLUR);
			Orb->Data[y * Orb->Size + x] = a > 1 ? 255 : (a <= 0 ? 0 : 255 * a);
		}
	}
}

typedef struct { Rgb* Color; flawt Z; } OrbPixelArgs;
void DrawOrbPixel (s16 x, s16 y, u8 spra, OrbPixelArgs* args)
{
	if (spra == 255)
	{
		Pixel* pi = &Eye.YX[y][x];
		*pi->Color = *args->Color;
		pi->Z = args->Z;
	}
	else Light(Eye.YX[y][x].Color, args->Color, spra);
}

bool DrawOrb (s32 x, s32 y, u16 radius, flawt z, Rgb* color)
{
	Sprect r;
	if (!TrySprect(x, y, radius * (1 + ORBBLUR), &r)) return 0;
	
	DrawSprite
	(
		Orb, &r,
		(SpritePixelDrawer) DrawOrbPixel,
		&(OrbPixelArgs){ .Color = color, .Z = z }
	);
	
	return 1;
}
