void DrawStar (s16 x, s16 y, const Rgb* color, u8 cc)
{
	Pixel* pi = &Eye.YX[y][x];
	
	Light(pi->Color, color, cc);
	Rgb* nc = pi->Color;
	
	pi -= Eye.Xs + 1;
	
	u8 sc = cc / 3;
	u8 dc = cc / 6;
	
	Light((pi++)->Color, nc, dc); Light((pi++)->Color, nc, sc); Light((pi)->Color, nc, dc);
	pi += Eye.Xs; Light((pi--)->Color, nc, sc); Light((--pi)->Color, nc, sc); pi += Eye.Xs;
	Light((pi++)->Color, nc, dc); Light((pi++)->Color, nc, sc); Light((pi)->Color, nc, dc);
}
