typedef struct {
	u16 Size;
	u16 Radius;
	u8 Data[];
} Sprite;

Sprite* NewSprite (u16 size)
{
	Sprite* s = new(Sprite, 1, size * size);
	s->Size = size; s->Radius = size / 2;
	return s;
}


typedef struct {
	u32 Radius;
	s32 X0, X1, Y0, Y1;
} Sprect;

Sprect PutSprect (s32 x, s32 y, u32 r)
{
	return (Sprect)
	{
		.Radius = r,
		.X0 = x - r, .X1 = x + r,
		.Y0 = y - r, .Y1 = y + r
	};
}

bool TrySprect (s32 x, s32 y, u32 r, Sprect* rect)
{
	rect->X0 = x - r; if (rect->X0 > Eye.XP) return 0;
	rect->X1 = x + r; if (rect->X1 < Eye.X0) return 0;
	rect->Y0 = y - r; if (rect->Y0 > Eye.YP) return 0;
	rect->Y1 = y + r; if (rect->Y1 < Eye.Y0) return 0;
	
	rect->Radius = r;
	
	return 1;
}


typedef void (*SpritePixelDrawer) (s16 x, s16 y, u8 spra, void* args);
void DrawSprite (Sprite* s, Sprect* r, SpritePixelDrawer drawPixel, void* args)
{
	flawt sx = 0, sy = 0;
	flawt plus = (flawt) s->Radius / r->Radius;
	
	for (s32 yy = r->Y0; yy < r->Y1; ++yy)
	{
		s32 syi = (s32)sy * s->Size;
		
		if (yy <= Eye.YP && yy >= Eye.Y0)
		{
			for (s32 xx = r->X0; xx < r->X1; ++xx)
			{
				if (xx <= Eye.XP && xx >= Eye.X0)
				{
					drawPixel(xx, yy, s->Data[syi + (s32)sx], args);
				}
				
				sx += plus;
			}
			
			sx = 0;
		}
		
		sy += plus;
	}
}
