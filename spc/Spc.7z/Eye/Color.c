typedef struct { flawt R, G, B; } Hdrgb;
#define HDR * (1.0 / 255.0)

Hdrgb ClampHd255 (Hdrgb* c)
{
	return (Hdrgb)
	{
		c->R < 1 ? (255.0 * c->R) : 255.0,
		c->G < 1 ? (255.0 * c->G) : 255.0,
		c->B < 1 ? (255.0 * c->B) : 255.0
	};
}

Rgb Clamp (Hdrgb* c)
{
	return RGB
	(
		c->R < 1 ? (u8) (255 * c->R) : 255,
		c->G < 1 ? (u8) (255 * c->G) : 255,
		c->B < 1 ? (u8) (255 * c->B) : 255
	);
}

void Light (Rgb* c, const Rgb* by, u8 a)
{
	u16 r = c->R + by->R * a / 255; c->R = r < 255 ? r : 255;
	u16 g = c->G + by->G * a / 255; c->G = g < 255 ? g : 255;
	u16 b = c->B + by->B * a / 255; c->B = b < 255 ? b : 255;
}

void Blend (Rgb* c, u8 clarity, const Rgb* by)
{
	u16 r = c->R * clarity / 255 + by->R; c->R = r < 255 ? r : 255;
	u16 g = c->G * clarity / 255 + by->G; c->G = g < 255 ? g : 255;
	u16 b = c->B * clarity / 255 + by->B; c->B = b < 255 ? b : 255;
}
