typedef void (PixelShader) (Pixel* p, flawt r, flawt g, flawt b, flawt z, void* args);


typedef struct Apex { flawt X, Y, Z; Hdrgb Color; } Apex;
typedef struct Pass { flawt X, R, G, B, Z; } Pass;


void DrawRow (int y, const Pass* v0, const Pass* v1, PixelShader* shade, void* shargs)
{
	if (v0->X > v1->X) SWAP (const Pass*, v0, v1);
	
	int x0 = CEIL(v0->X); if (x0 < Eye.X0) x0 = Eye.X0;
	int x1 = CEIL(v1->X); if (x1 > Eye.X1) x1 = Eye.X1;
	
	flawt xx = 1.0 / (v1->X - v0->X);
	flawt skip = x0 - v0->X;
	
	flawt rr = rr = (v1->R - v0->R) * xx;
	flawt gg = (v1->G - v0->G) * xx;
	flawt bb = (v1->B - v0->B) * xx;
	flawt zz = (v1->Z - v0->Z) * xx;
	
	flawt r = v0->R + skip * rr;
	flawt g = v0->G + skip * gg;
	flawt b = v0->B + skip * bb;
	flawt z = v0->Z + skip * zz;
	
	for (Pixel *row = Eye.YX[y], *p = row + x0, *p_ = row + x1; p < p_; ++p)
	{
		shade(p, r, g, b, z, shargs);
		
		r += rr;
		g += gg;
		b += bb;
		z += zz;
	}
}


void PlotLine (const Apex* a0, const Apex* a1, Pass* tgt)
{
	int y0 = CEIL(a0->Y); if (y0 < Eye.Y0) y0 = Eye.Y0;
	int y1 = CEIL(a1->Y); if (y1 > Eye.Y1) y1 = Eye.Y1;
	
	flawt yy = 1.0 / (a1->Y - a0->Y);
	flawt skip = y0 - a0->Y;
	
	flawt xx = (a1->X - a0->X) * yy;
	flawt zz = (a1->Z - a0->Z) * yy;
	flawt rr = (a1->Color.R - a0->Color.R) * yy;
	flawt gg = (a1->Color.G - a0->Color.G) * yy;
	flawt bb = (a1->Color.B - a0->Color.B) * yy;
	
	flawt x = a0->X + skip * xx;
	flawt z = a0->Z + skip * zz;
	flawt r = a0->Color.R + skip * rr;
	flawt g = a0->Color.G + skip * gg;
	flawt b = a0->Color.B + skip * bb;
	
	for (Pass* p = tgt + y0, *p_ = tgt + y1; p < p_; ++p)
	{
		p->X = x; x += xx;
		p->Z = z; z += zz;
		p->R = r; r += rr;
		p->G = g; g += gg;
		p->B = b; b += bb;
	}
}


void DrawTri (
	const Apex* a0, const Apex* a1, const Apex* a2,
	PixelShader* shade, void* shargs
) {
	if (a1->X > a2->X) SWAP (const Apex*, a1, a2);
	if (a0->X > a1->X) SWAP (const Apex*, a0, a1); if (a0->X > Eye.X1) return;
	if (a1->X > a2->X) SWAP (const Apex*, a1, a2); if (a2->X < Eye.X0) return;
	if (a1->Y > a2->Y) SWAP (const Apex*, a1, a2);
	if (a0->Y > a1->Y) SWAP (const Apex*, a0, a1); if (a0->Y > Eye.Y1) return;
	if (a1->Y > a2->Y) SWAP (const Apex*, a1, a2); if (a2->Y < Eye.Y0) return;
	
	int y0 = CEIL(a0->Y);
	int y1 = CEIL(a1->Y);
	int y2 = CEIL(a2->Y);
	
	if (y0 != y2) PlotLine(a0, a2, Eye.L0); else return;
	if (y0 != y1) PlotLine(a0, a1, Eye.L1);
	if (y1 != y2) PlotLine(a1, a2, Eye.L1);
	
	if (y0 < Eye.Y0) y0 = Eye.Y0;
	if (y2 > Eye.Y1) y2 = Eye.Y1;
	
	for (int y = y0; y < y2; y++)
	{
		DrawRow(y, &Eye.L0[y], &Eye.L1[y], shade, shargs);
	}
}
