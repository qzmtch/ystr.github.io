#define EYERES 512
#define MAXEXP 1000
#define MAXDIM 1




typedef struct {
	
	flawt Z;
	
	Rgb* Color;
	Rgb* Back;
	
	void* Special;
	
} Pixel;




struct Eye {
	
	bool Photo;
	
	flawt Ratio;
	
	u16 FastSize;
	u16 FullSize;
	
	u16 Xs, Ys; u32 Total;
	s16 X0, Y0, XP, YP, X1, Y1;
	u16 Short, Long;
	
	flawt Zoom, Qoom;
	flawt Pixoom, Qixoom;
	
	Pixel* Data;
	Pixel** YX, **YX0;
	
	struct Pass *L0, *L00;
	struct Pass *L1, *L10;
	
	struct {
		Rgb* Data;
		u16 Xs, Ys;
		u32 Total;
	} Back;
	
	u8 Boost;
	flawt Opti;
	flawt Expo;
	
	Chain (Glare) Glare;
	
} Eye = {
	
	.Ratio = 1,
	
	.FastSize = EYERES,
	.FullSize = EYERES,
	
	.Xs = EYERES,
	.Ys = EYERES,
	
	.Opti = 0.1,
	.Expo = MAXEXP,
	.Zoom = 1
};




#include "Color.c"
#include "Sprite.c"
#include "Spot.c"
#include "Star.c"
#include "Tristerizer.c"
#include "Orb.c"
#include "Glare.c"




void AttachBitmap ();




void UpFov ()
{
	Eye.Qoom = P2(Eye.Zoom);
	Eye.Pixoom = -(Eye.Zoom * Eye.Long);
	Eye.Qixoom = P2(Eye.Pixoom);
}

void UpEye ()
{
	zap(Eye.Data);
	zap(Eye.YX0);
	
	u16 max = Eye.Photo ? Eye.FullSize : Eye.FastSize;
	if (Eye.Ratio > 1) { Eye.Xs = max; Eye.Ys = max / Eye.Ratio; }
	else { Eye.Xs = max * Eye.Ratio; Eye.Ys = max; }
	
	Eye.Total = Eye.Xs * Eye.Ys;
	
	Eye.X1 = Eye.Xs / 2;
	Eye.Y1 = Eye.Ys / 2;
	
	Eye.X0 = Eye.X1 - Eye.Xs;
	Eye.Y0 = Eye.Y1 - Eye.Ys;
	
	Eye.XP = Eye.X1 - 1;
	Eye.YP = Eye.Y1 - 1;
	
	Eye.Data = new(Pixel, Eye.Total);
	
	Eye.YX0 = new(Pixel*, Eye.Ys);
	for (s32 i = 0; i < Eye.Ys; ++i) { Eye.YX0[i] = Eye.Data + i * Eye.Xs - Eye.X0; }
	Eye.YX = Eye.YX0 - Eye.Y0;
	
	if (Eye.Xs > Eye.Ys) { Eye.Long = Eye.XP; Eye.Short = Eye.YP; }
	else { Eye.Long = Eye.YP; Eye.Short = Eye.XP; }
	
	Eye.Back.Xs = Eye.Xs / 4;
	Eye.Back.Ys = Eye.Ys / 4;
	Eye.Back.Total = Eye.Back.Xs * Eye.Back.Ys;
	
	zap(Eye.Back.Data);
	Eye.Back.Data = new(Rgb, Eye.Back.Xs * Eye.Back.Ys);
	
	flawt xp = (flawt) Eye.Back.Xs / Eye.Xs;
	flawt yp = (flawt) Eye.Back.Ys / Eye.Ys;
	
	flawt xr = (flawt) Eye.Xs / Eye.Back.Xs / 4;
	flawt yr = (flawt) Eye.Ys / Eye.Back.Ys / 4;
	
	flawt yy = 0;
	
	for (s32 y = Eye.Y0; y <= Eye.YP; ++y)
	{
		flawt xx = 0;
		
		for (s32 x = Eye.X0; x <= Eye.XP; ++x)
		{
			s32 xxx = xx + RFF(&UnsafeSeq) * xr;
			s32 yyy = yy + RFF(&UnsafeSeq) * yr;
			
			if (xxx < 0) xxx = 0; else if (xxx >= Eye.Back.Xs) xxx = Eye.Back.Xs - 1;
			if (yyy < 0) yyy = 0; else if (yyy >= Eye.Back.Ys) yyy = Eye.Back.Ys - 1;
			
			Eye.YX[y][x].Back = &Eye.Back.Data[yyy * Eye.Back.Xs + xxx];
			xx += xp;
		}
		
		yy += yp;
	}
	
	zap(Eye.L00); Eye.L00 = new(Pass, Eye.Ys), Eye.L0 = Eye.L00 - Eye.Y0;
	zap(Eye.L10); Eye.L10 = new(Pass, Eye.Ys), Eye.L1 = Eye.L10 - Eye.Y0;
	
	AttachBitmap();
	UpFov();
}




void ClearEye ()
{
	for each (Rgb, c, Eye.Back.Data, Eye.Back.Total)
	{
		*c = (Rgb){0};
	}
	
	for each (Pixel, p, Eye.Data, Eye.Total)
	{
		*p->Color = (Rgb){0};
		p->Special = 0;
		p->Z = -FMAX;
	}
	
	Eye.Glare = 0;
}

void PostEye ()
{
	ForChain(Eye.Glare, (Handler)DoGlare, ZAP);
	
	u32 total = 0;
	
	for each (Pixel, p, Eye.Data, Eye.Total) total += p->Color->R + p->Color->G + p->Color->B;
	flawt meter = (flawt) total / Eye.Total / 3 / 255;
	
	if (meter < Eye.Opti) Eye.Expo *= 1 + Clock.Factor * ((Eye.Opti - meter) / Eye.Opti) * 6;
	if (meter > Eye.Opti) Eye.Expo /= 1 + Clock.Factor * ((meter - Eye.Opti) / Eye.Opti) * 6;
	
	if (Eye.Expo > MAXEXP) Eye.Expo = MAXEXP;
}
