typedef struct {
	s16 X, Y;
	flawt Radius;
	flawt Z;
	Rgb Color;
	flawt Lumi;
	flawt Alpha;
} Glare;

void DrawGlare (
	s16 x, s16 y, u16 inner, u16 outer, u16 steps,
	Rgb* color, flawt alpha
) {
	if (inner >= outer) return;
	flawt step = (flawt) (outer - inner) / steps; u8 a = (alpha / (steps / 2)) * 255;
	for (flawt r = inner + step; r <= outer; r += step)
	{
		Sprect sp = PutSprect(x, y, r);
		LightSpot(&sp, color, a);
	}
}

void DoGlare (Glare* g)
{
	Pixel* cr = &Eye.YX[g->Y][g->X];
	if (cr->Z > g->Z) goto Cleanup;
	
	flawt bri = g->Lumi * Eye.Expo * 2;
	if (bri > 16) bri = 16;
	
	u32 r1 = g->Radius + (g->Radius < 1 ? g->Radius : 1) * Eye.Long * bri;
	if (r1 > Eye.Long) r1 = Eye.Long;
	
	u32 r2 = g->Radius + g->Radius * 16 * bri + 2;
	if (r2 > Eye.Long) r2 = Eye.Long;
	
	if (Eye.Photo) {
		DrawGlare(g->X, g->Y, g->Radius, r1, 32, &g->Color, g->Alpha);
		DrawGlare(g->X, g->Y, g->Radius, r2, 16, &g->Color, g->Alpha);
	} else {
		Sprect sp1 = PutSprect(g->X, g->Y, r1);
		Sprect sp2 = PutSprect(g->X, g->Y, r2);
		LightSpot(&sp1, &g->Color, g->Alpha * 255);
		LightSpot(&sp2, &g->Color, g->Alpha * 255);
	}
	
	Cleanup: zap(g);
}
