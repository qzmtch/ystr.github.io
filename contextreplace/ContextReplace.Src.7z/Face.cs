using System;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

class Face : Form
{
	TextBox oldField;
	TextBox newField;
	Button goButton;
	GroupBox setGroup;
	CheckBox caseCheck;
	CheckBox fullCheck;
	CheckBox nameCheck;
	CheckBox contentCheck;
	CheckBox subCheck;
	CheckBox regCheck;
	CheckBox skipHiddenCheck;
	CheckBox skipSystemCheck;
	Label statusLabel;
	ProgressBar statusProgress;
	
	Replacer replacer;
	
	void OnFinished ()
	{
		statusProgress.Visible = false;
		statusLabel.Visible = true;
		
		if (replacer.Errors > 0) statusLabel.ForeColor = Color.Red;
		else statusLabel.ForeColor = Color.Green;
		
		statusLabel.Text = "Done.";
		
		if (replacer.ReplaceContents) statusLabel.Text += " " + Own.Line("Files:") + " " + replacer.ContentsReplaced.ToString() + ".";
		if (replacer.ReplaceNames) statusLabel.Text += " " + Own.Line("Names:") + " " + replacer.NamesReplaced.ToString() + ".";
		if (replacer.Errors > 0) statusLabel.Text += " " + Own.Line("Errors:") + " " + replacer.Errors.ToString() + ".";
		
		oldField.Enabled = true;
		newField.Enabled = true;
		goButton.Enabled = true;
		setGroup.Enabled = true;
	}
	
	void Go ()
	{
		if (oldField.Text == "") return;
		
		replacer.CaseSensitive = caseCheck.Checked;
		replacer.FullWords = fullCheck.Checked;
		replacer.ReplaceNames = nameCheck.Checked;
		replacer.ReplaceContents = contentCheck.Checked;
		replacer.Recursive = subCheck.Checked;
		replacer.RegExp = regCheck.Checked;
		replacer.SkipHidden = skipHiddenCheck.Checked;
		replacer.SkipSystem = skipSystemCheck.Checked;
		
		oldField.Enabled = false;
		newField.Enabled = false;
		goButton.Enabled = false;
		setGroup.Enabled = false;
		
		statusProgress.Visible = true;
		statusLabel.Visible = false;
		
		replacer.OldText = oldField.Text;
		replacer.NewText = newField.Text;
		
		new Thread(new ThreadStart(replacer.Go)).Start();
	}
	
	void SwitchState ()
	{
		if (regCheck.Checked) { try { new Regex(oldField.Text); } catch { goButton.Enabled = false; } }
		fullCheck.Enabled = caseCheck.Enabled = !regCheck.Checked;
		goButton.Enabled = !(!nameCheck.Checked && !contentCheck.Checked) && !string.IsNullOrEmpty(oldField.Text);
	}
	
	public Face (string path)
	{
		replacer = new Replacer(path);
		replacer.Finished += (o, e) => { Sync(OnFinished); };
		
		int padding = 10;
		
		Width = 400;
		MaximizeBox = false;
		FormBorderStyle = FormBorderStyle.FixedSingle;
		Text = Own.Line("Replace") + ": " + replacer.FullPath;
		Icon = Own.Icon("Replace");
		
		goButton = new Button();
		goButton.Text = Own.Line("Replace");
		goButton.Size = new Size(64, 24);
		goButton.Location = new Point(ClientSize.Width - goButton.Width - padding, padding);
		goButton.Click += delegate { Go(); };
		
		oldField = new TextBox();
		oldField.Width = ((goButton.Left - (padding * 2)) / 2) - padding / 2;
		oldField.Location = new Point(padding, padding + ((goButton.Height - oldField.Height) / 2));
		oldField.TextChanged += delegate { SwitchState(); };
		Controls.Add(oldField);
		
		newField = new TextBox();
		newField.Width = oldField.Width;
		newField.Location = new Point(oldField.Left + oldField.Width + padding, oldField.Top);
		Controls.Add(newField);
		
		Controls.Add(goButton);
		
		int h = 24;
		
		setGroup = new GroupBox();
		setGroup.Location = new Point(padding, goButton.Top + goButton.Height + padding / 2);
		setGroup.Size = new Size(ClientSize.Width - padding * 2, padding * 3 + h * 4);
		Controls.Add(setGroup);
		
		int l1 = padding * 2;
		int l2 = setGroup.ClientSize.Width / 2 + padding / 2;
		
		int t1 = padding * 2;
		int t2 = t1 + h;
		int t3 = t2 + h;
		int t4 = t3 + h;
		
		caseCheck = new CheckBox();
		fullCheck = new CheckBox();
		nameCheck = new CheckBox();
		contentCheck = new CheckBox();
		subCheck = new CheckBox();
		regCheck = new CheckBox();
		skipHiddenCheck = new CheckBox();
		skipSystemCheck = new CheckBox();
		
		bool directory = Directory.Exists(replacer.FullPath);
		
		subCheck.Enabled = subCheck.Checked = directory;
		nameCheck.Enabled = nameCheck.Checked = directory;
		contentCheck.Enabled = directory;
		skipSystemCheck.Enabled = directory;
		skipHiddenCheck.Enabled = directory;
		
		caseCheck.Text = Own.Line("Case-sensitive");
		fullCheck.Text = Own.Line("Full words only");
		nameCheck.Text = Own.Line("Replace in file names");
		contentCheck.Text = Own.Line("Replace in contents");
		subCheck.Text = Own.Line("Include subfolders");
		regCheck.Text = Own.Line("Regular expression");
		skipHiddenCheck.Text = Own.Line("Skip hidden files");
		skipSystemCheck.Text = Own.Line("Skip system files");
		
		setGroup.Controls.Add(caseCheck);
		setGroup.Controls.Add(fullCheck);
		setGroup.Controls.Add(regCheck);
		setGroup.Controls.Add(subCheck);
		setGroup.Controls.Add(nameCheck);
		setGroup.Controls.Add(contentCheck);
		setGroup.Controls.Add(skipHiddenCheck);
		setGroup.Controls.Add(skipSystemCheck);
		
		caseCheck.Location = new Point(l1, t1);
		fullCheck.Location = new Point(l1, t2);
		regCheck.Location = new Point(l1, t3);
		subCheck.Location = new Point(l2, t1);
		nameCheck.Location = new Point(l2, t2);
		contentCheck.Location = new Point(l2, t3);
		skipHiddenCheck.Location = new Point(l1, t4);
		skipSystemCheck.Location = new Point(l2, t4);
		
		regCheck.CheckedChanged += delegate { SwitchState(); };
		nameCheck.CheckedChanged += delegate { SwitchState(); };
		contentCheck.CheckedChanged += delegate { SwitchState(); };
		
		caseCheck.Size = fullCheck.Size = nameCheck.Size =
		contentCheck.Size = subCheck.Size =
		regCheck.Size = skipHiddenCheck.Size = skipSystemCheck.Size =
		new Size(setGroup.ClientSize.Width / 2 - padding * 2, h);
		
		contentCheck.Checked = true;
		caseCheck.Checked = true;
		skipHiddenCheck.Checked = directory;
		skipSystemCheck.Checked = directory;
		
		statusLabel = new Label();
		statusLabel.Location = new Point(padding, setGroup.Top + setGroup.Height + padding);
		statusLabel.Size = new Size(ClientSize.Width - (padding * 2), 18);
		statusLabel.BorderStyle = BorderStyle.Fixed3D;
		statusLabel.AutoEllipsis = true;
		statusLabel.Text = replacer.FullPath;
		Controls.Add(statusLabel);
		
		statusProgress = new ProgressBar();
		statusProgress.Location = statusLabel.Location;
		statusProgress.Size = statusLabel.Size;
		statusProgress.Style = ProgressBarStyle.Marquee;
		statusProgress.Visible = false;
		Controls.Add(statusProgress);
		
		ClientSize = new Size(ClientSize.Width, padding + statusLabel.Top + statusLabel.Height);
		
		SwitchState();
	}
	
	[STAThread] static void Main (string[] args)
	{
		if (args.Length != 1) return;
		Application.EnableVisualStyles();
		Application.Run(new Face(args[0]));
	}
	
	void Sync (Action act)
	{
		if (InvokeRequired) Invoke(act);
		else act();
	}
}
