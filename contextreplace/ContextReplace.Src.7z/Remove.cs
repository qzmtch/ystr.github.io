using System;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using Microsoft.Win32;

internal class Remove
{
	[STAThread] static void Main (string[] args)
	{
		if (args.Length == 0)
		{
			string temp = Path.GetTempPath();
			string place = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "");
			File.Copy(place + "\\Remove.exe", temp + "\\RemoveReplace.exe", true);
			Process.Start(temp + "\\RemoveReplace.exe", "\"" + place + "\"");
		}
		
		else
		{
			string pf = args[0];
			
			try { File.Delete(pf + "\\Replace.exe"); } catch {}
			try { File.Delete(pf + "\\Remove.exe"); } catch {}
			try { Directory.Delete(pf); } catch {}
			
			try { Registry.ClassesRoot.OpenSubKey("Directory\\shell", true).DeleteSubKeyTree("ContextReplace"); } catch {}
			try { Registry.ClassesRoot.OpenSubKey("Drive\\shell", true).DeleteSubKeyTree("ContextReplace"); } catch {}
			
			if (System.Environment.OSVersion.Version.Major > 5)
			{
				try { Registry.ClassesRoot.OpenSubKey("Directory\\Background\\shell", true).DeleteSubKeyTree("ContextReplace"); } catch {}
				try { Registry.ClassesRoot.OpenSubKey("LibraryFolder\\Background\\shell", true).DeleteSubKeyTree("ContextReplace"); } catch {}
			}
			
			try { Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall", true).DeleteSubKeyTree("ContextReplace"); } catch {}
		}
	}
}