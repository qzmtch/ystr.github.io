using System;
using System.IO;
using System.Text.RegularExpressions;

class Replacer
{
	public event EventHandler Started;
	public event EventHandler Finished;
	
	public readonly string FullPath;
	
	public bool CaseSensitive = true;
	public bool FullWords = false;
	public bool ReplaceNames = true;
	public bool ReplaceContents = true;
	public bool Recursive = true;
	public bool RegExp = false;
	public bool SkipHidden = true;
	public bool SkipSystem = true;
	
	public string OldText = null;
	public string NewText = null;
	
	Regex search;
	
	int namesReplaced = 0; public int NamesReplaced { get { return namesReplaced; } }
	int contentsReplaced = 0; public int ContentsReplaced { get { return contentsReplaced; } }
	int errors = 0; public int Errors { get { return errors; } }
	
	bool IsHidden (string path)
	{
		return (File.GetAttributes(path) & FileAttributes.Hidden) == FileAttributes.Hidden;
	}
	
	bool IsSystem (string path)
	{
		return (File.GetAttributes(path) & FileAttributes.System) == FileAttributes.System;
	}
	
	bool ToSkip (string path)
	{
		return (
			(IsHidden(path) && SkipHidden) ||
			(IsSystem(path) && SkipSystem)
		);
	}
	
	void ReName (string path)
	{
		try {
			
			if (ToSkip(path)) return;
			
			string folder = Path.GetDirectoryName(path);
			string name = Path.GetFileName(path);
			
			if (search.IsMatch(name))
			{
				string re = folder + "/" + search.Replace(name, NewText);
				
				if (Directory.Exists(path)) Directory.Move(path, re);
				else File.Move(path, re);
				
				namesReplaced++;
			}
			
		} catch { errors++; }
	}
	
	void ReContent (string path)
	{
		try {
			
			if (ToSkip(path)) return;
			
			string all;
			
			using (StreamReader r = new StreamReader(path)) all = r.ReadToEnd();
			
			if (search.IsMatch(all))
			{
				using (StreamWriter w = new StreamWriter(path))
				{
					w.Write(search.Replace(all, NewText));
				}
				
				contentsReplaced++;
			}
			
		} catch { errors++; }
	}
	
	void Replace (string path)
	{
		try {
			
			if (ToSkip(path)) return;
			
			if (Directory.Exists(path)) {
				if (ReplaceNames) foreach (string dir in Directory.GetDirectories(path)) ReName(dir);
				if (Recursive) foreach (string dir in Directory.GetDirectories(path)) Replace(dir);
				if (ReplaceNames) foreach (string file in Directory.GetFiles(path)) ReName(file);
				if (ReplaceContents) foreach (string file in Directory.GetFiles(path)) ReContent(file);
			} else if (ReplaceContents) ReContent(path);
		}
		catch { errors++; }
	}
	
	public void Go ()
	{
		if (string.IsNullOrEmpty(OldText)) return;
		if (OldText == null) OldText = "";
		
		if (Started != null) Started(this, null);
		
		namesReplaced = 0;
		contentsReplaced = 0;
		errors = 0;
		
		string rex = OldText;
		
		if (!RegExp)
		{
			rex = Regex.Escape(rex);
			if (FullWords) rex = "\\b" + rex + "\\b";
			if (CaseSensitive) rex = "(?-i)" + rex;
			else rex = "(?i)" + rex;
		}
		
		search = new Regex(rex);
		
		Replace(FullPath);
		
		if (Finished != null) Finished(this, null);
	}
	
	public Replacer (string path)
	{
		if (string.IsNullOrEmpty(path)) path = ".";
		FullPath = Path.GetFullPath(path);
	}
}
