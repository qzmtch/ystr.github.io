using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("ContextReplace Installer")]

internal class Setup : Form
{
	[STAThread] static void Main (string[] args)
	{
		Application.EnableVisualStyles();
		Application.Run(new Setup());
	}
	
	TextBox PathField;
	Button BrowseButton;
	Button GoButton;
	
	Button DoneButton;
	ProgressBar Progress;
	
	string product;
	string version;
	
	FolderBrowserDialog PathBrowser;
	
	string exePath;
	
	protected Setup ()
	{
		product = Application.ProductName.ToString();
		version = Application.ProductVersion.ToString();
		
		int padding = 10;
		int height = 24;
		
		Width = 400;
		MaximizeBox = MinimizeBox = false;
		FormBorderStyle = FormBorderStyle.FixedSingle;
		StartPosition = FormStartPosition.CenterScreen;
		Text = Own.Line("{AppName} setup").Replace("{AppName}", product + " " + version);
		Icon = Own.Icon("Replace");
		
		GoButton = new Button();
		GoButton.Text = Own.Line("Install");
		GoButton.Size = new Size(96, height);
		GoButton.Location = new Point(ClientSize.Width - GoButton.Width - padding, padding);
		GoButton.Click += delegate { Go(); };
		Controls.Add(GoButton);
		
		BrowseButton = new Button();
		BrowseButton.Text = "…";
		BrowseButton.Size = new Size(height, height);
		BrowseButton.Location = new Point(GoButton.Left - BrowseButton.Width - padding, padding);
		BrowseButton.Click += delegate { if (PathBrowser.ShowDialog() == DialogResult.OK) PathField.Text = PathBrowser.SelectedPath; };
		Controls.Add(BrowseButton);
		
		PathBrowser = new FolderBrowserDialog();
		
		PathField = new TextBox();
		PathField.Width = BrowseButton.Left - (padding * 2);
		PathField.Location = new Point(padding, padding + ((height - PathField.Height) / 2));
		try {
			object old = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\" + product).GetValue("Path");
			if (old == null) throw new Exception(); else PathField.Text = (string) old;
		} catch { PathField.Text = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\" + product; }
		Controls.Add(PathField);
		
		DoneButton = new Button();
		DoneButton.Text = Own.Line("Done");
		DoneButton.Size = GoButton.Size;
		DoneButton.Location = GoButton.Location;
		DoneButton.Enabled = false;
		DoneButton.Visible = false;
		DoneButton.Click += delegate { Environment.Exit(1); };
		Controls.Add(DoneButton);
		
		Progress = new ProgressBar();
		Progress.Location = new Point(padding, padding);
		Progress.Size = new Size(DoneButton.Left - (padding * 2), height);
		Progress.Visible = false;
		Progress.Maximum = 6;
		Controls.Add(Progress);
		
		ClientSize = new Size(ClientSize.Width, GoButton.Height + (padding * 2));
	}
	
	void Copy (string name, string path)
	{
		Stream from = Own.Get(name);
		FileStream to = new FileStream(path, FileMode.Create);
		
		int pointer;
		byte[] buffer = new byte[32*1024];
		
		while ((pointer = from.Read(buffer, 0, buffer.Length)) > 0) to.Write(buffer, 0, pointer);
		
		to.Close();
	}
	
	void PutKey (RegistryKey rk, string arg)
	{
		RegistryKey ak = rk.CreateSubKey("shell").CreateSubKey(product);
		ak.CreateSubKey("command").SetValue("", "\"" + exePath + "\"" + " \"%" + arg);
		ak.SetValue("", Own.Line("Replace…"));
		ak.SetValue("icon", Own.Line(exePath));
	}
	
	void Go ()
	{
		PathField.Visible = false;
		BrowseButton.Visible = false;
		GoButton.Visible = false;
		DoneButton.Visible = true;
		Progress.Visible = true;
		
		string path = PathField.Text.Trim();
		if (path.EndsWith("\\")) path.Remove(path.Length - 1);
		
		exePath = path + "\\Replace.exe";
		string unPath = path + "\\Remove.exe";
		
		try
		{
			long size = 0;
			
			if (!Directory.Exists(path)) Directory.CreateDirectory(path);
			Progress.Value++;
			
			Own.AllowExternal = false;
			
			Copy("Replace.exe", exePath);
			size += new FileInfo(exePath).Length;
			Progress.Value++;
			
			PutKey(Registry.ClassesRoot.CreateSubKey("Directory"), "1");
			PutKey(Registry.ClassesRoot.CreateSubKey("Drive"), "1");
			
			if (System.Environment.OSVersion.Version.Major > 5)
			{
				PutKey(Registry.ClassesRoot.CreateSubKey("Directory").CreateSubKey("Background"), "V");
				PutKey(Registry.ClassesRoot.CreateSubKey("LibraryFolder").CreateSubKey("Background"), "V");
			}
			
			Progress.Value++;
			
			Copy("Remove.exe", unPath);
			size += new FileInfo(unPath).Length;
			Progress.Value++;
			
			Own.AllowExternal = true;
			
			RegistryKey uk = Registry.LocalMachine.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\" + product);
			uk.SetValue("DisplayName", product);
			uk.SetValue("DisplayIcon", exePath);
			uk.SetValue("UninstallString", unPath);
			uk.SetValue("Path", path);
			uk.SetValue("Publisher", Own.Author);
			uk.SetValue("DisplayVersion", version);
			uk.SetValue("NoModify", 1);
			uk.SetValue("NoRepair", 1);
			uk.SetValue("URLInfoAbout", "http://ystr.github.io/contextreplace/");
			uk.SetValue("EstimatedSize", (int)size / 1024);
			Progress.Value++;
			
			Own.AllowInternal = false;
			
			string[] files = Own.Items;
			
			foreach (string file in files)
			{
				if (file.EndsWith(".tongue"))
				{
					Copy(file, path + "\\" + file);
				}
			}
			
			Progress.Value++;
			
			DoneButton.Enabled = true;
		}
		
		catch
		{
			Text = Own.Line("Error: {ErrorCode}").Replace("{ErrorCode}", Progress.Value.ToString());
		}
	}
}